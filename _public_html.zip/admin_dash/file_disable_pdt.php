<?php

session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
 {
  header("location: index.php"); // Redirecting To Profile Page
 }

 $db = new DB_Functions();
 $pdt=$_GET['pdtid'];
 $status=$db->get_stat($pdt); 
 $status=$status['status'];
 if($status==0)
 {
   $db->update_pdt_status($pdt,'1');
 }
 else if($status==1)
 {
   $db->update_pdt_status($pdt,'0');
 }

?>