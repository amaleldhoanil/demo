<?php 
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
    $db = new DB_Functions();
    $Oid=$_POST['oid'];
    $Status=$_POST['status'];
    $date=$_POST['date'];
    $date=date("h:i:sa", strtotime($date)); 
    $ps=$_POST['ps'];
    if($Status=='4')
    {
        $ps='1';
    }
    else
    {
        $ps=$ps;
    }
    $r=$db->update_order_status($Oid,$Status,$date,$ps);
    if($r)
    {
echo "1";
    }
    else
    {
echo "0";
    }

 }


?>