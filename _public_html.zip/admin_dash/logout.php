<?php
session_start();
 unset($_SESSION['login_admin']);
 
//if(session_destroy())
//{
  
   header("location: index.php");  
   // $_SESSION['expire']="";
//}

?>