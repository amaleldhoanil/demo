<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}else if(isset($_SESSION['expire'])){
  
  $now = time(); 
  if ($now > $_SESSION['expire']) {
     // session_destroy();
     unset($_SESSION["error"]);
     
  
}
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $Slider=$db->GetSliders();
  $details=$db->load_web_content();
  
           $i = 1; 
           while ($row = mysqli_fetch_array($details)) { 
  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>
      <div class="container-fluid">
        <div class="row">
          <!-- <div class="col-md-3">
            <section class="section-padding dashboard mngrdet">
              <div class="box-style">
                <h2>jishnu</h2>
                <hr>
                <ul>
                  <li>Marketing Executive</li>
                  <li>32154</li>
                  <li>trivandrum</li>
                </ul>
              </div>
            </section>
          </div> -->
          <div class="col-md-12">
            <section class="section-padding dashboard">
              <div class="container">
                <div class="row">
                  <div class="col-md-12">
                    <h2>Add Slide</h2>


                  </div>
                  <div class="col-md-6">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Slide Name</th>
                          <th scope="col">Image</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>

                      <?php
					$i = 1; 
          while ($row = mysqli_fetch_array($Slider)) { ?>
                        <tr>
                          <th scope="row"><?php echo $i;?></th>
                          <td><?php echo $row['slide_name'];?></td>
                          <td><img style="width:50px" src=<?php echo "../".$row['slide_url'];?> alt=""></td>
                          <td><a href="#delete<?php echo $row['id'];?>" data-toggle="modal"  class="btn btn-outline-danger"><i class="fa fa-trash m-0"></i></a> </td>
                        </tr>



                        <div class="modal fade" id="delete<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h6 class="modal-title text-center text-light" id="loginModalLabel">Are you sure want to delete?</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <!-- <form  action=""runat="server" method="POST" enctype="multipart/form-data"> -->
                      
     
                      <div class="form-row mt-3">
                        <div class="form-group col-md-6 text-right">
                        <a href="file_delete_slide.php?id=<?php echo $row['id'];?>" class="btn btn-danger" type="submit" >Yes</a>
                        </div>
                        <div class="form-group  col-md-6">
                        <a href="#" class="btn btn-primary" data-dismiss="modal"  >No</a>
                        </div>
                        </div>
                    <!-- </form> -->
      </div>
     
    </div>
  </div>
</div>
                        <?php
          $i++; 
	}
?>
                      </tbody>
                    </table>
                    <?php if($i==1)
{
         echo "<span class='text-danger'>Slides not found</span>";
}?>
                  </div>
                  <div class="col-md-6">
                    <form class="pd" action="file_add_slide.php" runat="server"  method="POST" enctype="multipart/form-data">
                      <h4 class="mb-1">Upload Slide </h4>
                      <span class="text-danger">(Width = 1500 * Height = 500)</span>
                      <div class="form-row mt-3">
                        <div class="form-group col-md-12">
                          <input type="text" class="form-control" placeholder="Slide Name" name="sname" id="sname" required>
                        </div>
                        <div class="form-group  col-md-12">
                        <input class="form-control-file" id="exampleFormControlFile1" type="file" class="form-control" required name="simage">
                        </div>
                        <div class="form-group col-md-12 text-center">
                          <button class="btn btn-primary" type="submit" name="">Upload</button>
                        </div>
                        <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<div id='snackbar' class='show'>$error</div>";
                    }
                ?> 

                      </div>
                    </form>
                  </div>
                  <div class="col-md-12">
                    <img id="blah" src="#" alt="">
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>





    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
