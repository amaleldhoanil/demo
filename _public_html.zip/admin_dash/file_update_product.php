<?php
 ini_set('display_errors', 1);
 ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
// if($_SERVER['REQUEST_METHOD']=='POST')
 //{
   
 $db = new DB_Functions();
 $pdt_id=$_POST['pdtid'];
  $pdt_name =$_POST['pdtname'];
  $actual=round($_POST['actual']);
  $disc=round($_POST['disc']);
  $offer=round($actual-(($actual/100)*$disc));
  $stock=$_POST['stock'];
  $New=$_POST['ybl'];
  $specset=$_POST['ps_field_name'];
  $colorset=$_POST['color_field_name'];
  $sizeset=$_POST['size_field_name'];
  $quaset=$_POST['quant_field_name'];
  $Img1=$_POST['img1']; 
  $Img2=$_POST['img2']; 
 
  if (basename($_FILES['image_field_name']['name'])==null && basename($_FILES['image_field_name2']['name'])==null)//1
 {
   $s=$db->update_product($pdt_id,$pdt_name,$actual,$disc,$offer,$stock,$New,$specset,$colorset,$sizeset,$quaset,$Img1,$Img2);
   if($s)
   {
      $error = "Product Details updated successfully!";
      $_SESSION["error"] = $error;
      $_SESSION['start'] = time();
      $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:products.php");
      
   }
   else
   {
      $error = "Please try again after sometime";
      $_SESSION["error"] = $error;
      $_SESSION['start'] = time();
      $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:products.php");
   }
 }else
 
 if(basename($_FILES['image_field_name']['name']) && basename($_FILES['image_field_name2']['name'])==null)//2
 {
   $ImagePath =basename($_FILES['image_field_name']['name']);
   $Img1 ="img/products/$ImagePath";
   $Img2==null;
    
   
 $target_dir = "../img/products/";
 $target_file = $target_dir . basename($_FILES['image_field_name']['name']);
  
        if(move_uploaded_file($_FILES["image_field_name"]["tmp_name"], $target_file) && $db->update_product($pdt_id,$pdt_name,$actual,$disc,$offer,$stock,$New,$specset,$colorset,$sizeset,$quaset,$Img1,$Img2))
      {
      $error = "Product Details Updated successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:products.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: products.php");
         } 
    
  }
  else if(basename($_FILES['image_field_name']['name'])== null && basename($_FILES['image_field_name2']['name']))//3
 {
   $ImagePath1 =basename($_FILES['image_field_name2']['name']);
   $Img2 ="img/products/$ImagePath1";
   $Img1=null;
   
 $target_dir1 = "../products/logo/";
 $target_file1 = $target_dir1 . basename($_FILES['image_field_name2']['name']);
  
        if(move_uploaded_file($_FILES["image_field_name2"]["tmp_name"], $target_file1) && $db->update_product($pdt_id,$pdt_name,$actual,$disc,$offer,$stock,$New,$specset,$colorset,$sizeset,$quaset,$Img1,$Img2))
      {
      $error = "Product Details Updated successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:products.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: products.php");
         } 
 } else if (basename($_FILES['image_field_name']['name'])&& basename($_FILES['image_field_name2']['name']))//4

 {
   $ImagePath =basename($_FILES['image_field_name']['name']);
   $Img1 ="img/products/$ImagePath";
    
   
 $target_dir = "../img/products/";
 $target_file = $target_dir . basename($_FILES['image_field_name']['name']);

 $ImagePath1 =basename($_FILES['image_field_name2']['name']);
 $Img2 ="img/products/$ImagePath1";
  
 
$target_dir1 = "../img/products/";
$target_file1 = $target_dir1 . basename($_FILES['image_field_name2']['name']);


if(move_uploaded_file($_FILES["image_field_name"]["tmp_name"], $target_file) && move_uploaded_file($_FILES["image_field_name2"]["tmp_name"], $target_file1) && $db->update_product($pdt_id,$pdt_name,$actual,$disc,$offer,$stock,$New,$specset,$colorset,$sizeset,$quaset,$Img1,$Img2))
{
$error = "Product Details Updated successfully!";
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: products.php");
} 
else 
   {
        $error = "Please try again after sometime"; 
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: products.php");
   } 


 }


 
 
 //}

 

?>