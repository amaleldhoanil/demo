<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}else if(isset($_SESSION['expire'])){
  
  $now = time(); 
  if ($now > $_SESSION['expire']) {
     // session_destroy();
     unset($_SESSION["error"]);
     
  
}
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $pdt=$db->pdt_list();
  $details=$db->load_web_content();
  $i = 1; 
  while ($row = mysqli_fetch_array($details)) { 
 ?>

 
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>

        <section class="section-padding dashboard">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <h2>Products</h2>
                <!-- <div class="form-group col-md-3">
                      <input type="search" class="form-control" name="qry"id="qry" placeholder="Name">
                      </div> -->
                      <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<div id='snackbar' class='show'>$error</div>";
                    }
                ?> 
                      
                      <form >
                  <div class="form-row">
                    <div class="form-group col-md-3">
                    <div class="input-group mb-3">
                        <input type="text" id="product_search" class="form-control" placeholder="Search Products" >
                        <div class="input-group-append">
                        <span class="input-group-text bg-primary text-white" id="basic-addon2">Search</span>
                     </div>
                    </div>
                    </div>
                     
                  </div>
  
                </form>
                
              </div>
              <div class="col-md-12">
                <div class="table-responsive">
                <table id="product_list" class="table table-hover">
                  <thead>
                  
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Image</th>
                      <th scope="col">Product Name</th>
                      <th scope="col">Category</th>
                      <th scope="col">Actual Price</th>
                      <th scope="col">Discount</th>
                      <th scope="col">Offer Price</th>
                      <th scope="col">Description</th>
                      <th scope="col">Stock</th>
                      <th scope="col">Color</th>
                      <th scope="col">Size</th>
                      <th scope="col">Quantity</th>
                      <th scope="col">Action</th>
                      
                    </tr>
                  </thead>
                  <tbody>

                  <?php
					$i = 1; 
          while ($row = mysqli_fetch_array($pdt)) { ?>
                    <tr>
                    <th scope="row"><?php echo $i;?></th>
                      <td><img style="width:30px" src=<?php echo "../".$row['img1'];?> alt=""></td>
                      <td><h6><?php echo $row['pdt_name'];?></h6></td>
                      <td><?php echo $row['pdt_cat_name'];?></td>
                      <td><?php echo $row['actual_price'];?></td>
                      <td><?php echo $row['disc'];?>%</td>
                      <td><?php echo $row['offer_price'];?></td>
                      <td><h6><?php echo $row['description'];?></h6></td>
                      <td><?php echo $row['stock_left'];?></td>
                      <td><?php echo $row['color'];?></td>
                      <td><?php echo $row['size'];?></td>
                      <td><?php echo $row['quantity'];?></td>
                      <?php 
                           $status=$row['status'];
                           if($status==1)
                           {
                             $text="off";
                           }else
                           {
                            $text="on";
                           }?>
                      <td>
                      <ul class="action">
                      <li><a href="#editproduct<?php echo $row['id'];?>" data-toggle="modal" class="btn btn-outline-warning"><i class="fa fa-edit m-0"></i></a></li>
                      <li><a id="onoff<?php echo $row['id'];?>"  href="file_disable_pdt.php?pdtid=<?php echo $row['id'];?>" class="onoff btn" ><?php echo $text;?></a></li>
                     <li><a href="#delete<?php echo $row['id'];?>" data-toggle="modal"  class="btn btn-danger"><i class="fa fa-trash m-0"></i></a></li> 
                     
                      </ul>
                      </td>

                      
                    </tr>
                    <div class="modal fade" id="delete<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h6 class="modal-title text-center text-light" id="loginModalLabel">Are you sure want to delete?</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <!-- <form  action=""runat="server" method="POST" enctype="multipart/form-data"> -->
                      
     
                      <div class="form-row mt-3">
                        <div class="form-group col-md-6 text-right">
                        <a href="file_delete_pdt.php?id=<?php echo $row['id'];?>" class="btn btn-danger" type="submit" >Yes</a>
                        </div>
                        <div class="form-group  col-md-6">
                        <a href="#" class="btn btn-primary" data-dismiss="modal"  >No</a>
                        </div>
                        </div>
                    <!-- </form> -->
      </div>
     
    </div>
  </div>
</div>
                    
                   <!-- Edit Product -->
<div class="modal fade " id="editproduct<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h6 class="modal-title text-light" id="exampleModalLongTitle">Update Product</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form class="needs-validation" action="file_update_product.php" runat="server"  method="POST" enctype="multipart/form-data" novalidate>
                  <div class="form-row">
                    <div class="form-group col-md-3">
                    <input id="field1" type="hidden"  class="form-control" value="<?php echo $row['id']; ?>" name="pdtid">
                      <label for="inputname">Product Name</label>
                      <input type="text" class="form-control" id="inputname" placeholder="Product Name" name="pdtname" value="<?php echo $row['pdt_name'];?>" required>
                      
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputmobile">Price</label>
                      <input type="text" class="form-control" id="inputmobile" placeholder="Price" name="actual"  value="<?php echo $row['actual_price'];?>" required>
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputamobile">Offer</label>
                      <input type="text" class="form-control" id="inputamobile" placeholder="50%"  name="disc" value="<?php echo $row['disc'];?>" required>
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputamobile">Stock Left</label>
                      <input type="text" class="form-control" id="inputamobile" placeholder="100" name="stock"value="<?php echo $row['stock_left'];?>"required>
                    </div>
                    <div class="form-group col-md-12">
                      <label class="text-danger" for="inputamobile">New in Market ?</label>
                      <div class="form-check">
                        <?php
                        $val=$row['new_arrival'];
                        if($val==1)
                        {
                          ?>
                          <label class="container"><input type="radio" checked="checked" value="1" name="ybl"><span class="checkmark"></span> Yes</label>
                      <label class="container"><input type="radio"  value="0" name="ybl"><span class="checkmark"></span> No</label>
                       <?php }else{?>
                        <label class="container"><input type="radio"  value="1" name="ybl"><span class="checkmark"></span> Yes</label>
                      <label class="container"><input type="radio"  checked="checked"value="0" name="ybl"><span class="checkmark"></span> No</label>
                        <?php 
                        }
                        ?>

                      
                        <!-- <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                              Yes
                        </label> -->
                        </div>
                     
                       </div>
                  </div>


                  
                  <div class="form-row">
                    <div class="form-group col-md-12 ps_field_wrapper">
                      <label for="field1">Specification</label>
                     <?php $db_val=$row['description'];
                        if($db_val!=null){?>
                         
                         <textarea type="text" class="form-control" id="aboutus"  rows="2" required name="ps_field_name" required><?php echo $row['description'];?></textarea>
                      <?php
                    
                    } else {?>
                    
                        <div class="input-group  mb-2"><input id="field1" type="hidden"  class="form-control"  name="ps_field_name"></div>
                        <span class='text-danger'>None</span>
                       
                        <?php 
 }
                        ?>
                   

                     </div>
                     </div>
                     <div class="form-row">
                    <div class="form-group col-md-12 color_field_wrapper">
                      <label for="field1">Color</label>
                     <?php $db_val=$row['color'];
                        if($db_val!=null){?>
                         
                         <textarea type="text" class="form-control" id="aboutus"  rows="2" required name="color_field_name" required><?php echo $row['color'];?></textarea>
                      <?php
                    
                    } else {?>
                        <div class="input-group  mb-2"><input id="field1" type="hidden"  class="form-control"  name="color_field_name"></div>
                        <span class='form-control text-danger'>None</span>
                        <?php 
 }
                        ?>
                      </div>
                     </div>
                     
                     <div class="form-row">
                        <div class="form-group col-md-12 size_field_wrapper">
                        <label for="field1">Size</label>
                     <?php $db_val=$row['size'];
                        if($db_val!=null){?>
                         
                         <textarea type="text" class="form-control" id="aboutus"  rows="2" required name="size_field_name" required><?php echo $row['size'];?></textarea>
                      <?php
                    
                    } else {?>
                        
                            <div class="input-group  mb-2"><input id="field1" type="hidden"  class="form-control"  name="size_field_name"></div>
                            <span class='form-control text-danger '>None</span>
                        
                        <?php 
 }
                        ?>
                       
          
                      </div>
                     </div>
                     
                     <div class="form-row">
                    <div class="form-group col-md-12 quant_field_wrapper">
                      <label for="field1">Quantity</label>
                     <?php $db_val=$row['quantity'];
                        if($db_val!=null){?>
                         
                         <textarea type="text" class="form-control" id="aboutus"  rows="2" required name="quant_field_name" required><?php echo $row['quantity'];?></textarea>
                      <?php
                    
                    } else {?>
                     
                        <div class="input-group  mb-2"><input id="field1" type="hidden"  class="form-control"  name="quant_field_name"></div>
                        <span class='form-control text-danger'>None</span>
                        
                        <?php 
 }
                        ?>
                     </div>
                     </div>
                     
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="field1">Uplaod Product Image <span class="text-danger">(Width=530 * height=390)</span></label>
                      <div class="input-group mb-2">
                        <div class="custom-file">
                        <input id="field1" type="hidden"  class="form-control" value="<?php echo $row['img1']; ?>" name="img1">
                          <input type="file" class="custom-file-input" id="pimagein_3" name="image_field_name">
                          <label class="custom-file-label" for="pimagein_3">Choose file</label>
                        
                        </div>
                        
                        
                      </div>
                      <img style="width: 100px;" id="pimage_3" src="<?php echo '../'.$row['img1']; ?>" alt="">
                    </div>

                    <div class="form-group col-md-6">
                      <label for="field1">Uplaod Product Image 2 <span class="text-danger">(Width=530 * height=390)</span></label>
                      <div class="input-group mb-2">
                        <div class="custom-file">
                        <input id="field1" type="hidden"  class="form-control" value="<?php echo $row['img2']; ?>" name="img2">
                          <input type="file" class="custom-file-input" id="pimagein_4" name="image_field_name2" >
                          <label class="custom-file-label" for="pimagein_2">Choose file</label>
                        
                        </div>
                        
                        
                        </div>
                         <img style="width: 100px;" id="pimage_4" src="<?php echo '../'.$row['img2']; ?>" alt="">
                        
                      
                    </div>

                      <div class="col-md-12 text-center">
                      <button type="submit" class="btn btn-primary">Add Product</button>
                      
                    </div>
                    
                </form>
      </div>
      
    </div>
  </div>
</div>      

                    <?php
          $i++; 
	}
?>

                  </tbody>
                </table>
              </div>
              </div>
            </div>
          </div>
        </section>


     
        
    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
