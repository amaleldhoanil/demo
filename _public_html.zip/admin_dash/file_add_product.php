<?php
 ini_set('display_errors', 1);
 ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);

$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$current= $dt->format('H:i:s');
$current1= $dt->format('d-m-Y');
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
// if($_SERVER['REQUEST_METHOD']=='POST')
 //{
   
 $db = new DB_Functions();
  $pdt_name =$_POST['pdtname'];
  $actual=round($_POST['actual']);
  $disc=round($_POST['disc']);
  $offer=round($actual-(($actual/100)*$disc));
  $stock=$_POST['stock'];
  $New=$_POST['ybl'];
  list($cid, $cname) = explode("-", $_POST['subcat'], 2);
  $categoryid=$cid;
  $categoryname=$cname;
  $specset=implode(",",$_POST['ps_field_name']);
  if(count($_POST["color_field_name"])!=null)
  {
   $colorset=implode(",",$_POST['color_field_name']);
  }
  else
  {
   $colorset=null;  
  }
  if(count($_POST["size_field_name"])!=null)
  {
   $sizeset=implode(",",$_POST['size_field_name']);
  }
  else
  {
   $sizeset=null;  
  }
  if(count($_POST["quant_field_name"])!=null)
  {
   $quaset=implode(",",$_POST['quant_field_name']);
  }
  else
  {
   $quaset=null;  
  }
  
 if(basename($_FILES['image_field_name']['name']) && basename($_FILES['image_field_name2']['name'])==null)//2
 {
   $ImagePath =basename($_FILES['image_field_name']['name']);
   $ServerURL ="img/products/$ImagePath";
   $ServerURL1==null;
    
   
 $target_dir = "../img/products/";
 $target_file = $target_dir . basename($_FILES['image_field_name']['name']);
  
        if(move_uploaded_file($_FILES["image_field_name"]["tmp_name"], $target_file) && $db->addproduct($pdt_name,$categoryid,$categoryname,$actual,$disc,$offer,$specset,$New,$stock,$colorset,$sizeset,$quaset,$ServerURL,$ServerURL1,$current1))
      {
      $error = "New Product Added successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:addproduct.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: addproduct.php");
         } 
    
  }else if (basename($_FILES['image_field_name']['name'])&& basename($_FILES['image_field_name2']['name']))//4

 {
   $ImagePath =basename($_FILES['image_field_name']['name']);
   $ServerURL ="img/products/$ImagePath";
    
   
 $target_dir = "../img/products/";
 $target_file = $target_dir . basename($_FILES['image_field_name']['name']);

 $ImagePath1 =basename($_FILES['image_field_name2']['name']);
 $ServerURL1 ="img/products/$ImagePath1";
  
 
$target_dir1 = "../img/products/";
$target_file1 = $target_dir1 . basename($_FILES['image_field_name2']['name']);


if(move_uploaded_file($_FILES["image_field_name"]["tmp_name"], $target_file) && move_uploaded_file($_FILES["image_field_name2"]["tmp_name"], $target_file1) && $db->addproduct($pdt_name,$categoryid,$categoryname,$actual,$disc,$offer,$specset,$New,$stock,$colorset,$sizeset,$quaset,$ServerURL,$ServerURL1,$current1))
{
$error = "New Product Added successfully!";
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: addproduct.php");
} 
else 
   {
        $error = "Please try again after sometime"; 
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: addproduct.php");
   } 


 }


 
 
 //}

 

?>