<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}else if(isset($_SESSION['expire'])){
  
  $now = time(); 
  if ($now > $_SESSION['expire']) {
     // session_destroy();
     unset($_SESSION["error"]);
     
  
}
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $Shop=$db->Load_Shop();
  $details=$db->load_web_content();
  $i = 1; 
  while ($row = mysqli_fetch_array($details)) { 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
<!-- ========== META TAGS ========== -->
<meta charset="utf-8">
<meta name="robots" content="all, index, follow" />
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>

        <section class="section-padding dashboard">
          <div class="container">
          <?php
          $i = 1; 
          while ($row = mysqli_fetch_array($Shop)) { ?>
            <div class="row">
              <div class="col-md-12">
                <h2>Add/Edit Shop Details</h2>
              </div>

              <div class="col-md-12">
                <form action="file_update_shop_details.php" runat="server"  method="POST" enctype="multipart/form-data">
                  <div class="form-row">
                    <div class="form-group col-md-3">
                      <label for="inputname">Brand/shop Name</label>
                      <input type="text" class="form-control" id="inputname" value="<?php echo $row['shop_name'];?>"  name="brand_name">
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputmobile">Mobile</label>
                      <input type="tel" class="form-control" id="inputmobile" value="<?php echo $row['shop_phone'];?>"  name="mobile">
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputamobile">Email</label>
                      <input type="email" class="form-control" id="inputamobile" value="<?php echo $row['shop_email'];?>"  name="email">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="per">GST in Percentage</label>
                         <input id="per"  type="text" class="form-control" value="<?php echo $row['tax'];?>"  name="tax">
                        </div>
                    <div  class="form-group col-md-3">
                          <label for="fb">Facebook Link</label>
                         <input id="fb"  type="text" class="form-control" value="<?php echo $row['fb_link'];?>"  name="fblink">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="insta">Instagram Link</label>
                         <input id="insta"  type="text" class="form-control" value="<?php echo $row['insta_link'];?>"  name="instalink">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="twiter">Twitter Link</label>
                         <input id="twiter"  type="text" class="form-control" value="<?php echo $row['tw_link'];?>"  name="twitterlink">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="yb">Youtube Link</label>
                         <input id="yb"  type="text" class="form-control" value="<?php echo $row['y_link'];?>"  name="yblink">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="play">Playstore Link</label>
                          <input id="play"  type="text" class="form-control" value="<?php echo $row['play_link'];?>"  name="playlink">
                    </div>
                    <div  class="form-group col-md-3">
                          <label for="play">Google Map iframe src Link</label>
                          <input id="play"  type="text" class="form-control" value="<?php echo $row['map_link'];?>"  name="gmaplink">
                    </div>
                    <div class="form-group col-mb-3">
                        <input type="hidden" class="form-control" id="old_small" value="<?php echo $row['small_logo'];?>" required name="old_small">
                        <img style="width:80px" src=<?php echo "../".$row['small_logo'];?> alt="">
                    </div>
                    <div class="form-group col-md-3">
                      <label for="field1"> Logo icon file </label>
                      <span class="text-danger">(W=50px * H=50px)</span>
                     
                      <div class="input-group mb-3">
                        <div class="custom-file">
                          <input class="form-control-file" id="ico" type="file" class="form-control" name="small_logo">
                          <label class="custom-file-label" for="ico">For browser Tab (Optional)</label>
                        </div>
                       
                      </div>
                        
                      
                    </div>
                    <div class="form-group col-md-12">
                      <label for="aboutus">About Us</label>
                      <textarea type="text" class="form-control" id="aboutus"  rows="10" required name="aboutus" required><?php echo $row['about'];?></textarea>
                    </div>
                    <div class="form-group col-md-12">
                      <label for="inputamobile">Address</label>
                      <textarea type="text" class="form-control" id="inputamobile"  rows="2" required name="address"><?php echo $row['shop_address'];?></textarea>
                    </div>
                    
                    <div class="form-group col-md-3">
                      
                      <label for="searchBox">Enter City  </label>
                      <div id="searchBoxContainer"><input id="searchBox" type="search" class="form-control" value="<?php echo $row['shop_city'];?>" required name="city"></div> 
                    </div>
                  
                  
                  
                  <div class="form-group col-md-3">
                    <label for="inputamobile">State</label>
                    <input type="text" class="form-control" id="inputamobile" value="<?php echo $row['shop_state'];?>" required name="state">
                 </div>
                 <div class="form-group col-md-3">
                    <label for="inputamobile">Country</label>
                    <input type="text" class="form-control" id="inputamobile" value="<?php echo $row['shop_country'];?>" required name="country">
                 </div>
                  <div class="form-group col-md-3">
                    <label for="inputamobile">Pincode</label>
                    <input type="text" class="form-control" id="inputamobile" value="<?php echo $row['shop_pin'];?>" required name="pincode">
                 </div>
                 
                 <div class="form-group col-md-3">
                      
                  <label for="inputamobile">Website Primary Color</label>
                  <input type="color" class="form-control" id="inputamobile" value="<?php echo $row['color_1'];?>" required name="color_1">
              
                
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputamobile">Website Secondary Color</label>
                      <input type="color" class="form-control" id="inputamobile" value="<?php echo $row['color_2'];?>" required name="color_2">
                  </div>
                    <div class="form-group col-mb-3">
                        <input type="hidden" class="form-control" id="old" value="<?php echo $row['logo'];?>" required name="old">
                        <img style="width:250px" src=<?php echo "../".$row['logo'];?> alt="">
                    </div>
                    <!-- <div class="form-row"> -->
                    <div class="form-group col-md-3">
                      <label for="field1">Uplaod shop/brand Logo </label>
                      <span class="text-danger">(W=250 * H=61)</span>
                     
                      <div class="input-group mb-3">
                        <div class="custom-file">
                          <input class="form-control-file" id="pimagein_1" type="file" class="form-control" name="logo">
                          <label class="custom-file-label" for="pimagein_1">Choose file</label>
                        </div>
                       
                      </div>
                        
                      
                    </div>
                  </div>
                  
                  <!-- </div> -->

            
                  <div class="col-md-12 text-center">
                      <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
              </div>
            </div>
            <?php
          $i++; 
	}
?>
 <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<div id='snackbar' class='show'>$error</div>";
                    }
                ?> 
                
          </div>
          
        </section>
        
        
    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script
    type="text/javascript"
    src="https://www.bing.com/api/maps/mapcontrol?key=AmZeinPpqVWDfY4hXTWpCp5AiRy7hGNnLKSn_sRSbY3fuMR8OHE17uc_23JUxiu2&callback=bingMapsReady"
    async
    defer
  ></script>
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
