<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}else if(isset($_SESSION['expire'])){
  
  $now = time(); 
  if ($now > $_SESSION['expire']) {
     // session_destroy();
     unset($_SESSION["error"]);
     
  
}
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $Category=$db->Cat_list();
  $details=$db->load_web_content();
           $i = 1; 
           while ($row = mysqli_fetch_array($details)) { 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
<!-- ========== META TAGS ========== -->
<meta charset="utf-8">
<meta name="robots" content="all, index, follow" />
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->

</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>
      <div class="container-fluid">
        <div class="row">
        
          <div class="col-md-12">
            <section class="section-padding dashboard">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-8">
                    <h2>Services</h2>


                  </div>
                  <div class="col-md-4 text-right">
                    <button class="btn btn-primary" data-target="#addserv" data-toggle="modal">Add Service</button>
                  </div>
                  <div class="col-md-12 mt-3">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Service Name</th>
                          <th scope="col">Image</th>
                          <th scope="col">Description</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
					$i = 1; 
          while ($row = mysqli_fetch_array($Category)) { ?>
                        <tr>
                          <th scope="row"><?php echo $i;?></th>
                          <td><?php echo $row['cat_name'];?></td>
                          <td><img style="width:60px" src=<?php echo "../".$row['cat_url'];?> alt=""></td>
                          <td><?php echo $row['des'];?></td>


                           <?php 
                           $status=$row['status'];
                           if($status==1)
                           {
                             $text="off";
                           }else
                           {
                            $text="on";
                           }?>
                          <td class=" d-flex flex-row">
                            <a href="#edit_category<?php echo $row['id'];?>" data-toggle="modal"  class="btn btn-warning editcat mr-1"><i class="fa fa-edit m-0"></i></a>
                            <a id="onoff<?php echo $row['id'];?>"  href="file_disable_cat.php?catid=<?php echo $row['id'];?>" class="onoff btn mr-1" ><?php echo $text;?></a>
                            <a href="#delete<?php echo $row['id'];?>" data-toggle="modal"  class="btn btn-danger mr-1"><i class="fa fa-trash m-0"></i></a>

                        </td>
                        </tr>






<div class="modal fade" id="delete<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h6 class="modal-title text-center text-light" id="loginModalLabel">Are you sure want to delete?</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <!-- <form  action=""runat="server" method="POST" enctype="multipart/form-data"> -->
                      
     
                      <div class="form-row mt-3">
                        <div class="form-group col-md-6 text-right">
                        <a href="file_delete_cat.php?id=<?php echo $row['id'];?>" class="btn btn-danger" type="submit" >Yes</a>
                        </div>
                        <div class="form-group  col-md-6">
                        <a href="#" class="btn btn-primary" data-dismiss="modal"  >No</a>
                        </div>
                        </div>
                    <!-- </form> -->
      </div>
     
    </div>
  </div>
</div>


 <!-- Modal-edit-categories -->
 <div class="modal fade" id="edit_category<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h6 class="modal-title text-center text-light" id="loginModalLabel">Edit</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form class="needs-validation" action="file_update_cat.php"runat="server" method="POST" enctype="multipart/form-data" novalidate>
                      <h4 class="mb-1">Edit Services</h4>
                      <span class="text-danger">Image size (W-500 * H-405)</span>
                     <img style="width:50px" src=<?php echo "../".$row['cat_url'];?> alt="">
                      <div class="form-row mt-3">
                        <div class="form-group col-md-12">
                          <input type="text" class="form-control" id="catname" value ="<?php echo $row['cat_name'];?>" placeholder="Product Category Name" required name="catname">
                          <input type="hidden" class="form-control" name="catid" value ="<?php echo $row['id'];?> ">
                          <input type="hidden" class="form-control" name="url" value ="<?php echo $row['cat_url'];?> ">
                        </div>
                        <div class="form-group col-md-12 ">
                      <!-- <label >Description</label> -->
                      <textarea class="form-control rounded" placeholder="Description" name="des" rows="5" required><?php echo $row['des'];?></textarea>

                    </div>
                        <div class="form-group  col-md-12">
                          <input class="form-control-file" id="exampleFormControlFile1" type="file" class="form-control" name="catimage">
                        </div>
                        <div class="form-group col-md-12 text-center">
                          <button class="btn btn-primary" type="submit" name="userfile">Save Changes</button>
                          
                        </div>
                
                    </div>
                    </form>
      </div>
     
    </div>
  </div>
</div>



                        
                        <?php
          $i++; 
	}
?>


                        
                      </tbody>
                      
                    </table>
                    <?php if($i==1)
{
         echo "<span class='text-danger'>Categories not found</span>";
}?>
                  </div>
               
                  
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>


      
<div class="modal fade" id="addserv" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title " id="exampleModalLabel">Add New Service</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form class="  needs-validation" action="file_add_category.php"runat="server" method="POST" enctype="multipart/form-data" novalidate>
                      
                      <span class="text-danger">Image Size(W-500 * H-405)</span>
                      
                      <div class="form-row mt-3">
                        <div class="form-group col-md-12">
                          <input type="text" class="form-control" id="catname" placeholder="Service Name" required name="catname">
                        </div>
                        <div class="form-group col-md-12 ">
                      <!-- <label >Description</label> -->
                      <textarea class="form-control rounded" placeholder="Description" name="des" rows="5" required></textarea>

                    </div>

                        <div class="form-group  col-md-12">
                          <input class="form-control-file" id="exampleFormControlFile1" type="file" class="form-control" required name="catimage">
                        </div>
                        <div class="form-group col-md-12 text-center">
                          <button  class="btn btn-primary" type="submit" name="userfile">Upload</button>
                          
                        </div>
                        <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<div id='snackbar' class='show'>$error</div>";
                    }
                ?> 
 </div>
                    </form>
     
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>


    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
