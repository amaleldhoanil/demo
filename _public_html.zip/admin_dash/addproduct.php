<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}else if(isset($_SESSION['expire'])){
  
  $now = time(); 
  if ($now > $_SESSION['expire']) {
     // session_destroy();
     unset($_SESSION["error"]);
     
  
}
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $Category=$db->Load_cat();
  $details=$db->load_web_content();
  
           $i = 1; 
           while ($row = mysqli_fetch_array($details)) { 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
<!-- ========== META TAGS ========== -->
<meta charset="utf-8">
<meta name="robots" content="all, index, follow" />
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">

<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>

        <section class="section-padding dashboard">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h2>Add Products</h2>
              </div>

              <div class="col-md-12">
                <form class="needs-validation"  action="file_add_product.php" runat="server"  method="POST" enctype="multipart/form-data" novalidate>
                  <div class="form-row">
                    <div class="form-group col-md-3">
                      <label for="inputname">Product Name</label>
                      <input type="text" class="form-control" id="inputname" placeholder="Product Name" name="pdtname"  required>
                      
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputmobile">Price</label>

                      <input type="number" class="form-control" id="inputmobile" placeholder="Price" name="actual"  required>

                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputamobile">Offer</label>
                      <input type="number" class="form-control" id="inputamobile" placeholder="50%" name="disc"  required>
                    </div>
                    <div class="form-group col-md-3">
                      <label for="inputamobile">Stock Left</label>
                      <input type="number" class="form-control" id="inputamobile" placeholder="100" name="stock"  required>

                    </div>
                    <div class="form-group col-md-12">
                      <label class="text-danger" for="inputamobile">New in Market ?</label>
                      <div class="form-check">
                        

                      <label class="container"><input type="radio" checked="checked" value="1" name="ybl"><span class="checkmark"></span> Yes</label>
                      <label class="container"><input type="radio" checked="checked" value="0" name="ybl"><span class="checkmark"></span> No</label>
                        <!-- <input class="form-check-input" type="radio" value="1" id="flexCheckDefault" name="ybl">
                        <label class="form-check-label" for="flexCheckDefault">Yes</label> -->
                        </div>
                     
                       </div>
                    <div class="form-group col-md-6">
                      
                        <label for="inputcat">Choose Category</label>
                        <select id="inputcat" class="form-control selectpicker" required>
                          <option id="cc"  selected value="">Choose Category</option>
                          <!--<option  value="Grocery">Grocery</option>
                           <option value="Mobiles">Mobiles</option>
                          <option value="Fashion">Fashion</option>
                          <option value="Electronics">Electronics</option>
                          <option value="Home">Home & Appliances</option> -->
                          <option value="Other">Restaurant</option>
                        </select>
                      
                    </div>
                    <div class="form-group col-md-6">
                      
                        <label for="inputcat2">Sub Category</label>
                        <select id="inputcat2" class="form-control selectpicker" name="subcat"  required>
                          <option value="">Choose Category</option>
                        <?php  $i = 1; 
          while ($row = mysqli_fetch_array($Category)) { ?>
                         <option value="<?php echo $row[0]. "-" . $row[1];?>"> <?php echo $row[1];?></option>
                              
                        <?php
          $i++; 
	}
?>
                          </select>
                      
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-12 ps_field_wrapper">
                      <label for="field1">Specification</label>
                      <div class="input-group  mb-2">
                        
                        <input id="field1" type="text" class="form-control" placeholder="Enter Product Specification"  name="ps_field_name[]"  required>
                        <div class="input-group-append">
                          <button class="btn btn-primary ps_add_button" type="button">Add</button>
                        </div>
                      </div>
                    </div>
                    
                  
                  </div>
                  <div id="col" class="form-row ">
                    <div class="form-group col-md-12 color_field_wrapper">
                      <label for="field2">Color</label>
                      <div class="input-group  mb-2">
                        
                        <input id="field2" type="text" class="form-control" placeholder="Enter color"  name="color_field_name[]"  >
                        <div class="input-group-append">
                          <button class="btn btn-primary color_add_button" type="button">Add</button>
                        </div>
                      </div>
                    </div>
                    
                  
                  </div>
                  <div id="size" class="form-row ">
                    <div class="form-group col-md-12 size_field_wrapper">
                      <label for="field3">Size</label>
                      <div class="input-group  mb-2">
                        
                        <input id="field3" type="text" class="form-control" placeholder="Enter size"  name="size_field_name[]"  >
                        <div class="input-group-append">
                          <button class="btn btn-primary size_add_button" type="button">Add</button>
                        </div>
                      </div>
                    </div>
                    </div>
                    <div id="quant" class="form-row ">
                    <div class="form-group col-md-12 quant_field_wrapper">
                      <label for="field4">Quantity</label>
                      <div class="input-group  mb-2">
                        
                        <input id="field4" type="text" class="form-control" placeholder="Enter Quantity"  name="quant_field_name[]"  >
                        <div class="input-group-append">
                          <button disabled class="btn btn-primary quant_add_button" type="button">Add</button>
                        </div>
                      </div>
                    </div>
                    </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="pimagein_3">Uplaod Product Image <span class="text-danger">(Width=530 * height=390)</span></label>
                      <div class="input-group mb-2">
                        <div class="custom-file">
                        
                          <input  type="file" class="custom-file-input" id="pimagein_3" name="image_field_name"  required>
                          <label class="custom-file-label" for="pimagein_3">Choose file</label>
                        
                        </div>
                        
                        
                      </div>
                      <img style="width: 100px;" id="pimage_3" src="#" alt="">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="pimagein_4">Uplaod Product Image 2 <span class="text-danger">(Width=530 * height=390)</span></label>
                      <div class="input-group mb-2">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="pimagein_4" name="image_field_name2" >
                          <label class="custom-file-label" for="pimagein_2">Choose file</label>
                        
                        </div>
                        
                        
                        </div>
                         <img style="width: 100px;" id="pimage_4" src="#" alt="">
                        
                      
                    </div>
                      <!-- <div class="form-group col-md-6">
                        <label for="field1">Uplaod Product Image 3 <span class="text-danger">(Width=530 * height=390)</span></label>
                        <div class="input-group mb-2">
                          <div class="custom-file">
                            <input type="file" class="custom-file-input" id="pimagein_3" name="image_field_name">
                            <label class="custom-file-label" for="pimagein_3">Choose file</label>
                          
                          </div>
                          
                          
                        </div>
                        <img style="width: 100px;" id="pimage_3" src="#" alt="">
                          
                        
                        </div>
                        <div class="form-group col-md-6">
                          <label for="field1">Uplaod Product Image 4 <span class="text-danger">(Width=530 * height=390)</span></label>
                          <div class="input-group mb-2">
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="pimagein_4" name="image_field_name">
                              <label class="custom-file-label" for="pimagein_4">Choose file</label>
                            
                            </div>
                            
                            
                          </div>
                          <img style="width: 100px;" id="pimage_4" src="#" alt="">
                            
                          
                          </div> -->
                  
                          <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<div id='snackbar' class='show'>$error</div>";
                    }
                ?> 
                  
                  
                  


                    <div class="col-md-12 text-center">
                      <button type="submit" class="btn btn-primary">Add Product</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </section>



    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
