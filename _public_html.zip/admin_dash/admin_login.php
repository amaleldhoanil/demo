<?php
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
//if(!isset($_SESSION['login_admin']))
//{
 //header("location: ../pinewick_admin_dash/index.php"); // Redirecting To Profile Page
//}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
 //importing DB_functions
 $db = new DB_Functions();
 //storing values from form
         $phone =htmlspecialchars($_POST['auser']);
         $password =htmlspecialchars($_POST['apass']);

         $user = $db->getpassByPhone($phone);
         $Db_pass = $user['admin_pass'];
         
          if (password_verify($password,$Db_pass)) 
          {
               $user =$db->GetAdminID($phone);
               $Db_id = $user['id'];
               $_SESSION['aid']=$Db_id;

                 echo 'Successfully Loged in';
                 $_SESSION['login_admin'] = $phone; 
                 header("location: admin.php"); // Redirecting To Profile Page 
          } 
          else 
          {
              // user is not found with the credentials
               $error = "Invalid Username or Password"; 
                $_SESSION["error"] = $error;
                 $_SESSION['start'] = time();
                  $_SESSION['expire'] = $_SESSION['start'] + 5;
                header("location: index.php");
               }
     
 }
?>