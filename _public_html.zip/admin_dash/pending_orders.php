<?php
session_start();
require_once 'include/DB_Functions.php';
$db = new DB_Functions();

if(!isset($_SESSION['login_admin']))
    {
 header("location: index.php");
}
else
{
  $orders=$db->load_accepted_orders();

  $details=$db->load_web_content();
  $i = 1; 
  while ($row = mysqli_fetch_array($details)) { 
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<script src="https://kit.fontawesome.com/2c3550df7e.js" crossorigin="anonymous"></script>
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>

    <section class="section-padding dashboard">
      <div class="container">
        <div class="row">
         <div class="col-md-12 ">
         <h5>Accepted Orders</h5>
        <?php while($row = mysqli_fetch_array($orders))
    {?>
       
            <div class="card mb-1">
              
              <div class="card-body">
               <div class="row">
               <div class="col-md-2">
                  <img class="ordimg"  src="../img/shopping-cart.png" alt="">
               </div>
               <div class="col-md-10">
               <ul class='my_orders mb-3'>
                <li>Order ID: <?php echo $row['id'];?></li>
                <li>Orderd on: <?php echo $row['dates'];?></li>
                <?php if($row['d_expect']!=null)
                {?><li> Delivery Expected : <?php echo $row['d_expect'];?></li>
                <?php }?>
               </ul>
               <ul class="my_orders my_ordersvc mb-4">
                   
                   <li class="price">₹<?php echo $row['total'];?></li>
                   <li>
                     
                   <button data-toggle="modal" data-target="#review<?php echo $row['id'];?>" class="btn .bg-dark">View Order</button>
                   </li>
                  
                   <li>
                   <button data-toggle="modal" data-target="#accept_order<?php echo $row['id'];?>" class="btn btn-success">Update Order Status</button>
                   </li>
      
                 </ul>
                 <ul class="my_orders my_ordersvc">
                 <?php if($row['pay_mode']==0){ ?>
                   <li ><span> Mode of Payment : </span><span class="text-success">Cash On Delivery</span></li>
                   <?php } else { ?>
                    <li ><span> Mode of Payment : </span><span class="text-success">Online Payment</span></li>
                   <?php } ?>
                   <?php if($row['pay_status']==0){ ?>
                   <li ><span> Payment Status : </span><span class="text-danger">Not Paid</span></li>
                   <?php } else { ?>
                    <li> Payment Status<span> : </span><span class="text-success">Paid</span></li>
                   <?php } ?>
                   <?php if($row['order_status']==1){ ?>
                   <li ><span> Order Status : </span><span class="text-success">Order Accepted</span></li>
                   <?php } else if($row['order_status']==2) {?>
                    <li ><span> Order Status : </span><span class="text-success">Packed</span></li>
                   <?php } else if($row['order_status']==3) {?>
                    <li ><span> Order Status : </span><span class="text-warning">Out For Delivery</span></li>
                   <?php }?>
                 </ul>
               </div>
                
              </div>
              
            </div>
          </div>

<div class="modal fade" id="review<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      
      <div class="modal-body">

      <!-- order list item -->
             <?php 
             $o_pdts=$db->load_order_pdts($row['id']);
             $i=0;
             $original=0;
             $disc=0;
             $total=0;
             while($row1 = mysqli_fetch_array($o_pdts))
             {
               $i=$i+$row1['quantity'];
               $original=$original+($row1['item_original']*$row1['quantity']);
               $disc=$disc+($row1['disc']*$row1['quantity']);
               $total=$total+($row1['item_offer']*$row1['quantity']);
              ?>
            <ul class="my_cart">
              <li ><img style="width: 40px;" src="<?php echo $row1['img1'];?>" alt=""></li>
              <li class="cwidthmyo pr-4">
                <span class="m-0"><a class="text-dark" href=""><?php echo $row1['pdt_name'];?></a></span>
                <p class="m-0">Qty: <?php echo $row1['quantity'];?></p>
                <?php if($row1['color']!='0')
                {?><p class="m-0">Sauce:<?php echo $row1['color'];?></p>
                <?php }?>
                <?php if($row1['size']!='0')
                {?><p class="m-0">Spicy:<?php echo $row1['size'];?></p>
                <?php }?>
              </li>
              <li>
              <span class="price"><b>₹ <?php echo $row1['item_offer'];?></b></span>
              </li>
            
             <li><div class="rateYo"></div></li>
            </ul>
            
       <?php  } ?> 
      </div>
      <!-- order list item -->
    <div class="container">
    
      <div class="row">
      <div class="col-md-6">
                       <!-- order details -->
      <div class="card">
        <div class="card-header">
            Order Details(<?php echo $i;?>)
        </div>
            <div class="card-body">
            <dl class="row mb-0">
              <dt class="col-md-5 col-6">Order ID </dt>
              <dd class="col-md-4 col-6"><?php echo $row['id'];?></dd>
              
              <dt class="col-md-5 col-6">Price </dt>
              <dd class="col-md-4 col-6">₹<?php echo $original;?> </dd>

              <dt class="col-md-5 col-6">Discount</dt>
              <dd class="col-md-4 col-6 font-weight-bold">-₹<?php echo $disc;?> </dd>
            
              <dt class="col-md-5 col-6">Delivery Fee</dt>
              <dd class="col-md-4 col-6">₹<?php echo $row['d_fee'];?> </dd>
            
              <dt class="col-md-5 col-6">Sub Total</dt>
              <dd class="col-md-4 col-6 font-weight-bold">₹<?php echo $total+$row['d_fee'];?> </dd>

              <dt class="col-md-5 col-6">Tax</dt>
              <dd class="col-md-4 col-6">₹<?php echo $row['tax'];?></dd>
              
            </dl>
            
          </div>
          <div class="card-footer">
          <dl class="row mb-0">
             <dt class="col-md-5 col-6"><b>Total Amount</b></dt>
              <dd class="col-md-4 col-6"><b>₹ <?php echo $row['total'];?> </b></dd>
          </dl>
              
          </div>
        </div>
        <?php 
        $user=$db->load_user($row['user_id']);
        while($row2 = mysqli_fetch_array($user))
    {?>

      
      </div>
      <div class="col-md-6">
      <div class="card">
         <div class="card-header">
            Customer Details
        </div>
            <div class="card-body">
            <dl class="row mb-0">
              <dt class="col-md-5 col-6"> Customer Name</dt>
              <dd class="col-md-7 col-6"><?php echo $row2['name'];?></dd>
              
              <dt class="col-md-5 col-6">Phone </dt>
              <dd class="col-md-7 col-6"><?php echo $row2['phone'];?></dd>

              <dt class="col-md-5 col-6">Email</dt>
              <dd class="col-md-7 col-6 font-weight-bold"><?php echo $row2['email'];;?></dd>
            
              <dt class="col-md-5 col-6">Address</dt>
              <dd class="col-md-7 col-6"><?php echo $row2['address'];?></dd>
            
              <dt class="col-md-5 col-6">Landmark</dt>
              <dd class="col-md-7 col-6 font-weight-bold"><?php echo $row2['landmark'];?></dd>

              <dt class="col-md-5 col-6">City</dt>
              <dd class="col-md-7 col-6"><?php echo $row2['city'];?></dd>
              <dt class="col-md-5 col-6">Emirate</dt>
              <dd class="col-md-7 col-6"><?php echo $row2['state'];?></dd>
              <!-- <dt class="col-md-5 col-6">Pincode</dt>
              <dd class="col-md-7 col-6"><?php echo $row2['pin'];?></dd> -->
              
            </dl>
            
          </div>
          
        </div>
      </div>
      </div>
  </div>
   

    
     
    </div>
    <?php } ?>
    <!-- order details -->
  </div>
</div>

      <!-- accept order -->

      <div class="modal fade" id="accept_order<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Order ID: <?php echo $row['id'];?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="acceptorder-form" action="">
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="edd">Expected Delivery Time</label>
              <input type="Time" class="form-control edd">
            </div>
            <div class="form-group col-md-12 m-0">
              <label for="edd">Choose Current Status of the Order !</label>
            </div>
            <div class="form-group col-md-12">
              
              
              <input class="oid"  type="hidden" value="<?php echo $row['id'];?>">
              <input class="ps"  type="hidden" value="<?php echo $row['pay_status'];?>">
                
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="schk"  value="2">
                <label class="form-check-label">Packed</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="schk"   value="3">
                <label class="form-check-label">Out For delivery</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="schk"   value="4">
                <label class="form-check-label">Delivered</label>
              </div>
            </div>
          </div>
          </form>
      </div>
      <div class="modal-footer">
        
        <button  type="submit" class="btn btn-warning acco">Update Order</button>
      </div>
    </div>
  </div>
</div>


<?php }?>
          
         
        </div>
        
      </div>
      


    </section>


        
    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
<?php }?>