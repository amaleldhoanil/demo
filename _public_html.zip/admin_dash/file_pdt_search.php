<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
$db = new DB_Functions();
if(isset($_POST['qry']))
{
   $search=$_POST['search'];
   $search="%$search%";
   if(strlen($search)>0)
   {
$data=$db->searchdata($search);

echo "$data";
}
}



?>