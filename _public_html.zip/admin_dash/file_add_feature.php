 <?php

session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
   
     //importing DB_functions
 $db = new DB_Functions();
 $feature_count=$db->get_feature_count();
 $count=$feature['total'];
 $Name=$_POST['fname'];
 $ServerURL=$_POST['fimage'];
// if($count>5)
// {
//    $ImagePath =basename($_FILES['fimage']['name']);
//    $ServerURL ="img/services/$ImagePath";
    
   
//  $target_dir = "../img/services/";
//  $target_file = $target_dir . basename($_FILES['fimage']['name']);
  
        if($db->add_feature($ServerURL,$Name))
      {
      $error = "New Video Added successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: add_features.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: add_features.php");
         } 
// } 
// else
// {
//    $error = "Maximum No.of Features added, Delete existing banner to add newone"; 
//    $_SESSION["error"] = $error;
//     $_SESSION['start'] = time();
//      $_SESSION['expire'] = $_SESSION['start'] + 5;
// header("location: add_features.php");  
// }

 
   
 
}
 
 
 

?>