<?php

class DB_Functions {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {
        //require_once 'DB_Connect.php';
        
    }
	
    
  //admin login
  
  public function getpassByPhone($phone) 
  {
      $stmt=$this->conn->query("SELECT admin_pass FROM tbl_admin WHERE admin_id ='$phone' ");
     if ($stmt) 
     {
      $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }
  } 
   //get admin id
 public function GetAdminID($Auser)
 {
      $stmt=$this->conn->query("SELECT id FROM tbl_admin WHERE admin_id ='$Auser' ");
   
         if ($stmt) 
     {
      $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }
  }
  public function get_catcount()
  {
    $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_category` WHERE status='0'  ");
   
    if ($stmt) 
{
 $stmt=$stmt->fetch_assoc();
 return $stmt;
    
} 
  }

  public function add_categories($ServerURL,$Name,$des)
  {
    $stmt=$this->conn->query("INSERT INTO `tbl_category`(`cat_name`,`des`,`cat_url`, `status`) VALUES ('$Name','$des','$ServerURL','0')");  

if($stmt)

{
return true;
}else{
return false;

}
  }
  public function temp_cat()
  {
      $stmt=$this->conn->query("SELECT * FROM `tbl_category` WHERE `status` = '0' ");
   
      if ($stmt) 
  {
  // $stmt=$stmt->fetch_assoc();
   return $stmt;
      
  }  
  }
  public function Cat_list()
  {

    $stmt=$this->conn->query("SELECT * FROM tbl_category WHERE status!='2'");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}
  }

  public function delete_categories($Cat)
  {
    $stmt=$this->conn->query("UPDATE `tbl_category` SET `status`='2' WHERE id='$Cat' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return true;
  }else{
    return false;
  }

   
}

public function add_update_cat($ServerURL,$Name,$Cat,$des)
{
  $stmt=$this->conn->query("UPDATE `tbl_category` SET `cat_name`='$Name',`cat_url`='$ServerURL',`des`='$des' WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}
}
public function get_status($Cat)
{
  $stmt=$this->conn->query("SELECT * FROM tbl_category WHERE id ='$Cat' ");
  if ($stmt) 
  {
   $stmt=$stmt->fetch_assoc();
   return $stmt;
      
  }
}
public function update_cat_status($Cat,$update)
{
  $stmt=$this->conn->query("UPDATE `tbl_category` SET `status`='$update' WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}
}
public function add_slide($ServerURL,$Name)
{
  $stmt=$this->conn->query("INSERT INTO `tbl_slider`(`slide_name`, `slide_url`, `status`) VALUES ('$Name','$ServerURL','0')");  

  if($stmt)
  
  {
  return true;
  }else{
  return false;
  
  }
}
public function add_gallery($ServerURL,$Name)
{
  $stmt=$this->conn->query("INSERT INTO `tbl_gallery`(`slide_name`, `slide_url`, `status`) VALUES ('$Name','$ServerURL','0')");  

  if($stmt)
  
  {
  return true;
  }
  else
  {
  return false;
}
}
public function get_ser($ser)
{

  $stmt=$this->conn->query(" SELECT `cat_name` FROM `tbl_category` WHERE `id`='$ser' ");
     
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;   
}  
}
//slide listing
public function GetSliders()
{
     $stmt=$this->conn->query("SELECT * FROM tbl_slider WHERE status ='0' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }
}
public function getGallery()
{
  $stmt=$this->conn->query("SELECT * FROM tbl_gallery WHERE status ='0' ");
   
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return $stmt;
  
}
}
public function delete_slide($Cat)
{
  $stmt=$this->conn->query("UPDATE `tbl_slider` SET `status`='1' WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}
}
public function delete_image($Cat)
{
  $stmt=$this->conn->query("DELETE FROM `tbl_gallery` WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
} 
}
// add feature
public function add_feature($ServerURL,$Name)
{
  $stmt=$this->conn->query("INSERT INTO `tbl_features`(`feature_name`, `feature_url`, `status`) VALUES ('$Name','$ServerURL','0')");  

  if($stmt)
  
  {
  return true;
  }else{
  return false;
  
  } 
}

public function get_feature_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_features` WHERE status='0'  ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
} 
}
public function Load_features()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_features` WHERE status = '0' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }   
}

public function delete_feature($Cat)
{
  $stmt=$this->conn->query("UPDATE `tbl_features` SET `status`='1' WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
} 
}

public function Load_Shop()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_shop_details` WHERE id = '1' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }    
}
public function update_shop($shop_name,$shop_phone, $shop_email,$shop_address,$shop_city,$shop_state,$shop_country,$shop_pin,$shop_color1,$shop_color2,$old_logo,$Tax,$Fb,$Insta,$Twi,$Y,$Play,$Map,$about,$old_small)
{
  $stmt=$this->conn->query("UPDATE `tbl_shop_details` SET `shop_name`='$shop_name',`shop_phone`='$shop_phone',
  `shop_email`='$shop_email',`shop_address`='$shop_address',`shop_city`='$shop_city',`shop_state`='$shop_state',
  `shop_country`='$shop_country',`shop_pin`='$shop_pin',`color_1`='$shop_color1',`color_2`='$shop_color2',
  `logo`='$old_logo',`small_logo`='$old_small',`tax`='$Tax',`fb_link`='$Fb',`insta_link`='$Insta',`tw_link`='$Twi',`y_link`='$Y',
  `play_link`='$Play',`map_link`='$Map',`about`='$about' WHERE id='1'");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
} 
}

public function add_deli_loc($Loc,$Fee,$Pin)
{
  $stmt=$this->conn->query("INSERT INTO `tbl_delivery_loc`(`district`, `pincode`, `d_fee`, `status`) 
                             VALUES ('$Loc','$Pin','$Fee','0')");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}  
}
public function Load_Loc()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_delivery_loc` WHERE status = '0' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }    
}
public function update_deli_loc($Loc,$Fee,$Pin,$ID)
{
  $stmt=$this->conn->query("UPDATE `tbl_delivery_loc` SET `district`='$Loc',`pincode`='$Pin',
                           `d_fee`='$Fee' WHERE id='$ID' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}  
}
public function delete_location($Cat)
{
  $stmt=$this->conn->query("UPDATE `tbl_delivery_loc` SET `status`='1' WHERE id='$Cat' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}  
}
public function Load_cat()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_category` WHERE status = '0' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }    
}
public function addproduct($pdt_name,$categoryid,$categoryname,$actual,$disc,$offer,$specset,$New,$stock,$colorset,$sizeset,$quaset,$ServerURL,$ServerURL1,$current1)
{
  $stmt=$this->conn->query("INSERT INTO `tbl_products`(`pdt_name`, `pdt_cat`, `pdt_cat_name`, `actual_price`, `disc`, `offer_price`, `description`, `new_arrival`, `trending`, `stock_left`, `color`, `size`, `quantity`, `img1`, `img2`, `day`, `status`) 
                            VALUES ('$pdt_name','$categoryid','$categoryname','$actual','$disc','$offer','$specset',
                            '$New','0','$stock','$colorset','$sizeset','$quaset','$ServerURL','$ServerURL1','$current1','0')");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}   
}
public function get_pdt_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_products` WHERE status='0' OR status='1'  ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}  
}
public function pdt_list()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_products` WHERE status = '0' OR status='1' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }     
}
public function searchdata($search)
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_products` WHERE pdt_name LIKE '$search' AND status ='0' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }     
}

public function update_product($pdt_id,$pdt_name,$actual,$disc,$offer,$stock,$New,$specset,$colorset,$sizeset,$quaset,$Img1,$Img2)
{
  $stmt=$this->conn->query("UPDATE `tbl_products` SET `pdt_name`='$pdt_name',`actual_price`='$actual',`disc`='$disc',
                            `offer_price`='$offer',`description`='$specset',`new_arrival`='$New',`stock_left`='$stock',
                            `color`='$colorset',`size`='$sizeset',`quantity`='$quaset',`img1`='$Img1',`img2`='$Img2' WHERE id = '$pdt_id' ");

if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
return false;
}   
}

public function delete_pdt($pdt)
{
  $stmt=$this->conn->query("UPDATE `tbl_products` SET `status`='2' WHERE id='$pdt' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}    
}
public function get_stat($pdt)
{
  $stmt=$this->conn->query("SELECT * FROM tbl_products WHERE id ='$pdt' ");
  if ($stmt) 
  {
   $stmt=$stmt->fetch_assoc();
   return $stmt;
      
  } 
}
public function update_pdt_status($pdt,$update)
{
  $stmt=$this->conn->query("UPDATE `tbl_products` SET `status`='$update' WHERE id='$pdt' ");
     
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return true;
}else{
  return false;
}
}
public function load_orders()
{
    $stmt=$this->conn->query(" SELECT * FROM tbl_orders WHERE order_status ='0' ORDER BY dates DESC ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }     
}
public function load_accepted_orders()
{
  $stmt=$this->conn->query(" SELECT * FROM tbl_orders WHERE `order_status` IN ('1','2','3') ORDER BY dates DESC ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }   
}
public function load_completed_orders()
{
  $stmt=$this->conn->query(" SELECT * FROM tbl_orders WHERE `order_status` ='4' ORDER BY dates DESC ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }   
}
public function load_canceled_orders()
{
  $stmt=$this->conn->query(" SELECT * FROM tbl_orders WHERE `order_status` ='5' ORDER BY dates DESC ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}   
}
public function get_new_order_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_orders` WHERE `order_status`='0' ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
  }  
}
public function get_acc_order_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_orders` WHERE `order_status` IN ('1','2','3') ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
} } 
public function get_comp_order_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_orders` WHERE `order_status`='4' ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}  
}
public function get_canc_order_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_orders` WHERE `order_status`='5' ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}   
}
public function load_order_pdts($id)
{
    //SELECT tbl_orders.d_fee,tbl_orders.tax,tbl_products.pdt_name,tbl_products.img1,tbl_products.id, tbl_order_items.quantity,tbl_order_items.color,tbl_order_items.size,tbl_order_items.item_offer,tbl_order_items.disc,tbl_order_items.item_original FROM tbl_products LEFT JOIN tbl_order_items LEFT JOIN tbl_orders ON tbl_order_items.order_id = tbl_orders.id ON tbl_products.id = tbl_order_items.pdt_id WHERE tbl_order_items.order_id='1' 
    $stmt=$this->conn->query(" SELECT tbl_products.pdt_name,tbl_products.img1,tbl_products.id, tbl_order_items.quantity,tbl_order_items.color,tbl_order_items.size,tbl_order_items.item_offer,tbl_order_items.disc,tbl_order_items.item_original FROM tbl_products LEFT JOIN tbl_order_items ON tbl_products.id = tbl_order_items.pdt_id WHERE tbl_order_items.order_id='$id' ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }     
}
public function load_user($user)
{
  $stmt=$this->conn->query(" SELECT `name`,phone,email,`address`,landmark,city,`state`,pin FROM tbl_user WHERE id ='$user' ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}    
}
public function update_order_status($Oid,$Status,$date,$ps)
{
  $stmt=$this->conn->query(" UPDATE `tbl_orders` SET `order_status`='$Status',`d_expect`='$date',`pay_status`='$ps' WHERE `id`='$Oid' ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}    
}

public function update_cancel_order($Oid)
{
  $stmt=$this->conn->query(" UPDATE `tbl_orders` SET `order_status`='5' WHERE `id`='$Oid' ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}      
}
public function feed_list()
{
  $stmt=$this->conn->query(" SELECT * FROM tbl_feedback ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}   
}
public function get_feed_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_feedback` ORDER BY dates DESC");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}   
}
public function user_list()
{
  $stmt=$this->conn->query(" SELECT * FROM tbl_user ORDER BY id DESC ");
  if ($stmt) 
{
  return $stmt;
}else{
    return false;
}     
}
public function get_user_count()
{
  $stmt=$this->conn->query("SELECT COUNT(*) as total FROM `tbl_user` ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}    
}
public function get_revenue()
{
  $stmt=$this->conn->query("SELECT SUM(total) AS Total FROM tbl_orders WHERE `pay_status`='1' AND `order_status` IN ('1','2','3','4') ");
   
  if ($stmt) 
{
$stmt=$stmt->fetch_assoc();
return $stmt;
  
}     
}
public function load_web_content()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_shop_details` WHERE id = '1' ");
   
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return $stmt;
  
}     
}
}

?>
