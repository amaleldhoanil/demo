<?php
define("DB_HOST","localhost");
define("DB_USER","u497483543_zara");
define("DB_PASSWORD","2#UpB$+QtVg");
define("DB_DATABASE","u497483543_zara");
?>
