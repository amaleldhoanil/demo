<?php

session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
     //importing DB_functions
 $db = new DB_Functions();
 $Name=$_POST['sname'];

  $ImagePath =basename($_FILES['simage']['name']);
  $ServerURL ="img/gallery/$ImagePath";
   
  
$target_dir = "../img/gallery/";
$target_file = $target_dir . basename($_FILES['simage']['name']);
 
       if(move_uploaded_file($_FILES["simage"]["tmp_name"], $target_file) && $db->add_gallery($ServerURL,$Name))
     {
     $error = "New  Image Added successfully!";
                $_SESSION["error"] = $error;
                 $_SESSION['start'] = time();
                  $_SESSION['expire'] = $_SESSION['start'] + 5;
     header("location:gallery.php");
     } 
     else 
        {
             $error = "Please try again after sometime"; 
                $_SESSION["error"] = $error;
                 $_SESSION['start'] = time();
                  $_SESSION['expire'] = $_SESSION['start'] + 5;
     header("location: gallery.php");
        } 
   
 
}
 
 
 

?>