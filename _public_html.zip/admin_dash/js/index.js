// $(window).on('scroll load', function(event) {
//     /*if ($(this).scrollTop() > $('.rev_slider').offset().top + 100) {*/
//     if ($(this).scrollTop() > 300) {
//         $('.menu-bar').addClass('sticky');
//         $('.navbar-brand img').css({"height":"50px"});
//
//
//     } else {
//         $('.menu-bar').removeClass('sticky');
//         $('.navbar-brand img').css({"height":"55px"});
//     };
// });

   var owl = $('.owl-slider');
    owl.owlCarousel({
        autoplay: true,
        autoplayTimeout:10000,
        items:1,
        loop: true,
        dots: true,

        merge:true,
        mergeFit:false,
        nav:true,
        navText: [" <i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
        navClass: ['owl-prev', 'owl-next'],
        // responsive : {
        //   // breakpoint from 0 up
        //   0 : {
        //     nav: true,
        //
        //   },
        //
        //   // breakpoint from 520 up
        //   480 : {
        //       nav:true,
        //
        //   },
        //   768:
        //   {
        //     nav: false,
        //   }
        //
        // }

    });


      //
      // var owl = $('.owl-slidr5');
      //  owl.owlCarousel({
      //    autoplay: true,
      //    autoplayTimeout:3000,
      //    autoHeight:false,
      //    autoWidth:false,
      //    loop: true,
      //    items:3,
      //    dots: false,
      //    margin: 0,
      //    merge:true,
      //    mergeFit:false,
      //    nav: false,
      //    navText: [" <i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      //    navClass: ['owl-prev', 'owl-next'],
      //    responsive : {
      //      // breakpoint from 0 up
      //      0 : {
      //        items: 1,
      //        dots: true,
      //      },
      //      // breakpoint from 520 up
      //      520 : {
      //        items: 2,
      //
      //      },
      //      768:
      //      {
      //        items:3
      //      }
      //    }
      //
      //  });
      $(document).ready(function(){
        $("#product_search").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#product_list tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
      });