/**
 *
 * ---------------------------------------------------------------------------
 *
 * Template Name:alphaexpression
 * Template URL: http://www.alphaexpression.com/
 * Description:
 *
 * ---------------------------------------------------------------------------
 *
 */


/*  ==================================
 *           js content
 *    ==================================
 *
 *
 *  ================================== */



jQuery(document).ready(function($) {
    "use-strict";

 setInterval("animadd()", 2000);
 setInterval("animrem()", 6000);

});



  function animadd() {

   $(".anim1").addClass("anim3");
   $(".anim2").addClass("anim4");

   // setTimeout(function() {
   //
   // }, 7000, );
 }
 function animrem() {
   $(".anim1").removeClass("anim3");
   $(".anim2").removeClass("anim4");
 }


 function readURL1(input) {
   if (input.files && input.files[0]) {
     var reader = new FileReader();

     reader.onload = function(e) {
       $('#pimage_1').attr('src', e.target.result);
     }
     

     reader.readAsDataURL(input.files[0]);
   }
 }

 function readURL2(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#pimage_2').attr('src', e.target.result);
    }
    

    reader.readAsDataURL(input.files[0]);
  }
}
function readURL3(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#pimage_3').attr('src', e.target.result);
    }
    

    reader.readAsDataURL(input.files[0]);
  }
}
function readURL4(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#pimage_4').attr('src', e.target.result);
    }
    

    reader.readAsDataURL(input.files[0]);
  }
}

 $("#pimagein_1").change(function() {
   readURL1(this);
 });
 $("#pimagein_2").change(function() {
  readURL2(this);
});
$("#pimagein_3").change(function() {
  readURL3(this);
});
$("#pimagein_4").change(function() {
  readURL4(this);
});


// dynamic input add

$(document).ready(function(){
  var maxField = 50; //Input fields increment limitation
  var caaddButton = $('.ca_add_button')
  var psaddButton = $('.ps_add_button'); //Add button selector
  var coloraddButton = $('.color_add_button'); //Add button selector
  var sizeaddButton = $('.size_add_button');
  var quantaddButton = $('.quant_add_button'); //Add button selector
  var pswrapper = $('.ps_field_wrapper'); //Input field wrapper
  var cawrapper = $('.ca_field_wrapper');
  var colorwrapper = $('.color_field_wrapper'); //Input field wrapper
  var sizewrapper = $('.size_field_wrapper');
  var quantwrapper = $('.quant_field_wrapper'); //Input field wrapper
  var cafieldHTML = '<div class="input-group  mb-2"><input id="ca1" type="text" class="form-control"  name="cap_field_name[]" required><div class="input-group-append  ca_remove_button" ><button class="btn btn-outline-secondary" type="button">Remove</button></div></div>'; //New input field html
  var colorfieldHTML = '<div class="input-group  mb-2"><input id="field1" type="text" class="form-control"  name="color_field_name[]" required><div class="input-group-append  color_remove_button" ><button class="btn btn-outline-secondary" type="button">Remove</button></div></div>'; //New input field html 
  var psfieldHTML = '<div class="input-group  mb-2"><input id="field1" type="text" class="form-control"  name="ps_field_name[]" required><div class="input-group-append  ps_remove_button" ><button class="btn btn-outline-secondary" type="button">Remove</button></div></div>'; //New input field html 
  var sizefieldHTML = '<div class="input-group  mb-2"><input id="field1" type="text" class="form-control"   name="size_field_name[]" required><div class="input-group-append  size_remove_button" ><button class="btn btn-outline-secondary" type="button">Remove</button></div></div>'; //New input field html 
  var quantfieldHTML = '<div class="input-group  mb-2"><input id="field1" type="text" class="form-control"   name="quant_field_name[]" required><div class="input-group-append  quant_remove_button" ><button class="btn btn-outline-secondary" type="button">Remove</button></div></div>'; //New input field html 
  var x = 1; //Initial field counter is 1



    //Once add button is clicked
    $(quantaddButton).click(function(){
      //Check maximum number of input fields
      if(x < maxField){ 
          x++; //Increment field counter
          $(quantwrapper).append(quantfieldHTML); //Add field html
      }
  });

  
  //Once remove button is clicked
  $(quantwrapper).on('click', '.quant_remove_button', function(e){
      e.preventDefault();
      $(this).parent('div').remove(); //Remove field html
      x--; //Decrement field counter
  });

  
  //Once add button is clicked
  $(psaddButton).click(function(){
      //Check maximum number of input fields
      if(x < maxField){ 
          x++; //Increment field counter
          $(pswrapper).append(psfieldHTML); //Add field html
      }
  });

  
  //Once remove button is clicked
  $(pswrapper).on('click', '.ps_remove_button', function(e){
      e.preventDefault();
      $(this).parent('div').remove(); //Remove field html
      x--; //Decrement field counter
  });


    //Once add button is clicked
    $(caaddButton).click(function(){
      //Check maximum number of input fields
      if(x < maxField){ 
          x++; //Increment field counter
          $(cawrapper).append(cafieldHTML); //Add field html
      }
  });
  
  
  //Once remove button is clicked
  $(cawrapper).on('click', '.ca_remove_button', function(e){
      e.preventDefault();
      $(this).parent('div').remove(); //Remove field html
      x--; //Decrement field counter
  });



    //Once add button is clicked
    $(coloraddButton).click(function(){
      //Check maximum number of input fields
      if(x < maxField){ 
          x++; //Increment field counter
          $(colorwrapper).append(colorfieldHTML); //Add field html
      }
  });
  
  //Once remove button is clicked
  $(colorwrapper).on('click', '.color_remove_button', function(e){
      e.preventDefault();
      $(this).parent('div').remove(); //Remove field html
      x--; //Decrement field counter
  });


  //Once add button is clicked
  $(sizeaddButton).click(function(){
    //Check maximum number of input fields
    if(x < maxField){ 
        x++; //Increment field counter
        $(sizewrapper).append(sizefieldHTML); //Add field html
    }
});

//Once remove button is clicked
$(sizewrapper).on('click', '.size_remove_button', function(e){
    e.preventDefault();
    $(this).parent('div').remove(); //Remove field html
    x--; //Decrement field counter
});


});


// location search

function bingMapsReady() {
  Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
    callback: onLoad,
    errorCallback: logError,
    credentials: 'Ap12Gwv9esg5iXgfAh5Ehlbf36MZ-O8051Sl66Zm6glGwq7PSaaKgGPpcOUEGICy'
  });

  function onLoad() {
    var options = { maxResults: 8 };
    initAutosuggestControl(options, "searchBox", "searchBoxContainer");
    initAutosuggestControl2(options, "searchBox2", "searchBoxContainer2");
  }
}

function initAutosuggestControl(
  options,
  suggestionBoxId,
  suggestionContainerId
) {
  var manager = new Microsoft.Maps.AutosuggestManager(options);
  manager.attachAutosuggest(
    "#" + suggestionBoxId,
    "#" + suggestionContainerId,
    selectedSuggestion
  );

  function selectedSuggestion(suggestionResult) {
    document.getElementById(suggestionBoxId).innerHTML =
      suggestionResult.formattedSuggestion;
  }
}
function initAutosuggestControl2(
  options,
  suggestionBoxId,
  suggestionContainerId
) {
  var manager = new Microsoft.Maps.AutosuggestManager(options);
  manager.attachAutosuggest(
    "#" + suggestionBoxId,
    "#" + suggestionContainerId,
    selectedSuggestion
  );

  function selectedSuggestion(suggestionResult) {
    document.getElementById(suggestionBoxId).innerHTML =
      suggestionResult.formattedSuggestion;
  }
}


function logError(message) {
  console.log(message);
}

// on off toggle


$(".onoff").click(function (event) {
  $(this).text(function(i, text){
      return text === "on" ? "off" : "on";

      
      
  })
  let gethref = $(this).attr("href")
  event.preventDefault();
  $.ajax({
  url: gethref, 
  success: function(result){
      
     // alert(result)
  }});
//   $(this).toggleClass(function(i, col){
//     return col === "btn-danger"  ? "btn-danger" : "btn-success";
    
// })
$( this ).toggleClass(function() {
  if ( $( this ).is( ".btn-danger" ) ) {
    $( this ).removeClass( "btn-danger" );
    return "btn-success";
  } else {
    $( this ).removeClass( "btn-success" );
    return "btn-danger";
  }
})
});

$(document).ready(function() {

  let onoff = [];
  $(".onoff").each(function() 
  { 
    onoff.push($(this).attr("id")) 
  });
  
  
  onoff.forEach(function(arrdata) {
   
     for (let i = 0; i < arrdata.length; i++) {
       
      // 
      
      if ($('#'+ arrdata).text() == "off") {
      
        $('#'+ arrdata).addClass("btn-success")
        $('#'+ arrdata).removeClass("btn-danger")
        }
        else {
          $('#'+ arrdata).addClass("btn-danger")
          $('#'+ arrdata).removeClass("btn-success")
         
      
      
    }
       
     }
      

  });
    // $( ".onoff" ).each(function(index) {

    //   for (let i = 0; i <= index; i++) {

    //     if( $( this ).text() == "off" ){
    //       ($(this).addClass("btn-success"))
    //       ($(this).removeClass("btn-danger"))
    //     }
    //     else{
    //       ($(this).addClass("btn-danger"))
    //         ($(this).removeClass("btn-success"))
    //     }
        
    //   }
     
    
    
  });


$(document).ready(function($) {
  
   setTimeout(() => {
     $("#snackbar").removeClass("show");
   }, 3000);

});

// form validation
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();



// category input check
$(document).ready(function () {

    $("#size").hide();
    $("#col").hide();
    $("#quant").hide()
    var cattxt = $("#cc").text();
    
  $("#inputcat").change(function() {
    $("#field2, #field3, #field4").removeAttr('required',false);
    $("#size").hide();
    $("#col").hide();
    $("#quant").hide();
  
  var catin = $(this).val();
  
  
  if (catin == 'Grocery') {
   
    $("#quant").show(function () {
      $("#field4").attr('required',true)
    })
    
  }
  else if (catin == 'Mobiles') {
    
    $("#col").show(function () {
      $("#field2").attr('required',true)
    })
    
    
  }
  else if (catin == 'Fashion') {
    $("#col").show(function () {
      $("#field2").attr('required',true)
    })
    $("#size").show(function () {
      $("#field3").attr('required',true)
    })
  }
  else if (catin == 'Electronics') {
    
    
    
  }
  else if (catin == 'Home') {
    $("#col").show(function () {
      $("#field2").attr('required',true)
    })
    
  }
  else if ((catin == 'Choose Category')||(cattxt == 'Choose Category')) {
    $("#size").hide();
    $("#col").hide();
    $("#quant").hide();
  }
  else {
    $("#col").show(function () {
      $("#field2").attr('required',true)
    })
    $("#size").show(function () {
      $("#field3").attr('required',true)
    })
  }
})
})

$('input:radio[name=schk]').change(function() {
   status = $(this).val()
  });
$('.acco').click(function(event){  
  event.preventDefault();
  var date = $(this).parents('.modal').find('.edd').val();
  var oid = $(this).parents('.modal').find('.oid').val();
  var ps = $(this).parents('.modal').find('.ps').val();
  
  
  if(date != '' && status != '')  
  {  
       $.ajax({  
            url:"./file_admin_accept_order.php",  
            method:"POST",  
            data: {date:date,status:status,oid:oid,ps:ps},  
            success:function(data)  {
               if(data == 1){
                 location.reload();
               }

            }  
       });  
  }  
  else  
  {  
       alert("Please enter a valid Input");  
  }  
}); 
$('.crem').click(function(event){  
  event.preventDefault();
  
  var gethref = $(this).attr('href') 
  
       $.ajax({  
            url: gethref,
            success:function(data)  
            {   
            //  alert(data)
              
              if (data == '1') {
                
               location.reload()
              
              } 
               
             
                
            }  
       });     
  
});