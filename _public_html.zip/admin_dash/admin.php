<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $cat_count=$db->get_catcount();
  $pdt_count=$db->get_pdt_count();
  $new_o_count=$db->get_new_order_count();
  $acc_o_count=$db->get_acc_order_count();
  $comp_o_count=$db->get_comp_order_count();
  $canc_o_count=$db->get_canc_order_count();
  $feed_count=$db->get_feed_count();
  $user_count=$db->get_user_count();
  $revenue=$db->get_revenue();
  $details=$db->load_web_content();
  
           $i = 1; 
           while ($row = mysqli_fetch_array($details)) { 
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta http-equiv="refresh" content="120">
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<script src="https://kit.fontawesome.com/2c3550df7e.js" crossorigin="anonymous"></script>
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body class="bgcolor">
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
      <?php include 'menubar.php'?>
      <section class="section-padding dashboard">
      <div class="container">
        <!-- Dashboard row one -->
        <!-- Small boxes (Stat box) -->
        <div class="row">
        <div class="col-md-12 ">
                <h5>Dashboard</h5>
              </div>
          <!-- <div class="col-md-3  ">
           
            <div class="small-box bg-info in">
              <div class="inner">
                <h3 class="in"><?php  echo $user_count['total'];?></h3>
                <p class="padings">Users</p>
              </div>
              <div class="icon">
                <i class="fas fa-user-friends"></i>
              </div>
              <a href="user_list.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div> -->

         
          <!-- ./col -->
          <div class="col-md-3  ">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php  echo $feed_count['total'];?></h3>
                <p class="padings">Enquiries</p>
              </div>
              <div class="icon">
                <i class="fas fa-comments"></i>
              </div>
              <a href="feedback.php" class="small-box-footer text-dark">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-md-3  ">
            <!-- small box -->
            <div class="small-box bg-danger gn">
              <div class="inner">
                <h3 class="gn">+</h3>
                <p class="padings">Add Website Details</p>
              </div>
              <div class="icon">
                <i class="fas fa-store-alt"></i>
              </div>
              <a href="add_shop_details.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          </div>
<!-- Dashboard row 2 -->
<!-- <div class="row">
        <div class="col-md-12 ">
                <h5>Orders</h5>
              </div>
          <div class="col-md-3  ">
            <div class="small-box bg-dark in">
              <div class="inner">
                <h3 class="in"><?php  echo $new_o_count['total'];?></h3>
                <p class="padings">New Orders</p>
              </div>
              <div class="icon">
                <i class="fas fa-shopping-cart"></i>
              </div>
              <a href="new_order.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
      
        <div class="col-md-3  ">
           
            <div class="small-box in" style="background-color:Teal;">
              <div class="inner">
                <h3 class="in"><?php  echo $acc_o_count['total'];?></h3>
                <p class="padings">Pending Orders</p>
              </div>
              <div class="icon">
                <i class="fas fa-shopping-bag"></i>
              </div>
              <a href="pending_orders.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
         
          <div class="col-md-3  ">
            
            <div class="small-box bg-danger gn">
              <div class="inner">
                <h3 class="gn"><?php  echo $comp_o_count['total'];?></h3>
                <p class="padings">Completed Orders</p>
              </div>
              <div class="icon">
                <i class="fas fa-shipping-fast"></i>
              </div>
              <a href="completed_order.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-md-3  ">
           
            <div class="small-box gn"style="background-color:Blue;">
              <div class="inner">
                <h3 class="gn"><?php  echo $canc_o_count['total'];?></h3>
                <p class="padings">Canceled Orders</p>
              </div>
              <div class="icon">
                <i class="fas fa-shopping-basket"></i>
              </div>
              <a href="canceled_orders.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          </div> -->
          <!-- dashboard row 3 -->
          <!-- <div class="row">
        <div class="col-md-12 ">
                <h5>Products</h5>
              </div>
          <div class="col-md-3  ">
             small box 
            <div class="small-box bg-success in">
              <div class="inner">
                <h3 class="in"><?php  echo $cat_count['total'];?></h3>
                <p class="padings">Categories</p>
              </div>
              <div class="icon">
                <i class="fas fa-tags"></i>
              </div>
              <a href="add_categories.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
        
        <div class="col-md-3  ">
          
            <div class="small-box bg-info in">
              <div class="inner">
                <h3 class="in"><?php  echo $pdt_count['total'];?></h3>
                <p class="padings">Products</p>
              </div>
              <div class="icon">
                <i class="fas fa-percent"></i>
              </div>
              <a href="products.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
         
          <div class="col-md-3  ">
           
            <div class="small-box bg-secondary gn">
              <div class="inner">
                <h3 class="gn">+</h3>
                <p class="padings">Add Products</p>
              </div>
              <div class="icon">
                <i class="fas fa-user-tag"></i>
              </div>
              <a href="addproduct.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          </div> -->
<!-- Dashboard row 4 -->
<div class="row">
        <div class="col-md-12 ">
                <h5>Website Contents</h5>
              </div>
          <div class="col-md-3  ">
            <!-- small box -->
            <div class="small-box bg-dark in">
              <div class="inner">
                <h3 class="in">+</h3>
                <p class="padings">Add Slides</p>
              </div>
              <div class="icon">
                <i class="fas fa-image"></i>
              </div>
              <a href="addslide.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
       
        <!-- <div class="col-md-3  ">
           
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>+</h3>
                <p class="padings">Add Videos</p>
              </div>
              <div class="icon">
                <i class="fas fa-camera-retro"></i>
              </div>
              <a href="add_features.php" class="small-box-footer text-dark">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div> -->
          <div class="col-md-3  ">
             <!-- small box  -->
            <div class="small-box bg-success in">
              <div class="inner">
                <h3 class="in"><?php  echo $cat_count['total'];?></h3>
                <p class="padings">Add Services</p>
              </div>
              <div class="icon">
                <i class="fas fa-tags"></i>
              </div>
              <a href="add_categories.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-md-3  ">
           
           <div class="small-box bg-info gn">
             <div class="inner">
               <h3 class="gn">+</h3>
               <p class="padings">Add Gallery</p>
             </div>
             <div class="icon">
               <i class="fas fa-camera-retro"></i>
             </div>
             <a href="gallery.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
           </div>
         </div>
          <!-- ./col -->
         
          <!-- <div class="col-md-3  ">
            <div class="small-box  gn" style="background-color:Purple;">
              <div class="inner">
                <h3 class="gn">+</h3>
                <p class="padings">Add Delivery Locations</p>
              </div>
              <div class="icon">
                <i class="fas fa-search-location"></i>
              </div>
              <a href="add_delivery_location.php" class="small-box-footer">View <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div> -->
          </div>

          </div>
</section>

    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
