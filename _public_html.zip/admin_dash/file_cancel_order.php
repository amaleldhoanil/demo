<?php 
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
    $db = new DB_Functions();
    $Oid=$_GET['id'];


    $r=$db->update_cancel_order($Oid);
    if($r)
    {
echo "1";
    }
    else
    {
echo "0";
    }

 


?>