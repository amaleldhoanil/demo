<?php

session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='GET')
 {
     //importing DB_functions
 $db = new DB_Functions();
  $pdt=$_GET['id'];
 $result=$db->delete_pdt($pdt);

 if($result)
 {
  $error = "Product deleted successfully!";
  $_SESSION["error"] = $error;
   $_SESSION['start'] = time();
    $_SESSION['expire'] = $_SESSION['start'] + 5; 
  header("location: products.php");
 }else
 {
  $error = "Please try again after sometime"; 
  $_SESSION["error"] = $error;
   $_SESSION['start'] = time();
    $_SESSION['expire'] = $_SESSION['start'] + 5;
 header("location: products.php");
 }
  
  }
 
 
 

?>