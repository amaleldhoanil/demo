<?php
session_start();
ini_set('display_errors', 1);

//include('../php/admin_login.php'); // Includes Login Script
if(isset($_SESSION['expire']))
{
  $_SESSION['expire']="";

if(isset($_SESSION['login_admin']))
{
header("location: admin.php"); // Redirecting To Profile Page
}else {
        $now = time(); // Checking the time now when home page starts.

        if ($now > $_SESSION['expire']) {
           // session_destroy();
           unset($_SESSION["error"]);
           
        }
}
}
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$details=$db->load_web_content();
  
           $i = 1; 
           while ($row = mysqli_fetch_array($details)) { 
?> 
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->


</head>
<?php
          $i++; 
	}
?>
<body class="bgcolor">
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
   
      <section class="section-padding  newarr">
        <div class="container">
          <div class="row">
            <!-- <div class="col-md-12 text-center">
              <h1 class="section-title">NEW ARRIVALS</h1>
            </div> -->


            <div class="col-8 col-md-4 no-padding login" style="margin:auto">
             
              <h3>Admin Login</h3>
              <form action="admin_login.php"method="POST">
                <div class="form-group" >
                  <input class="form-control" type="text" placeholder="Username" name="auser" required>

                  </div>
                  <div class="form-group">
                    <input class="form-control" type="password" placeholder="Password" name="apass" required>

                    </div>
                    <button type="submit">Login</button>
              </form>
              <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<span class='text-danger'>$error</span>";
                    }
                ?> 
            </div>


          </div>
        </div>
      </section>
    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
