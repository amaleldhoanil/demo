<?php

session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
   
     //importing DB_functions
 $db = new DB_Functions();
$Loc=$_POST['location'];
$Fee=$_POST['dfee'];
$Pin=$_POST['pincode'];
 
$result=$db->add_deli_loc($Loc,$Fee,$Pin);
if($result)
{
    $error = "New  Delivery Location Added successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: add_delivery_location.php");
}
else
{
    $error = "Please try again after sometime"; 
    $_SESSION["error"] = $error;
     $_SESSION['start'] = time();
      $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: add_delivery_location.php");   
}


}
 
 
 

?>