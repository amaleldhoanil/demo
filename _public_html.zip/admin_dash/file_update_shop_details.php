 <?php
 ini_set('display_errors', 1);
 ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
// if($_SERVER['REQUEST_METHOD']=='POST')
 //{
 $db = new DB_Functions();
  $shop_name =$_POST['brand_name'];
  $shop_phone=$_POST['mobile'];
  $shop_email=$_POST['email'];
  $shop_address=$_POST['address'];
  $shop_city=$_POST['city'];
  $shop_state=$_POST['state'];
  $shop_country=$_POST['country'];
  $shop_pin=$_POST['pincode'];
  $shop_color1=$_POST['color_1'];
  $shop_color2=$_POST['color_2'];
  $old_logo=$_POST['old'];
  
  $Tax=$_POST['tax'];
  $Fb=$_POST['fblink'];
  $Insta=$_POST['instalink'];
  $Twi=$_POST['twitterlink'];
  $Y=$_POST['yblink'];
  $Play=$_POST['playlink'];
  $Map=$_POST['gmaplink'];
  $about=$_POST['aboutus'];
  $old_small=$_POST['old_small'];
 if (basename($_FILES['logo']['name'])==null && basename($_FILES['small_logo']['name'])==null)//1
 {
   $s=$db->update_shop($shop_name,$shop_phone, $shop_email,$shop_address,$shop_city,$shop_state,$shop_country,$shop_pin,$shop_color1,$shop_color2,$old_logo,$Tax,$Fb,$Insta,$Twi,$Y,$Play,$Map,$about,$old_small);
   if($s)
   {
      $error = "Website Details updated successfully!";
      $_SESSION["error"] = $error;
      $_SESSION['start'] = time();
      $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:add_shop_details.php");
      
   }
   else
   {
      $error = "Please try again after sometime";
      $_SESSION["error"] = $error;
      $_SESSION['start'] = time();
      $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:add_shop_details.php");
   }
 }else if(basename($_FILES['logo']['name']) && basename($_FILES['small_logo']['name'])==null)//2
 {
   $ImagePath =basename($_FILES['logo']['name']);
   $ServerURL ="img/logo/$ImagePath";
    
   
 $target_dir = "../img/logo/";
 $target_file = $target_dir . basename($_FILES['logo']['name']);
  
        if(move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file) && $db->update_shop($shop_name,$shop_phone, $shop_email,$shop_address,$shop_city,$shop_state,$shop_country,$shop_pin,$shop_color1,$shop_color2,$ServerURL,$Tax,$Fb,$Insta,$Twi,$Y,$Play,$Map,$about,$old_small))
      {
      $error = "Website Details updated successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:add_shop_details.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: add_shop_details.php");
         } 
    
 }else if(basename($_FILES['logo']['name'])== null && basename($_FILES['small_logo']['name']))//3
 {
   $ImagePath1 =basename($_FILES['small_logo']['name']);
   $ServerURL1 ="img/logo/$ImagePath1";
    
   
 $target_dir1 = "../img/logo/";
 $target_file1 = $target_dir1 . basename($_FILES['small_logo']['name']);
  
        if(move_uploaded_file($_FILES["small_logo"]["tmp_name"], $target_file1) && $db->update_shop($shop_name,$shop_phone, $shop_email,$shop_address,$shop_city,$shop_state,$shop_country,$shop_pin,$shop_color1,$shop_color2,$old_logo,$Tax,$Fb,$Insta,$Twi,$Y,$Play,$Map,$about,$ServerURL1))
      {
      $error = "Website Details updated successfully!";
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location:add_shop_details.php");
      } 
      else 
         {
              $error = "Please try again after sometime"; 
                 $_SESSION["error"] = $error;
                  $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + 5;
      header("location: add_shop_details.php");
         } 
 } else if (basename($_FILES['logo']['name'])&& basename($_FILES['small_logo']['name']))//4

 {
   $ImagePath =basename($_FILES['logo']['name']);
   $ServerURL ="img/logo/$ImagePath";
    
   
 $target_dir = "../img/logo/";
 $target_file = $target_dir . basename($_FILES['logo']['name']);

 $ImagePath1 =basename($_FILES['small_logo']['name']);
 $ServerURL1 ="img/logo/$ImagePath1";
  
 
$target_dir1 = "../img/logo/";
$target_file1 = $target_dir1 . basename($_FILES['small_logo']['name']);


if(move_uploaded_file($_FILES["small_logo"]["tmp_name"], $target_file1) && move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file) && $db->update_shop($shop_name,$shop_phone, $shop_email,$shop_address,$shop_city,$shop_state,$shop_country,$shop_pin,$shop_color1,$shop_color2,$ServerURL,$Tax,$Fb,$Insta,$Twi,$Y,$Play,$Map,$about,$ServerURL1))
{
$error = "Website Details updated successfully!";
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location:add_shop_details.php");
} 
else 
   {
        $error = "Please try again after sometime"; 
           $_SESSION["error"] = $error;
            $_SESSION['start'] = time();
             $_SESSION['expire'] = $_SESSION['start'] + 5;
header("location: add_shop_details.php");
   } 


 }


 
 
 //}

 

?>