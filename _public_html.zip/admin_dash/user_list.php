<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'admin_login.php';
if(!isset($_SESSION['login_admin']))
{
 header("location:index.php");
}
  require_once 'include/DB_Functions.php';
  $db = new DB_Functions();
  $Category=$db->user_list();
  $details=$db->load_web_content();
  $i = 1; 
  while ($row = mysqli_fetch_array($details)) { 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- ========== PAGE TITLE ========== -->
<title><?php echo $row['shop_name'];?></title>
<!-- ========== META TAGS ========== -->
<meta charset="utf-8">
<meta name="robots" content="all, index, follow" />
 <!-- ========================== Mobile Specific Metas ======================== -->
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0, user-scalable=0">
<!-- =========================== Favicon ============================= -->
<link href="../<?php echo $row['small_logo'];?>" rel="shortcut icon" type="image/png">
<link href="../<?php echo $row['small_logo'];?>" rel="icon" type="image/png">
<!-- ======================= CSS LINES =============================== -->
<link rel="stylesheet" href=" css/bootstrap.min.css">
<!-- ====================== Plugin CSS =============================== -->
<link rel="stylesheet" href=" css/owl.carousel.min.css">
<link rel="stylesheet" href=" css/owl.theme.default.min.css">
<link rel="stylesheet" href=" css/bootstrap-select.css">
<link rel="stylesheet" href=" css/anim.css">
<!-- ====================== Custom CSS =============================== -->
<link rel="stylesheet" href=" css/style.css">
<!-- ==================== FONT-AWESOME =============================== -->
<link rel="stylesheet" href=" fonts/font-awesome/css/font-awesome.min.css">
<!-- ========== NEED TO USING GOOGLE WEBFONT ========== -->

</head>
<?php
          $i++; 
	}
?>
<body>
  <!--==================================== Wrapper Start ===================================-->
    <div class="Wrapper">
    <?php include 'menubar.php'?>
      <div class="container-fluid">
        <div class="row">
        
          <div class="col-md-12">
            <section class="section-padding dashboard">
              <div class="container">
                <div class="row">
                  <div class="col-md-12">
                    <h5>Registered Users</h5>

                  </div>
                  <div class="col-md-12">
                    <table class="table table-responsive">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Customer Name</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Email</th>
                          <th scope="col">Address</th>
                          <th scope="col">Landmark</th>
                          <th scope="col">City</th>
                          <th scope="col">Emirate</th>
                          <th scope="col">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
					$i = 1; 
          while ($row = mysqli_fetch_array($Category)) { ?>
                        <tr>
                          <th scope="row"><?php echo $i;?></th>
                          <td><?php echo $row['name'];?> <?php echo $row['lname'];?></td>
                          <td><?php echo $row['phone'];?></td>
                          <td><?php echo $row['email'];?></td>
                          <td><?php echo $row['address'];?></td>
                          <td><?php echo $row['landmark'];?></td>
                          <td><?php echo $row['city'];?></td>
                          <td><?php echo $row['state'];?></td>
                          <td><?php echo $row['d_time'];?></td>
                         
                        </tr>

                      <?php
          $i++; 
	}
?>


                        
                      </tbody>
                      
                    </table>
                    
                  </div>
                 
                  
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>




    </div><!-- end Wrapper -->
    <!-- ================================ SCRIPT LINES =============================== -->
    <script src=" js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src=" js/bootstrap.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src=" js/plugins.js"></script>
    <!-- =============================== owl-carousel Script ========================= -->
    <script src=" js/index.js"></script>
    <!-- =================================== Custom Js =============================== -->
    <script src=" js/script.js"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->


</body>
<!-- end Body -->

</html>
<!-- end Html -->
