 <?php
session_start(); // Starting Session  
require_once 'include/DB_Functions.php';
if(!isset($_SESSION['login_admin']))
{
 header("location: index.php"); // Redirecting To Profile Page
}
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
 $db = new DB_Functions();
  $Name =$_POST['catname'];
  $des=$_POST['des'];
  $ImagePath =basename($_FILES['catimage']['name']);
  $ServerURL ="img/category/$ImagePath";
   
  
$target_dir = "../img/category/";
$target_file = $target_dir . basename($_FILES['catimage']['name']);
 
       if(move_uploaded_file($_FILES["catimage"]["tmp_name"], $target_file) && $db->add_categories($ServerURL,$Name,$des))
     {
     $error = "New Service added successfully!";
                $_SESSION["error"] = $error;
                 $_SESSION['start'] = time();
                  $_SESSION['expire'] = $_SESSION['start'] + 5;
     header("location:add_categories.php");
     } 
     else 
        {
             $error = "Please try again after sometime"; 
                $_SESSION["error"] = $error;
                 $_SESSION['start'] = time();
                  $_SESSION['expire'] = $_SESSION['start'] + 5;
     header("location: add_categories.php");
        } 
   
 
 }

 

?>