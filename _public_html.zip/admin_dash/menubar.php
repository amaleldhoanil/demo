<?php 
$url = $_SERVER['REQUEST_URI'];
$key = 'menubar';
if (strpos($url, $key) == true) {
  header("location: index.php");
}
require_once 'include/DB_Functions.php';
 $db = new DB_Functions();
 $details=$db->load_web_content();
 
					$i = 1; 
          while ($row = mysqli_fetch_array($details)) { 
?>
<header>

        <div class="menu-bar">
          <div class="container">
               <div class="row">
                 <div class="col-md-12 no-padding">
                   <nav class="navbar navbar-expand-lg navbar-light">
                     <a class="navbar-brand" title="<?php echo $row['shop_name'];?>" href="admin.php"><img id="pimage_1" src="../<?php echo $row['logo'];?>" alt=""></a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                       <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarNavDropdown">
                       <ul class="navbar-nav">
                         <li class="nav-item ">
                           <a class="nav-link" href="logout.php">Logout</a>
                         </li>
                       </ul>
                     </div>
                   </nav>
                 </div>

               </div>
             </div>
        </div>
      </header>
      <?php
          $i++; 
	}
?>