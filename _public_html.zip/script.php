    <!-- ================================ SCRIPT LINES =============================== -->
    <script src="js/jquery.js"></script>
    <!-- ========================= Bootstrap Core JavaScript ========================= -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- ============================ All Included JavaScript ======================== -->
    <script src="js/plugins.js"></script>

   
    <!-- =================================== Custom Js =============================== -->
    <script src="js/index.js?3"></script>
    
    <script src="js/script.js?3"></script>
    <!-- ================================ INLINE SCRIPT ============================== -->