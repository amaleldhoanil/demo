-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2023 at 03:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_zara`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `admin_id` varchar(200) NOT NULL,
  `admin_pass` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `admin_id`, `admin_pass`, `status`) VALUES
(1, '9961684050', '$2y$10$IWOAXhUZ8bfeB2rqUUt2SOzvRWaI1wEpV.PMCKwtGdD4dy0WxbUzG', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(200) NOT NULL,
  `des` varchar(20000) DEFAULT NULL,
  `cat_url` varchar(200) NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `cat_name`, `des`, `cat_url`, `status`) VALUES
(1, 'Academic Tutoring', 'According to recent Researches it is revealed that human beings are, able to focus on a task or\r\nobject for a few seconds. The average human has an attention span of justÂ 8.25 seconds so its\r\ntechnically not possible to concentrate on a subject for hours in your schools therefore we will\r\nhelp to cover all the portions and help your kids to get their homework done for that we have\r\nexpert tutors who will provide exception support to your kids. We implement some strategic\r\nmoves to get the attention of kids and to make the class more entertained also we contrive\r\neffective methodology to improve the grasping power of kids.', 'img/category/zara1.jpg', '0'),
(2, 'Skill Development', 'We would spotlessly frame our kids and youth for tomorrows and extend our support by\r\nserving them with the proper guidance, infrastructure, opportunities, and encouragement that\r\nhelp them achieve their ambitions. Our society demands education and the major part of a\r\nhuman journey is skill development. If you are not capable to explore your skills then there is no\r\nuse with your education so far, we help our kids to develop it from their core. Specifically, we\r\nare composed with professional teams who can guide you to achieve your dreams and to\r\nempower your skills.', 'img/category/zara3.jpg ', '0'),
(3, 'Holistic Learning', 'Holistic Learning concisely allows students to create a bond with the subject of study. along with\r\nit we help to enhance the creative cognitive ability of students Also It helps to attain the learners\r\nto gain the factors such as emotion, psychology, and social growth, actually we prepare our\r\nstudents to overcome any hard situation by practicing this. In fact, we could say that itâ€™s a\r\nconsecrated process of controlling your body, mind and spirit in an easy way.', 'img/category/zara4.jpg ', '0'),
(4, 'One to one Student Profiling', 'By initiating the one-to-one student profiling, we just deliberatively collect some aspects of the students mainly we focus on the interests and strengths of students in both academic and other activities so that we can nurture them. We can point the stages where the students need help and support. By identifying the segments where they are weak our highly talented team will support them to make an eccentric change in it. We can assure you the best that we can provide for your student.', 'img/category/zara2.jpg ', '0'),
(5, 'Child-Parent care and Counseling for Career Development', 'The best part of a human beings life is their childhood and its mostly developed from the home\r\nitself. The things that we learn from our childhood will last forever. In spite of this we set out a\r\nteam to give proper guidance to parenting and to perceive the benefits and drawbacks of it. Our\r\nteam will take care of the parents and even children with an effective parenting methodology.\r\nWe also provide awareness to our students about the career and the importance of building a\r\ncareer. our dedicated team willÂ prepare the students to choose proper career by improving the\r\nskills and motivating them by concisely explaining the need of career in life. More over our\r\ntrained team enlighten the students to keep learn and to take impeccable decision-making\r\nmentality which brings them closer to the ideal job, skillset, and lifestyle.', 'img/category/zara5.jpg ', '0'),
(6, 'Career and Personality Development', 'We are intended to introduce an advanced scientific assessment tool for children which will help in developing the career and personalities of our children. Itâ€™s a simple procedure but it has a great impact on the developing the career and personality, in fact, itâ€™s so clear that most children are petrified and clueless while choosing a career. By some scientific strategies we will figure out for our students  to achieve a good career along with building an impeccable personalities in them. We monitor our students very keenly and spotlessly to identify the stage that they are sustaining now and will provide appropriate guidance regarding the appropriate scientific assessment also we prepare standardized tests for our students to frame a good personality. We specifically expose our students to certain assessments such as self-assessment, and peer assessment and to some surveys to perceive society to them which will help them to grab and learn more from society and by this, they will achieve good personality and an excellent career.', 'img/category/zara6.jpg   ', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_features`
--

CREATE TABLE `tbl_features` (
  `id` int(11) NOT NULL,
  `feature_name` varchar(222) NOT NULL,
  `feature_url` varchar(222) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `dates` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(120) NOT NULL,
  `slide_name` varchar(200) NOT NULL,
  `slide_url` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop_details`
--

CREATE TABLE `tbl_shop_details` (
  `id` int(10) NOT NULL,
  `shop_name` varchar(222) NOT NULL,
  `shop_phone` varchar(20) NOT NULL,
  `shop_email` varchar(222) NOT NULL,
  `shop_address` varchar(500) NOT NULL,
  `shop_city` varchar(222) NOT NULL,
  `shop_state` varchar(222) NOT NULL,
  `shop_country` varchar(222) NOT NULL,
  `shop_pin` varchar(20) NOT NULL,
  `color_1` varchar(222) NOT NULL,
  `color_2` varchar(222) NOT NULL,
  `logo` varchar(222) NOT NULL,
  `small_logo` varchar(200) NOT NULL,
  `tax` varchar(20) NOT NULL,
  `fb_link` varchar(200) NOT NULL,
  `insta_link` varchar(200) NOT NULL,
  `tw_link` varchar(200) NOT NULL,
  `y_link` varchar(200) NOT NULL,
  `play_link` varchar(200) NOT NULL,
  `map_link` varchar(1000) NOT NULL,
  `about` varchar(8000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_shop_details`
--

INSERT INTO `tbl_shop_details` (`id`, `shop_name`, `shop_phone`, `shop_email`, `shop_address`, `shop_city`, `shop_state`, `shop_country`, `shop_pin`, `color_1`, `color_2`, `logo`, `small_logo`, `tax`, `fb_link`, `insta_link`, `tw_link`, `y_link`, `play_link`, `map_link`, `about`) VALUES
(1, 'Zara International Academy', '+968 7117 4444', 'info@zarainternationalacademy.com', 'P.O.Box: 66, Postal Code: 111\r\nAl-Safat Street, Al Ghubhra, \r\nMuscat, Sultanate of Oman', ' ', ' ', ' ', ' ', '#0a1423', '#03000f', 'img/logo/zara_large.png', 'img/logo/ico.png', '0', '#', '#', '#', '#', '#', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d720.3105338578571!2d58.39640777775616!3d23.588445173379228!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e91ffbf3db282cd%3A0x8f447a3506aee8cc!2sTurkish%20Falcon%20Food%20Restaurant!5e0!3m2!1sen!2sus!4v1683449318209!5m2!1sen!2sus', 'An organization aiming towards actualising the human potential,  through specifically designed programs in the field of education, skills, creativity, entertainment and career development. Targeting to cultivate, channelize and nurture the skills deep within the student community, we bring in holistically designed highly effective programs facilitated by career counsellors, psychologists and certified skilled trainers to imbue the same as a part of academic curriculum.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(120) NOT NULL,
  `slide_name` varchar(500) NOT NULL,
  `slide_url` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `slide_name`, `slide_url`, `status`) VALUES
(1, '<h1 class=\"m-0 font-weight-bold\">Committed To <br> Learn Excellence <br> In Education</h1>   \n                         \n                       ', 'img/banner/zara2.jpg', '0'),
(2, '<h3>Start Better <br> </h3> <h2>Learning  Future<br></h2> <h3>From Here <br> </h3>', 'img/banner/zara1.jpg', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_features`
--
ALTER TABLE `tbl_features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_shop_details`
--
ALTER TABLE `tbl_shop_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_features`
--
ALTER TABLE `tbl_features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(120) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_shop_details`
--
ALTER TABLE `tbl_shop_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(120) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
