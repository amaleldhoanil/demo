/**
 *
 * ---------------------------------------------------------------------------
 *
 * Template Name:alphaexpression
 * Template URL: http://www.alphaexpression.com/
 * Description:
 *
 * ---------------------------------------------------------------------------
 *
 */


/*  ==================================
 *           js content
 *    ==================================
 *
 *
 *  ================================== */




  
$("#contact-form").on("submit",function(event){  
  event.preventDefault();
  var name = $('#name').val();  
  var email = $('#email').val();
  var phone = $('#phone').val();
  // var address = $('#addr').val();

  var msg = $('#msg').val();

  
  if(name != '' && email != '' && phone != '' && msg != '' )  
  {  
    $("#snackbar").addClass("show")
   $.ajax({  
            url:"php/send_msg.php",  
            method:"POST",  
            data: {name:name, email:email,phone:phone,msg:msg},  
            success:function(data)  
            { 
           
             
            
             
                 
                 if(data == 1)  
                 {  
                   
                  let x = document.getElementById("snackbar");
                   // Add the "show" class to DIV
                   $("#snackbar").text("Your Message Send Successfully");
                   x.className = "show";
                 
                   // After 3 seconds, remove the show class from DIV
                   setTimeout(function(){ 
                     
                     x.className = x.className.replace("show", ""); 
                   
                   }, 1000);
                   
                 }  
                 else
                 {  
                  let x = document.getElementById("snackbar");
                     // Add the "show" class to DIV
                   $("#snackbar").text("Failed to send your message");
                   x.className = "show";
                 
                   // After 3 seconds, remove the show class from DIV
                   setTimeout(function(){ 
                     
                     x.className = x.className.replace("show", ""); 
                   
                   }, 1000); 
                 } 
                 
            } 
             
       }); 
     
  }  
 
});  



//news letter
$("#news").on("submit",function(event){  
  event.preventDefault();

  var email = $('.email').val();




  
  if(email != ''  )  
  {  
   $.ajax({  
            url:"php/send_msg_news.php",  
            method:"POST",  
            data: {email:email},  
            success:function(data)  
            { 
           
               let x = document.getElementById("snackbar");
                 
                 if(data == 1)  
                 {  
                   

                   // Add the "show" class to DIV
                   $("#snackbar").text("Your Message Send Successfully");
                   x.className = "show";
                 
                   // After 3 seconds, remove the show class from DIV
                   setTimeout(function(){ 
                     
                     x.className = x.className.replace("show", ""); 
                   
                   }, 1000);
                   
                 }  
                 else
                 {  
                     // Add the "show" class to DIV
                   $("#snackbar").text("Failed to send your message");
                   x.className = "show";
                 
                   // After 3 seconds, remove the show class from DIV
                   setTimeout(function(){ 
                     
                     x.className = x.className.replace("show", ""); 
                   
                   }, 1000); 
                 } 
                 
            } 
             
       }); 
     
  }  
 
});   


  
//   $( document ).ready(function() {
//     $(".menu-top").hide();
// });

//   $(".nav-item a, .footerli li a").click(function(){  
    
//     $(".menubar").fadeOut();
//     $(".menu-top").fadeIn();

//     $(".nav-item a.active").removeClass("active");
    
      

//     $(this).addClass("active"); 
 
   
    
//   });  
  // $(".menu-top").click(function(e){
  //   e.preventDefault();
  //   $(".menubar").fadeIn();
  //   $(".menu-top").fadeOut();
  // });
//   $(".menubar").on('click','a', function(event){ 
//     event.preventDefault();
//     var o =  $( $(this).attr("href") ).offset();   
//     var sT = o.top + $(".menubar").outerHeight(true); 
//     window.scrollTo(0,sT);
//     alert(sT)
// });

// $("#about").click(function(){
//   var x = $(".menubar").offset();
//   alert("Top: " + x.top + " Left: " + x.left);
// });


$(".scatl a").click(function(event){  
  event.preventDefault();
  $(".shopcatload").addClass("animate__backInUp").css('animation-duration', '0.2s');
  setTimeout(() => {
    $(".shopcatload").removeClass("animate__backInUp");
  }, 500);
  // remove classname 'active' from all li who already has classname 'active'
  $(".scatl a.activec").removeClass("activec");
  $(".scatl a.text-white").removeClass("text-white"); 
    
  // adding classname 'active' to current click li 
  $(this).addClass("activec"); 


});


$(".more").click(function(event){  
  event.preventDefault();
window.location.href='gallery.php'
});



// form validation
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();



$(".zeroval").on("input", function() {
  if (/^0/.test(this.value)) {
    this.value = this.value.replace(/^0/, "")
    let x = document.getElementById("snackbar");
    // Add the "show" class to DIV
    $("#snackbar").text("Enter > 0");
    x.className = "show";
  
    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ 
      
      x.className = x.className.replace("show", ""); 
    
    }, 3000); 
  }
})

$(".tcalc").on("submit",function(event){  
  event.preventDefault();

  var al = $(this).find('input[name="al"]').val(); 
  var aw = $(this).find('input[name="aw"]').val(); 
  var tl = $(this).find('input[name="tl"]').val(); 
  var tw = $(this).find('input[name="tw"]').val(); 

var cthis = $(this);

  
  if(al != '' && aw != '' &&tl != '' &&tw != '')  
  {  
   $.ajax({  
            url:"php/file_tile_calculator.php",  
            method:"POST",  
            data: {al:al,aw:aw,tl:tl,tw:tw,},  
            success:function(data)  
            { 
             
              cthis.find(".ans").html(data)
           
             
                 
                
                 
            } 
             
       }); 
     
  }  
 
});   

$(".read").click(function (e) {
  e.preventDefault();
  $(this).parents('.section-padding').find('.readmore').css("height","fit-content");
  $(this).hide();
})