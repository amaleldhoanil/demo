

$(window).on('scroll load', function(event) {
   
  if ($(this).scrollTop() > 50) {

      $('.menubar').addClass('sticky');
      $('.navbar-brand img').css({"width":"250px"});



  } else {

      $('.menubar').removeClass('sticky');
      $('.navbar-brand img').css({"width":"400px"});
  };
});

$('.parent-container').magnificPopup({
delegate: 'a', // child items selector, by clicking on it popup will open
type: 'image',
gallery:{
enabled:true
}
});
  $(document).ready(function() {
    $('.newarrival').find('.owl-nav').removeClass('disabled');
    $('.newarrival').on('changed.owl.carousel', function(event) {
      $(this).find('.owl-nav').removeClass('disabled');
    });
    

    // Fakes the loading setting a timeout
      setTimeout(function() {
          $("#loader-wrapper").remove();
      }, 600);
 
  });


 var owl = $('.owl-slider');
  owl.owlCarousel({
      autoplay: true,
      autoplayTimeout:10000,
      items:1,
      loop: true,
      dots: true,

      merge:true,
      mergeFit:false,
      nav:true,
      navText: [" <i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      navClass: ['owl-prev', 'owl-next'],
      responsive : {
        // breakpoint from 0 up
        0 : {
          nav: false,
      
        },
      
        // breakpoint from 520 up
        480 : {
            nav:false,
      
        },
        768:
        {
          nav: true,
        }
      
      }

  });
  var owl = $('.owl-rating');
  owl.owlCarousel({
      autoplay: true,
      autoplayTimeout:10000,
      items:1,
      loop: true,
      dots: true,

      merge:true,
      mergeFit:false,
      nav:true,
      navText: [" <i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      navClass: ['owl-prev', 'owl-next'],
      // responsive : {
      //   // breakpoint from 0 up
      //   0 : {
      //     nav: true,
      //
      //   },
      //
      //   // breakpoint from 520 up
      //   480 : {
      //       nav:true,
      //
      //   },
      //   768:
      //   {
      //     nav: false,
      //   }
      //
      // }

  });
  var owl = $('.cat');
  owl.owlCarousel({
      autoplay: true,
      autoplayTimeout:10000,
      items:10,
      loop:true,
      dots: false,
      margin:0,
     
      merge:true,
      mergeFit:false,
      nav:false,
      navText: [" <i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
      navClass: ['owl-prev', 'owl-next'],
      responsive : {
        0: {
          items: 1
        },
        400: {
          items: 1
        },
        740: {
          items: 1
        },
        940: {
          items: 1
        }
      
       }

  });

 

  
    var owl = $('.newarrival');
     owl.owlCarousel({
       items:6,
  loop: true,
  
  margin:15,
  mouseDrag: true,
  autoplay: false,
  touchDrag: true,
  pullDrag: true,
dots:false,
  nav:false,
  navSpeed: 1000,
  navText: [" <i class='fas fa-arrow-left m-0'></i>", "<i class='fas fa-arrow-right m-0'></i>"],
  navClass: ['owl-prev', 'owl-next'],
   responsive: {
    0: {
      items: 2
    },
    400: {
      items: 2
    },
    740: {
      items: 4
    },
    940: {
      items: 4
    }
  },
     

     });

     var owl = $('.fea');
     owl.owlCarousel({
       items:4,
       loop: true,
  
  margin:0,
  mouseDrag: true,
  autoplay: true,
  touchDrag: true,
  pullDrag: true,
dots:true,
  nav:false,
  navSpeed: 3000,
  navText: ['<fa-icon class="fa" [icon]="mobile"></fa-icon>', '<fa-icon class="fa" [icon]="mobile"></fa-icon>'],
  responsive: {
    0: {
      items: 1,
    
    },
    400: {
      items: 1,
      
    },
    740: {
      items: 1
      
    },
    940: {
      items: 1
    }
  },
     

     });

     
     var owl = $('.clients');
     owl.owlCarousel({
       items:6,
  loop: true,
  
  margin:15,
  mouseDrag: true,
  autoplay: true,
  touchDrag: true,
  pullDrag: true,
dots:false,
  nav:false,
  navSpeed: 1000,
  navText: [" <i class='fas fa-arrow-left m-0'></i>", "<i class='fas fa-arrow-right m-0'></i>"],
  navClass: ['owl-prev', 'owl-next'],
   responsive: {
    0: {
      items: 2
    },
    400: {
      items: 2
    },
    740: {
      items: 3
    },
    940: {
      items: 3
    }
  },
     

     });

     var owl = $('.brands');
     owl.owlCarousel({
       items:6,
  loop: true,
  
  margin:15,
  mouseDrag: true,
  autoplay: true,
  touchDrag: true,
  pullDrag: true,
dots:false,
  nav:false,
  navSpeed: 1000,
  navText: [" <i class='fas fa-arrow-left m-0'></i>", "<i class='fas fa-arrow-right m-0'></i>"],
  navClass: ['owl-prev', 'owl-next'],
   responsive: {
    0: {
      items: 2
    },
    400: {
      items: 2
    },
    740: {
      items: 5
    },
    940: {
      items: 5
    }
  },
     

     });

     var owl = $('.scatl');
     owl.owlCarousel({
       items:7,
       loop: true,
       autoplayTimeout:9000,
  margin:5,
  autoWidth:true,
  mouseDrag: true,
  autoplay: false,
  touchDrag: true,
  pullDrag: true,
  autoWidth:true,
  dots:false,
  nav:false,
  navSpeed: 3000,
  
  responsive: {
    0: {
      items: 3,
      margin:5,
    },
    400: {
      items: 3,
      margin:5,
    },
    740: {
      items: 4,
      
    },
    940: {
      items: 5
    }
  },
     

     });

     $(function() {
         $('.lazy').lazy({
           effect: 'show',
           effectTime: 100,
           visibleOnly: true,
          delay: 2500,

         });
     });

//initiate the plugin and pass the id of the div containing gallery images
$('#img_01').ezPlus({
  gallery: 'gal1', 
  cursor: 'crosshair', 
  galleryActiveClass: 'active', 
  zoomType: 'lens',
  imageCrossfade: true,
  borderSize:1,
  responsive: true,
  
});

//pass the images to Fancybox
$('#img_01').bind('click', function (e) {
  var ez = $('#img_01').data('ezPlus');
  $.fancyboxPlus(ez.getGalleryList());
  return false;
});

$(function () {

$(".rateYo").rateYo({
  spacing   : "2px",
  starWidth: "20px",
  normalFill: "#A0A0A0",
  fullStar: true
});

});


// google translate
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}


function triggerHtmlEvent(element, eventName) {
var event;
if (document.createEvent) {
event = document.createEvent('HTMLEvents');
event.initEvent(eventName, true, true);
element.dispatchEvent(event);
} else {
event = document.createEventObject();
event.eventType = eventName;
element.fireEvent('on' + event.eventType, event);
}
}

$('.lang-select').click(function() {
 theLang = $(this).attr('data-lang');
localStorage.setItem('lang',theLang);
// language = localStorage.getItem('lang');
// $('.goog-te-combo').val(theLang);

//alert(jQuery(this).attr('href'));
window.location = $(this).attr('href');

location.reload();

});

