<?php
$area_length=$_POST['al'];
$area_width=$_POST['aw'];
$tile_length=$_POST['tl'];
$tile_width=$_POST['tw'];

$area_size=$area_length*$area_width;
$tile_size=$tile_length*$tile_width;
$no_of_times=$area_size/$tile_size;

//echo "You Need".number_format($no_of_times, 2, '.', '')."Tiles";
echo "You Need <span class='text-danger'>".number_format($no_of_times, 2, '.', '')."</span> Tiles";



?>