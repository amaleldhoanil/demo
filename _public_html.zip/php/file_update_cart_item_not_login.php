<?php
session_start([
    'cookie_lifetime' => 604800,
]); // Starting Session 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$pid=$_GET['id'];
$item=$_POST['newquantity'];
//$uid=$_GET['uid'];
if($item > 0 && $item < 4)
{
    if(isset($_SESSION['cart']))
    {
    $item_array_id=array_column($_SESSION['cart'],"pid");
    if(in_array($pid,$item_array_id))
    {
        foreach ($_SESSION['cart'] as $k => $v) {
            if ($v['pid']==$pid) {
                $_SESSION['cart'][$k]['item']=$item;
              echo "Hi";
              print_r($_SESSION['cart']);
            }
          }
    }
    else
    {
   echo "pdt not in session";
    }
    }
    else
    {
        echo "no cart session";
        
    }
}
else
{
    echo "no";
}



?>