<?php
session_start();
if(isset($_POST["action"]))  
{  
     unset($_SESSION["login_user"]);  
     unset($_SESSION["uid"]);
     unset($_SESSION["uname"]);
     if(isset($_SESSION['cart']))
     {
          unset($_SESSION["cart"]);
     }
     // unset($_SESSION["av"]);
     // unset($_SESSION["pin"]);
     // unset($_SESSION["pinmsg"]);
}  
?>  
?>