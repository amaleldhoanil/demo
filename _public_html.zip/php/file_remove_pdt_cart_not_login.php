<?php
session_start();
$pid=$_GET['pid'];
$count=count($_SESSION['cart']);
$count=$count-1;
foreach($_SESSION['cart'] as $key => $value)
{
    if($value['pid']==$pid)
    {
        unset($_SESSION['cart'][$key]);
        echo $count;
    }
    
}

?>