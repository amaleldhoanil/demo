<?php
require_once 'include/DB_Functions.php';
 $db = new DB_Functions();

 if (isset($_POST['search'])) {

    $output = "";
    $query =  $_POST['search'];
    $result = $db->search_data($query);

    $output = '<ul class="list-unstyled">';		

    if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $output=$output."
            <li class='p-1'><a  href='product_description.php?epdid=".base64_encode($row['id'])."'>

            <div class='row'>
                <div class='col-3 pr-0'>
                   <img class='serachimg'  src='".$row['img1']."' alt=''>
                </div>
                <div class='col-9 pl-2'>
                        <span>".$row['pdt_name']." </span> 
                        <span><br>₹ ".$row['offer_price']." </span>
                </div>
            </div>
            
              
                               
            
                          
                     
            </a></li>
            "	;
        }
    }else{
          $output .= '<li> Product not Found</li>';
    }
    
    echo $output;
}

?>