<?php 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$mails=$_POST['mail'];
$Pass=$_POST['passwordr'];
$Pass = password_hash($Pass,PASSWORD_BCRYPT);
$otp=$_POST['otp'];
$r=$db->verify_otp($mails,$otp);
if($r->num_rows > 0)
{
$re=$db->update_password($mails,$Pass);
if($re)
{
    echo "1";
}
else
{
    echo "2";
}

}
else
{
    echo "0";
}



?>