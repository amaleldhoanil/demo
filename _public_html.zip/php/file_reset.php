<?php
require_once 'include/DB_Functions.php';
require 'phpmailer/PHPMailerAutoload.php';

$frommail = "bluefinrestaurantuae@gmail.com";
$pass = "gkoxhozebagiyvgl";
$tomail  = $_POST['mail'];
$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Debugoutput = 'html';
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "bluefinrestaurantuae@gmail.com";
$mail->Password = $pass;
$mail->setFrom($frommail, 'OTP');
$mail->addAddress($tomail, 'John Doe');
$mail->Subject = 'Reset Password Otp';
$otp=rand(999,9999);
$mail->Body = 'Password Reset Otp Is-'. $otp;
$mail->AltBody = 'This is a plain-text message body';
$db = new DB_Functions();
$mails=$_POST['mail'];
$s=$db->check_mail($mails); 
if($s->num_rows > 0)
 {
     if($mail->send() && $db->save_otp($mails,$otp))
     {
        echo "1";
     }
     else
     {
        echo "2";
     }
    
 } else
 {
    echo "0";     
 }
function save_mail($mail) {
    
    $path = "{imap.gmail.com:993/imap/ssl}[Gmail]/Sent Mail";
    $imapStream = imap_open($path, $mail->Username, $mail->Password);
    $result = imap_append($imapStream, $path, $mail->getSentMIMEMessage());
    imap_close($imapStream);
    return $result;

}

?>
