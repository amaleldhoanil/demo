<?php
require_once 'include/DB_Functions.php';
require('razorpay-api/config.php');
require('razorpay-api/razorpay-php/Razorpay.php');
session_start();
use Razorpay\Api\Api;
$api = new Api($keyId, $keySecret);
if($_SERVER['REQUEST_METHOD']=='POST')
{
$db = new DB_Functions();
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$d_time= $dt->format('d-m-Y h:i:s A');
  $fname = $_POST['fname']; 
  $uid = $_POST['uid']; 
  $lname = $_POST['lname']; 
  $email = $_POST['email']; 
  $phone = $_POST['phone']; 
  $inputAddress = $_POST['inputAddress']; 
  $land = $_POST['land']; 
  $inputCity = $_POST['inputCity']; 
  $inputstate = $_POST['inputstate']; 
  $inputZip = $_POST['inputZip']; 
  $pay=$_POST['paym'];
  $total=0;
  $original=0;
  $tax=$db->get_tax();
  $tax=$tax['tax'];
  $cart_items=$db->loggedin_cart($uid);
  $Pay_status="0";
  $shop=$db->get_shop();
           $i = 1; 
          while ($row = mysqli_fetch_array($shop)) { 
$shop_name=$row['shop_name'];
$img=$row['logo'];
$color=$row['color_1'];
            $i++; 
          }


  
$r=$db->update_profile($fname,$uid,$lname,$email,$phone,$inputAddress,$land,$inputCity,$inputstate,$inputZip);
if($r)
{
  $fee=$db->get_delivery_fee();
while ($row = mysqli_fetch_array($fee)) 
{ 
  $D_fee=$row['d_fee'];
}
  // $s=$db->check_pin($inputZip);
  // if($s!=null)
  // {
 if($pay=='0')
         {
        //  $D_fee=$s['d_fee'];
          while($row1 = mysqli_fetch_array($cart_items))
                {
                 $ITM_COUNT=$row1['pdt_item'];
                 $total=$total+($row1['offer_price']*$ITM_COUNT);
                 $original=$original+($row1['actual_price']*$ITM_COUNT);
                }
                $disc=$original-$total;
                $sub=$total+$D_fee;
                $vat=($sub/100)*$tax;
                $g_total=$sub+$vat;
          $o=$db->add_order($uid,$g_total,$pay,$d_time,$D_fee,$vat,$Pay_status);
          if($o)
               {
                $cart_items=$db->loggedin_cart($uid);
                while($row = mysqli_fetch_array($cart_items))
                {
              $pid=$row['pdt_id'];
              $pid_item=$row['pdt_item'];
              $color=$row['color'];
              $size=$row['size'];
              $offer_price=$row['offer_price'];
              $disc=$row['disc'];
              $actual_price=$row['actual_price'];
           $db->insert_cart_products($o,$pid,$pid_item,$color,$size,$offer_price,$disc,$actual_price);
             }
             $db->clear_cart($uid);
             $a = array("2");
             echo json_encode($a);
              }
         }
         else
         {
           
          


         // $D_fee=$s['d_fee'];
          while($row1 = mysqli_fetch_array($cart_items))
                {
                 $ITM_COUNT=$row1['pdt_item'];
                 $total=$total+($row1['offer_price']*$ITM_COUNT);
                 $original=$original+($row1['actual_price']*$ITM_COUNT);
                }
                $disc=$original-$total;
                $sub=$total+$D_fee;
                $vat=($sub/100)*$tax;
                $g_total=$sub+$vat;
          $o=$db->add_order($uid,$g_total,$pay,$d_time,$D_fee,$vat,$Pay_status);
          $orderData = [
            'receipt'         => $o,
            'amount'          => $g_total * 100, // 2000 rupees in paise
            'currency'        => 'INR',
            'payment_capture' => 1 // auto capture
                        ];
          $razorpayOrder = $api->order->create($orderData);
          $razorpayOrderId = $razorpayOrder['id'];
          $_SESSION['razorpay_order_id'] = $razorpayOrderId;
          $_SESSION['purchase_id'] = $o;
          $amount = $orderData['amount'];
          if($o)
               {
                $cart_items=$db->loggedin_cart($uid);
                while($row = mysqli_fetch_array($cart_items))
                {
              $pid=$row['pdt_id'];
              $pid_item=$row['pdt_item'];
              $color=$row['color'];
              $size=$row['size'];
              $offer_price=$row['offer_price'];
              $disc=$row['disc'];
              $actual_price=$row['actual_price'];
           $db->insert_cart_products($o,$pid,$pid_item,$color,$size,$offer_price,$disc,$actual_price);
             }
             $a = array("3","$o","$uid","$g_total","$fname","$email","$phone","$inputAddress","$shop_name","$img","$color","$razorpayOrderId");
             echo json_encode($a);
              }
          
         }

          
         
  // } else
  //    {  
  //       $a = array("1");
  //        echo json_encode($a);
  //     }
 
}
else
{
  $a = array("0");
  echo json_encode($a);
}
}

?>
