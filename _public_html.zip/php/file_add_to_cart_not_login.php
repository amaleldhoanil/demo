<?php
session_start([
    'cookie_lifetime' => 604800,
]); // Starting Session 
$pid=$_GET['pid'];
$color=$_POST['color'];
$size=$_POST['size'];
$item='1';
if(isset($_SESSION['cart']))
{
$item_array_id=array_column($_SESSION['cart'],"pid");
if(in_array($pid,$item_array_id))
{
echo "0";
}
else
{
$count=count($_SESSION['cart']);
$cart_item_array=array('pid'=>$pid,'color'=>$color,'size'=>$size,'item'=>$item);
$_SESSION['cart'][$count]=$cart_item_array;
echo $count=count($_SESSION['cart']);
}
}
else
{
    $cart_item_array=array('pid'=>$pid,'color'=>$color,'size'=>$size,'item'=>$item);
    $_SESSION['cart'][0]=$cart_item_array;
    echo $count=count($_SESSION['cart']);
    
}
?>