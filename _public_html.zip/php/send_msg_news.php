<?php

require 'phpmailer/PHPMailerAutoload.php';


 $email=$_POST['email'];


$frommail = "oyyorealestateqar@gmail.com";
$pass = "avlxjrnodaektlfh";
$tomail  = "info@oyyorealestate.com";
$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Debugoutput = 'html';
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "oyyorealestateqar@gmail.com";
$mail->Password = $pass;
$mail->setFrom($frommail, 'OYYO Real Estate');
$mail->addAddress($tomail, 'Admin');
$mail->Subject = 'News Letter';
$otp=rand(999,9999);
$mail->Body = '<html>


<body><h2>Email:'.$email.'</h2></body></html>';
$mail->IsHTML(true); 
$mail->AltBody = 'This is a plain-text message body';




     if($mail->send())
     {
        echo 1;
     }
     else
     {
        echo 2;
     }
    

function save_mail($mail) {
    
    $path = "{imap.gmail.com:993/imap/ssl}[Gmail]/Sent Mail";
    $imapStream = imap_open($path, $mail->Username, $mail->Password);
    $result = imap_append($imapStream, $path, $mail->getSentMIMEMessage());
    imap_close($imapStream);
    return $result;

}

?>
