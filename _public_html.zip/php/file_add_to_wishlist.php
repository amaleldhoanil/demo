<?php 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$pdt_id=$_GET['pid'];
$u_id=$_GET['uid'];
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$current1= $dt->format('d-m-Y');
$s=$db->whish_status($pdt_id,$u_id);
if($s->num_rows > 0)
{
    $s=$s->fetch_assoc();
    if($s['status']==0)
    {
        $val='1';
        $w=$db->wish_s_change($pdt_id,$u_id,$val);
        if($w)
        {
            echo "1";
        }
        else
        {
            echo "2";
        }
    }
    else
    {
        $val='0';
        $w=$db->wish_s_change($pdt_id,$u_id,$val);
        if($w)
        {
            echo "0";
        }
        else
        {
            echo "2";
        }
    }

}
else
{
    $v=$db->add_to_wish($pdt_id,$u_id,$current1);
    if($v)
        {
            echo "0";
        }
        else
        {
            echo "2";
        }

}



?>