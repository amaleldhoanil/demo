<?php
require_once 'include/DB_Functions.php';
// if(!isset($_SESSION['login_admin']))
// {
//  header("location: index.php"); // Redirecting To Profile Page
// }
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
 //importing DB_functions
 $db = new DB_Functions();
 $dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$d_time= $dt->format('d-m-Y');
$Name=$_POST['uname'];
$Phone=$_POST['umobile'];
$Email=$_POST['uemail'];
$Pass=$_POST['rpassword'];
$Pass = password_hash($Pass,PASSWORD_BCRYPT);

$mob_check=$db->mobcheck($Phone);
$mail_check=$db->mailcheck($Email);
if($mob_check->num_rows>0)
{
  echo "2";
}else if($mail_check->num_rows>0)
{
  echo "3";
}else
{
 $result=$db->register($Name,$Phone,$Email,$Pass,$d_time);
    if($result)
    {
       echo "0";
    }
    else
    {
        echo "1"; 
       
    }
}
}
?>