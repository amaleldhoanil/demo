<?php
//session_name("LN");
session_start([ 
    'cookie_lifetime' => 31536000, 
    'gc_maxlifetime' => 31536000, 
   ]); 
require_once 'include/DB_Functions.php';
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$current1= $dt->format('d-m-Y');
 if($_SERVER['REQUEST_METHOD']=='POST')
 {
 $db = new DB_Functions();
         $phone =htmlspecialchars($_POST['lmob']);
         $password =htmlspecialchars($_POST['lpass']);

         $user = $db->getpassByPhone($phone);
         $Db_pass = $user['pass'];
         
          if (password_verify($password,$Db_pass)) 
          {
              $_SESSION['uid'] = $user['id'];
              $_SESSION['uname']=$user['name'];
              echo "0";
              $_SESSION['login_user'] = $phone; 

              if(isset($_SESSION['cart']))
              {
                  $r=$db->cart_list();
                  while($row = mysqli_fetch_array($r))
                  {
                      foreach ($_SESSION['cart'] as $item_id => $item)
                  {
                  if($row['id'] == $item['pid'])
                  {
                  $pid=$item['pid'];
                  $color=$item['color'];
                  $size=$item['size'];
                  $items=$item['item'];
                  $db->insert($user['id'],$pid,$color,$size,$items,$current1);
                  }
                  }
                  }
              }

          } 
          else 
          { 
            echo "1";
          }
     
 }
?>