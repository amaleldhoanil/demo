<?php 
session_start([
    'cookie_lifetime' => 604800,
]); 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$d_time= $dt->format('d-m-Y');
$pid=$_GET['pid'];
$userid=$_GET['cuid'];
$color=$_POST['color'];
$size=$_POST['size'];
$item='1';

$check=$db->check_pdt_on_cart($userid,$pid);
if($check->num_rows>0)
{
echo "0";  
}
else
{
 $r=$db->logedin_add_to_cart($userid,$pid,$color,$size,$item,$d_time);
 if($r)
 {
     
     $count=$db->cart_count($userid);
     while ($r=mysqli_fetch_array($count)) {
         echo $r['total'];
         } 
 }
 else
 {
     echo "no";  
 }   
}

?>