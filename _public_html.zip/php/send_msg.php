

<?php

require 'phpmailer/PHPMailerAutoload.php';
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
$d_time= $dt->format('d-m-Y h:i:s A');
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];

 $msg=$_POST['msg'];




if($db->send_msg($name,$email,$phone,$msg,$d_time))
 {
        echo 1;
     }
     else
     {
        echo 2;
     }

    //  if($mail->send())
    //  {
    //     echo 1;
    //  }
    //  else
    //  {
    //     echo 2;
    //  }
    



?>
