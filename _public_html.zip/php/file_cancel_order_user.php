<?php
require_once 'include/DB_Functions.php';
if($_SERVER['REQUEST_METHOD']=='GET')
{
$db = new DB_Functions();
$o_id=$_GET['id'];
$r=$db->cancel_order_user($o_id);
if($r)
{
echo "0";
}
else
{
echo "1";
}
}

?>