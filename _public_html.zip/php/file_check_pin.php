 <?php
//session_name("CK_PIN");
session_start([ 
    'cookie_lifetime' => 31536000, 
    'gc_maxlifetime' => 31536000, 
   ]); 
require_once 'include/DB_Functions.php';
 $db = new DB_Functions();
 $pin1=$_POST['pin'];
 $pin="%$pin1%";
 $s=$db->check_pin($pin); 
 if($s!=null)
 {
         echo $s['d_fee'];
         $_SESSION['av']=true;
         $_SESSION['pin']=$pin1;
         $_SESSION['pinmsg'] = $s['d_fee'];
         $_SESSION['pinmessage']="Delivery available in your area | Fee ".$s['d_fee'];
 } else{
         $_SESSION['av']=false;
         $_SESSION['pin']=$pin1;
         $_SESSION['pinmsg'] = "0";
         $_SESSION['pinmessage']="Delivery is not available in your area";
         echo "no";
 }
?>