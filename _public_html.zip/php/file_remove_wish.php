<?php 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$pdt_id=$_GET['pid'];
$u_id=$_GET['uid'];
$s=$db->remove_whish_status($pdt_id,$u_id);
if($s)
{
    $count=$db->wish_count($u_id);
    while ($r=mysqli_fetch_array($count)) {
        echo $r['total'];
        } 

}
else
{
    echo "no";
}

?>