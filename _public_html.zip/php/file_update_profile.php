<?php
require_once 'include/DB_Functions.php';
if($_SERVER['REQUEST_METHOD']=='POST')
{
$db = new DB_Functions();
  $fname = $_POST['fname']; 
  $uid = $_POST['uid']; 
  $lname = $_POST['lname']; 
  $email = $_POST['email']; 
  $phone = $_POST['phone']; 
  $inputAddress = $_POST['inputAddress']; 
  $land = $_POST['land']; 
  $inputCity = $_POST['inputCity']; 
  $inputstate = $_POST['inputstate']; 
  $inputZip = $_POST['inputZip']; 
$r=$db->update_profile($fname,$uid,$lname,$email,$phone,$inputAddress,$land,$inputCity,$inputstate,$inputZip);
if($r)
{
echo "0";
}
else
{
    echo "1";
}
}

?>