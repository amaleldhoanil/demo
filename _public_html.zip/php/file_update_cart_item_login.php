<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$p_id=$_GET['id'];
$item=$_POST['newquantity'];
$uid=$_GET['uid'];
if($item > 0 && $item < 4)
{
    $r=$db->update_cart_item_count($p_id,$item,$uid);
    if($r)
    {
    echo "0";
    }
    else
    {
    echo "1";
    }
}
else
{
    echo "no";
}



?>