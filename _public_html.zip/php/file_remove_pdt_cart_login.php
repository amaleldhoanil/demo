<?php 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
$pdt_id=$_GET['pdid'];
$u_id=$_GET['uid'];
$s=$db->remove_from_cart($pdt_id,$u_id);

if($s)
{
    $count=$db->cart_count($u_id);
    while ($r=mysqli_fetch_array($count)) {
        echo $r['total'];
        } 
}
else
{
    echo "no";
}

?>