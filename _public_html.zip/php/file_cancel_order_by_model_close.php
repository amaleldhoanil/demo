<?php
require_once 'include/DB_Functions.php';
if($_SERVER['REQUEST_METHOD']=='POST')
{
$db = new DB_Functions();
$uid=$_POST['uid'];
$oid=$_POST['soid'];
$db->delete_order($uid,$oid);
$db->delete_order_pdts($uid,$oid);
}

?>