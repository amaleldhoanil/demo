<?php

class DB_Functions {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {
        //require_once 'DB_Connect.php';
        
    }
	
     public function GetSliders()
  {
       $stmt=$this->conn->query("SELECT * FROM tbl_slider WHERE status ='0' ");
     
           if ($stmt) 
       {
       // $stmt=$stmt->fetch_assoc();
        return $stmt;
           
       }
  }
   public function Load_cat()
  {
       $stmt=$this->conn->query("SELECT * FROM tbl_category WHERE `status`='0' LIMIT 12 ");
     
           if ($stmt) 
       {
       // $stmt=$stmt->fetch_assoc();
        return $stmt;
           
       }
  }

  public function Load_features()
  {
    $stmt=$this->conn->query("SELECT * FROM `tbl_features` WHERE status = '0' ORDER BY `id` DESC LIMIT 4 ");
     
           if ($stmt) 
       {
       // $stmt=$stmt->fetch_assoc();
        return $stmt;
           
       }   
  }
  public function get_data()
{
  $stmt=$this->conn->query("SELECT * FROM tbl_category WHERE `status` ='0' ");
   
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return $stmt;
  
} 
}
  public function getGallery()
{
  $stmt=$this->conn->query("SELECT * FROM tbl_gallery WHERE status ='0' ");
   
  if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return $stmt;
  
}
}
  public function Load_feature()
  {
    $stmt=$this->conn->query("SELECT * FROM `tbl_features` WHERE status = '0' ORDER BY `id` DESC");
     
           if ($stmt) 
       {
       // $stmt=$stmt->fetch_assoc();
        return $stmt;
           
       }   
  }
  public function load_web_content()
  {
    $stmt=$this->conn->query("SELECT * FROM `tbl_shop_details` WHERE id = '1' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}     
  }
  public function load_ser_details($sid)
  {
    $stmt=$this->conn->query("SELECT * FROM `tbl_category` WHERE id = '$sid' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}     
  }
  public function load_pdt_details($pid)
  {
    $stmt=$this->conn->query("SELECT * FROM `tbl_gallery` WHERE `id` = '$pid' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}   
  }
  public function Load_new()
  {
    $stmt=$this->conn->query(" SELECT * FROM `tbl_products` WHERE status='0' AND new_arrival='1' ORDER BY `day` DESC LIMIT 16 ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }
   
}

public function get_cat_pdt($get_epid)
{
    $stmt=$this->conn->query(" SELECT * FROM `tbl_products` WHERE pdt_cat='$get_epid' AND status='0' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }  
}
public function get_pdt($get_epid)
{
    $stmt=$this->conn->query(" SELECT * FROM `tbl_products` WHERE id='$get_epid' AND status='0' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }    
}
public function load_related($cat,$pdt)
{
    $stmt=$this->conn->query(" SELECT * FROM `tbl_products` WHERE pdt_cat='$cat' AND status='0' AND id !='$pdt' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }      
}
public function  check_pin($pin)
{
    $stmt=$this->conn->query(" SELECT d_fee FROM `tbl_delivery_loc` WHERE pincode LIKE '%$pin%' ");
    
    if ($stmt) 
{
 return $stmt=$stmt->fetch_assoc();
  }else{
      return $stmt;
  }       
}
public function register($Name,$Phone,$Email,$Pass,$d_time)
{
    $stmt=$this->conn->query(" INSERT INTO `tbl_user`(`name`, `phone`, `email`, `pass`,`d_time`) VALUES ('$Name','$Phone','$Email','$Pass','$d_time') ");
    
    if ($stmt) 
{
 return true; 
  }else{
      return false;
  }        
}

public function mobcheck($Phone)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_user` WHERE phone='$Phone'");
    
    if ($stmt) 
{
 return $stmt; 
  }else{
      return false;
  }     
}
public function mailcheck($Email)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_user` WHERE email='$Email'");
    
    if ($stmt) 
{
 return $stmt; 
  }else{
      return false;
  }    
}
public function getpassByPhone($phone) 
{
    $stmt=$this->conn->query("SELECT id,pass,`name` FROM tbl_user WHERE phone ='$phone' ");
   if ($stmt) 
   {
    $stmt=$stmt->fetch_assoc();
    return $stmt;
       
   }
} 

public function check_mail($mails)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_user` WHERE email='$mails'");
    
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }       
}
public function save_otp($mails,$otp)
{
    $stmt=$this->conn->query(" UPDATE `tbl_user` SET `otp`='$otp' WHERE email='$mails' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }  
}
public function verify_otp($mails,$otp)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_user` WHERE email='$mails' AND otp='$otp' ");
    
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }          
}
public function update_password($mails,$Pass)
{
    $stmt=$this->conn->query(" UPDATE `tbl_user` SET pass='$Pass',otp=null WHERE email='$mails' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }   
}
public function check_pdt_in_wish($val,$uid)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_wish_list` WHERE `user_id` ='$uid' AND pdt_id='$val' AND `status`='0' ");
    
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }     
}
public function whish_status($pdt_id,$u_id)
{
    $stmt=$this->conn->query(" SELECT * FROM `tbl_wish_list` WHERE `user_id` ='$u_id' AND pdt_id='$pdt_id' ");
    
    if ($stmt) 
{
    // $stmt=$stmt->fetch_assoc();
    return $stmt;
  }else{
      return $stmt;
  }       
}
public function wish_s_change($pdt_id,$u_id,$val)
{
    $stmt=$this->conn->query(" UPDATE `tbl_wish_list` SET `status`='$val' WHERE `user_id` ='$u_id' AND pdt_id='$pdt_id' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }     
}
public function add_to_wish($pdt_id,$u_id,$current1)
{
    $stmt=$this->conn->query("INSERT INTO `tbl_wish_list`(`user_id`, `pdt_id`, `w_date`, `status`) VALUES ('$u_id','$pdt_id','$current1','0')");
    
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }       
}
public function Load_wishlist($uid)
{
    $stmt=$this->conn->query("SELECT * FROM tbl_products where id in (select pdt_id from tbl_wish_list where user_id ='$uid' AND `status`='0')");
    
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }       
}
public function remove_whish_status($pdt_id,$u_id)
{
    $stmt=$this->conn->query(" UPDATE `tbl_wish_list` SET `status`='1' WHERE `user_id` ='$u_id' AND pdt_id='$pdt_id' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }        
}
public function cart_list()
{
    $stmt=$this->conn->query(" SELECT * FROM `tbl_products` WHERE status='0' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }      
}

public function get_tax()
{
    $stmt=$this->conn->query(" SELECT tax FROM `tbl_shop_details` ");
     
    if ($stmt) 
{
 $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }    
}
public function insert($userid,$pid,$color,$size,$items,$day)
{
    $stmt=$this->conn->query("INSERT INTO `tbl_cart`(`user_id`,`pdt_id`, `color`, `size`, `pdt_item`,`dates`,`status`) VALUES ('$userid','$pid','$color','$size','$items','$day','0') ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }     
}
public function loggedin_cart($uid)
{
    $stmt=$this->conn->query(" SELECT tbl_products.*, tbl_cart.* FROM tbl_products LEFT JOIN tbl_cart ON tbl_products.id = tbl_cart.pdt_id WHERE tbl_cart.user_id='$uid' GROUP BY tbl_cart.pdt_id");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }        
}
public function logedin_add_to_cart($userid,$pid,$color,$size,$item,$d_time)
{
    $stmt=$this->conn->query("INSERT INTO `tbl_cart`(`user_id`, `pdt_id`, `color`, `size`, `pdt_item`, `dates`, `status`) VALUES ('$userid','$pid','$color','$size','$item','$d_time','0')");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;   
  }     
}
public function load_profile($uid)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_user` WHERE id = $uid ");
   
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}  
}
public function update_profile($fname,$uid,$lname,$email,$phone,$inputAddress,$land,$inputCity,$inputstate,$inputZip)
{
    $stmt=$this->conn->query(" UPDATE `tbl_user` SET `name`='$fname',`lname`='$lname',`phone`='$phone',`email`='$email',`address`='$inputAddress',`landmark`='$land',`city`='$inputCity',`state`='$inputstate',`pin`='$inputZip' WHERE id='$uid' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }     
}
public function add_order($uid,$g_total,$pay,$d_time,$D_fee,$vat,$Pay_status)
{
    $stmt=$this->conn->query("INSERT INTO `tbl_orders`(`user_id`, `total`, `order_status`, `pay_mode`, `dates`,`d_fee`,`tax`,`pay_status`) VALUES ('$uid','$g_total','0','$pay','$d_time','$D_fee','$vat','$Pay_status')");
   
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
return $this->conn->insert_id;
    
  }     
}
public function insert_cart_products($o,$pid,$pid_item,$color,$size,$offer_price,$disc,$actual_price)
{
    $stmt=$this->conn->query(" INSERT INTO `tbl_order_items`(`order_id`, `pdt_id`, `quantity`, `color`, `size`, `item_offer`, `disc`, `item_original`) 
            VALUES ('$o','$pid','$pid_item','$color','$size','$offer_price','$disc','$actual_price')");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }    
}
public function cart_count($userid)
{ 
    $stmt=$this->conn->query(" SELECT COUNT(*) as total FROM `tbl_cart` WHERE `user_id`='$userid' AND status='0' ");
if ($stmt) 
{
return $stmt;
}else{
return false;
}    
}
public function get_proj_count($sid)
{
    $stmt=$this->conn->query(" SELECT COUNT(*) as total FROM `tbl_gallery` WHERE `ser`='$sid' AND `status`='0' ");
    if ($stmt) 
    {
    $stmt=$stmt->fetch_assoc();
    return $stmt;
    }else{
    return false;
    }     
}
public function check_pdt_on_cart($userid,$pid)
{
    $stmt=$this->conn->query(" SELECT *  FROM `tbl_cart` WHERE `user_id`='$userid' AND `pdt_id`='$pid' AND status='0' ");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }     
}

public function load_orders($uid)
{
    $stmt=$this->conn->query(" SELECT * FROM tbl_orders WHERE `user_id`='$uid' ORDER BY id DESC ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }     
}
public function load_order_pdts($id)
{
    //SELECT tbl_orders.d_fee,tbl_orders.tax,tbl_products.pdt_name,tbl_products.img1,tbl_products.id, tbl_order_items.quantity,tbl_order_items.color,tbl_order_items.size,tbl_order_items.item_offer,tbl_order_items.disc,tbl_order_items.item_original FROM tbl_products LEFT JOIN tbl_order_items LEFT JOIN tbl_orders ON tbl_order_items.order_id = tbl_orders.id ON tbl_products.id = tbl_order_items.pdt_id WHERE tbl_order_items.order_id='1' 
    $stmt=$this->conn->query(" SELECT tbl_products.pdt_name,tbl_products.img1,tbl_products.id, tbl_order_items.quantity,tbl_order_items.color,tbl_order_items.size,tbl_order_items.item_offer,tbl_order_items.disc,tbl_order_items.item_original FROM tbl_products LEFT JOIN tbl_order_items ON tbl_products.id = tbl_order_items.pdt_id WHERE tbl_order_items.order_id='$id' ");
    if ($stmt) 
{
    return $stmt;
  }else{
      return false;
  }     
}
public function Load_Shop()
{
  $stmt=$this->conn->query("SELECT * FROM `tbl_shop_details` WHERE id = '1' ");
   
         if ($stmt) 
     {
     // $stmt=$stmt->fetch_assoc();
      return $stmt;
         
     }    
}
public function get_cat_products($sid)
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_gallery` WHERE `status`='0' AND `ser`='$sid' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}   
}

public function send_msg($name,$email,$phone,$msg,$d_time)
{
$stmt=$this->conn->query("INSERT INTO `tbl_feedback`(`name`, `phone`, `mail`, `msg`, `dates`) VALUES ('$name','$phone','$email','$msg','$d_time')");
if ($stmt) 
{
return $stmt;
}else{
return false;
}    
}
public function remove_from_cart($pdt_id,$u_id)
{
    $stmt=$this->conn->query(" DELETE FROM `tbl_cart` WHERE `user_id` ='$u_id' AND pdt_id='$pdt_id' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }       
}
public function wish_count($u_id)
{
    $stmt=$this->conn->query(" SELECT COUNT(*) as total FROM `tbl_wish_list` WHERE `user_id`='$u_id' AND status='0' ");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }      
}
public function get_shop()
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_shop_details` WHERE id = '1' ");
     
    if ($stmt) 
{
// $stmt=$stmt->fetch_assoc();
 return $stmt;
    
}      
}
public function update_order_pay_status($uid,$oid)
{
    $stmt=$this->conn->query(" UPDATE `tbl_orders` SET `pay_status`='1' WHERE id='$oid' AND `user_id`='$uid' ");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }     
}
public function clear_cart($uid)
{
    $stmt=$this->conn->query(" DELETE FROM `tbl_cart` WHERE `user_id` ='$uid' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }       
}
public function delete_order($uid,$oid)
{
    $stmt=$this->conn->query(" DELETE FROM `tbl_orders` WHERE `user_id` ='$uid' AND id='$oid' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }        
}
public function delete_order_pdts($uid,$oid)
{
    $stmt=$this->conn->query(" DELETE FROM `tbl_order_items` WHERE `order_id` ='$oid' ");
    
    if ($stmt) 
{
    return true;
  }else{
      return false;
  }    
}
public function cancel_order_user($o_id)
{
    $stmt=$this->conn->query(" UPDATE `tbl_orders` SET `order_status`='5' WHERE id='$o_id'");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }      
}
public function update_cart_item_count($p_id,$item,$uid)
{
    $stmt=$this->conn->query(" UPDATE `tbl_cart` SET `pdt_item`='$item' WHERE pdt_id='$p_id' AND `user_id`='$uid' ");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }      
}
public function search_data($city)
{

    $stmt=$this->conn->query(" SELECT * FROM tbl_products WHERE pdt_name LIKE '%$city%' LIMIT 6 ");
    if ($stmt) 
    {
    return $stmt;
    }else{
    return false;
    }     
}
public function get_delivery_fee()
{
    $stmt=$this->conn->query("SELECT * FROM `tbl_delivery_loc` WHERE id = '1' ");
   
    if ($stmt) 
  {
  // $stmt=$stmt->fetch_assoc();
  return $stmt;
    
  }       
}
}
?>
