/* You can add global styles to this file, and also import other style files */
/*------------------------------------------------------------------
 * Theme Name:AplhaExpresion Technologies
 * Description:
 * Bootstrap v4.1.3 (http://getbootstrap.com)
 * Copyright 2019
 -------------------------------------------------------------------*/


/*------------------------------------------------------------------

[Table of contents]

1. General Styles .
2. header Styles .


[ THE END ]
-------------------------------------------------------------------*/


@import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
<?php header("Content-type: text/css; charset: UTF-8"); 
require_once '../php/include/DB_Functions.php';
$db = new DB_Functions();
$details=$db->load_web_content();

         $i = 1; 
         while ($row = mysqli_fetch_array($details)) { 
         
$cheader = $row['color_1'];
$color_2 = 'rgb(28, 93, 190)';
$cfooter = $row['color_2'];

         $i++; 
 }

?>

/*------------------------------------------------------------------
    1. General Styles
-------------------------------------------------------------------*/

html {
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    display: block;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
	  scroll-behavior: smooth;
	  overflow-y: scroll;
}

body {
    font-family: 'Poppins', sans-serif;
    color: #606060;
    font-weight: normal;
    font-size: 14px;
    background: rgb(255 255 255);
    line-height: 1.6;
    position: relative;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

a {
    text-decoration: none;
    color:<?=$cfooter?>;
    -webkit-transition: all 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    -moz-transition: all 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    -o-transition: all 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    outline: none !important;
}


a:focus, a:hover {
  text-decoration: none;
  cursor: pointer;
  outline: 0;

}
p {
  margin: 0 0 30px;
  line-height: 30px;
  font-size: 16px;
  font-weight: 300;
}

img {
    outline: none;
    border: none;
    max-width: 100%;
    height: auto;
}

ul,
ol {
    margin: 0px;
}
button
{
    outline: 0;
}
button:focus {
   
    outline: unset;
}
.no-padding {
    padding: 0!important;
}

.no-padding-lft {
    padding-left: 0;
}

.no-padding-rgt {
    padding-right: 0;
}






.disp-flex {
    display: flex;
}

.text-danger {
    color: #dc3545!important;
}


.nav-item .fas{
	color: rgb(28, 93, 190);
}
.nav-item.active .fas{
	color: #ffff;
}
/*.fa-phone{
  transform: rotate(100deg);
}*/
ul{
  list-style: none;
  margin: auto;
  padding: 0;
}
.no-margin{
  margin: 0;
}
.color-custom{
   background-color: rgb(255, 87, 34);
}
/* ============================ COMMON CLASSES =========================*/
h1, h2, h3, h4, h5, h6 {
    font-family: 'Sora', sans-serif;
    font-weight: 300;
    color: <?=$cfooter?>;
    margin: 0 0 15px;
}
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
.section-padding{
    padding: 40px 40px;
  }
  .users {
    padding: 100px 40px;
}
.bg-primary {
    background-color: <?=$cheader?>!important;
}

  .section-title {
    color: <?=$cheader?>f0;
    font-weight: 6;
    text-transform: uppercase;
    font-size: 36px;
    margin: 0px auto 0px;
    /* width: max-content; */
    border-radius: 0.5px;
}



  p.sub-head {
    letter-spacing: 0px;
    font-size: 16px;
    opacity: 0.8;
}
  h1.section-title.video {
    color: #ffff;
}
  .section-title-side{
    color: #ee474b;
    font-weight: 300;
    font-size: 20px;
    margin: 0px auto 5px;
    
    
  }
  .bg1 {
    background-color: <?=$cheader?>!important;
}
  .bg2{
    background-color: <?=$cfooter?>!important;
  }
  .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #ffffff!important ;
    background-color:<?=$cheader?>!important;
}
.color1{
    color: #e52522!important;
}
.color2{
    color: #f70000!important;
  
}
.eliteborder{
  border: 1px solid rgba(28, 93, 190, 0.18);
}
.eliteborder-shop{

    margin: 10px;
    /* box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0px 2px 6px 0 rgba(0, 0, 0, 0.12); */
    overflow: hidden;
    cursor: pointer;
    position: relative;
    
    border: 1px solid rgba(28, 93, 190, 0.18);
}
.eliteborder-shop:hover{
  box-shadow: 0 2px 5px 0 rgb(0 0 0 / 16%), 0px 2px 6px 0 rgb(0 0 0 / 12%);
}
.eliteborder-shop:hover .p-name{
  color: rgb(25, 0, 255);
}
.box-style{
    /* border-radius: 14px; */
    margin: 10px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0px 2px 6px 0 rgba(0, 0, 0, 0.12);
    overflow: hidden;
    cursor: pointer;
    position: relative;
    background-color: #ffffff;
  }
  .box-style:hover {
    transform: scale(1.01);
    /* transform: rotate(1deg); */
    
    transition: auto;
    box-shadow: -2px -1px 7px 0 rgba(0, 0, 0, 0.16), 0px 0px 0px 0 rgba(0, 0, 0, 0.12);

}
.video-box{
    margin: 10px;
    
    overflow: hidden;
    cursor: pointer;
}


.about{
  background-color: #000000;
}
.about h5{
  color: #ffffff;
  margin-top: 15px;
}

.aboutintro .flag {
    width: 60px;
    margin: 0 auto;
    top: -15px;
    left: 0;
}

   .aboutintro .fa{
   color:#f70000;
   box-shadow: 0px 0px 1px 0 rgb(0 0 0 / 16%), 0 4px 10px 0px rgb(0 0 0 / 12%);
  }


.aboutintro ul li{
  font-size: 16px;
  list-style: none;
  padding-bottom: 8px;
}
/* .btn{
  border-radius: unset;
} */


/* ============================ form =========================*/
.form-control:focus {
    color: #495057;
    background-color: #fff;
    border-color: rgb(36 77 143);
    outline: 0;
    box-shadow: none;
}
/* ============================ from =========================*/

.btm-headc{
  padding: 15px;
    bottom: 0;
    width: 90%;
    color: #fff;
    margin: 15px;
    background-color: #000000;
    position: absolute;
}
.btm-head {
  text-align: left;
  padding: 15px;
  text-align: center;
  background-color: #ffffff;
}
.btm-head .btn{
  
  padding: 0;
  
}
.btm-head span{
  color: #000000;;
  padding: 5px;
}
.btm-head .price {
  font-size: 16px;
  font-weight: 300;
}
.btm-head .oprice {
  font-size: 12px;
  text-decoration: line-through;
}
.dprice li{
  display:inline-block;
  padding: 0 12px 0 0;
}


.btm-head ul li{
  display: inline-block;
  font-size: 20px;
  padding: 8px;
}
.btm-head p{
  font-size: 15px;
  margin: 0;
  color: #000000;;
  font-weight: 300;
  letter-spacing: 1.5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.subhead{
  font-size: 14px;
  font-weight: 100;
  padding: 0;
  margin: 0;
}
.btm-head p.size{
    font-size: 14px;
    color: rgb(28, 93, 190);
    font-weight: 100;
}
.orderbtn{
  display: block;
}

/***********************************preloader**********************************/
/* Demo Styles */
#content {
  margin: 0 auto;
  padding-bottom: 50px;
  width: 80%;
  max-width: 978px;
}

h1 {
  font-size: 60px;
}

/* The Loader */
#loader-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  overflow: hidden;
}
.no-js #loader-wrapper {
  display: none;
}

#loader {
  display: block;
  position: relative;
  width: 100px;
  height: 100px;
  top: 50%;
  left: 50%;
  margin: -75px 0 0 -75px;
  
  

  
  z-index: 11;
}


@-webkit-keyframes flash {
  from,
  50%,
  to {
    opacity: 1;
  }

  25%,
  75% {
    opacity: 0;
  }
}

@keyframes flash {
  from,
  50%,
  to {
    opacity: 1;
  }

  25%,
  75% {
    opacity: 0;
  }
}


#loader-wrapper .loader-section {
  position: fixed;
  top: 0;
  width: 51%;
  height: 100%;
  background: #ffffff;
  z-index: 10;
}

#loader-wrapper .loader-section.section-left {
  left: 0;
}

#loader-wrapper .loader-section.section-right {
  right: 0;
}

/* Loaded styles */
.loaded #loader-wrapper .loader-section.section-left {
  visibility: hidden;
  transition: all 0.7s 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
}

.loaded #loader-wrapper .loader-section.section-right {
  visibility: hidden;
  transition: all 0.7s 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
}

.loaded #loader {
  opacity: 0;
  transition: all 0.3s ease-out;
}

.loaded #loader-wrapper {
  visibility: hidden;
  -webkit-transform: translateY(-100%);
          transform: translateY(-100%);
  transition: all 0.3s 1s ease-out;
}
/***********************************preloader**********************************/

/* ============================ owlcarousal =========================*/

.owl-theme .owl-nav [class*=owl-] {
    position: absolute;
    background: #ffffff!important;
    border-radius: 0;
    padding: 0;
    border-color: #fff;
    border-style: dashed;
    text-align: center;
    font-size: 26px;
    line-height: 50px;
    border-radius: 10%;
    color: rgb(243, 112, 34);
    width: 40px;
    height: 50px;
    -webkit-box-shadow: 0px 3px 24px 0px rgba(0, 0, 0, 0.1);
    box-shadow: 0px 3px 24px 0px rgba(0, 0, 0, 0.1);
}
.owl-carousel .owl-nav .owl-prev{
    left: 20px;
    top: 45%;
    -webkit-transition: all 0.4s ease-in-out;
    -moz-transition: all 0.4s ease-in-out;
    -o-transition: all 0.4s ease-in-out;
    transition: all 0.4s ease-in-out;
}

.owl-carousel .owl-nav .owl-next {
    right: 20px;
    top: 45%;
    -webkit-transition: all 0.4s ease-in-out;
    -moz-transition: all 0.4s ease-in-out;
    -o-transition: all 0.4s ease-in-out;
    transition: all 0.4s ease-in-out;
}

.owl-stage{display: flex;}
.item {
    display: flex;
    flex: 1 0 auto;
    height: 100%;
}

.owl-carousel .owl-nav .owl-next .fa {
    margin: 0!important;
    color: #000000;
}
.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span{
  background: #ffc107;
}
.text-primary {
    color: <?=$cheader?>!important;
}
.owl-slider .owl-dots {
    left: 0;
    right: 0;
    position: absolute;
    bottom: 10%;
}

.owl-rating .owl-dots {
    left: 0;
    right: 0;
    position: absolute;
    bottom: 0%;
}
.owl-theme .owl-dots .owl-dot span {
    width: 10px;
    height: 10px;
    margin: 2px;
}
.owl-theme .owl-dots .owl-dot {
  
    background-color: #0000;
    border: unset;
    box-shadow: unset;
}
.owl-theme .owl-nav{
  margin: 0;
}
 

 section.catemenu {
  padding: 10px 40px;
  background-color: <?=$cheader?>
}
.catemenu h6 {
  margin: 0;
  padding: 8px 0;
  color: #fff;
}
.btn-cstm {
  -webkit-transition: all 0.4s  ease-in-out;
  transition: all 0.4s  ease-in-out;
    color: #fff;
    background-color: <?=$cheader?>;
    border-color: <?=$cheader?>;
    width: fit-content;
    border-radius: 1.25rem;
}
.btn-cstm:hover{
  color: #fff;

}
.contact{
    padding: 40px 0 15px;
}
.contact .fa{

color: <?=$cheader?>;
}
.contact ul li {
    font-size: 16px;
    list-style: none;
    padding-bottom: 8px;
    border: 1px solid rgb(196, 196, 196);
    margin-bottom: 15px;
    padding: 10px;
}
.contact ul li h5 {
    margin: 0 0 10px;
}
 .about{
    background-color: #000000;
}
.about h5{
    color: #ffffff;
    margin-top: 15px;
}
.aboutintro p{
    margin: 0 auto;
    font-size: 16px;
    color: rgb(86, 86, 86);
    line-height: 30px;
   
}
.card-text{
    margin: 0!important;
    font-size: 14px;
    color: rgb(86, 86, 86);
    line-height: 30px;
   
}
/* .aboutintro img{
    margin-left: 30px;
    border: 1px solid #d4d4d4;
    padding: 5px;
} */
box-style-mv{

    padding-top: 20px;
    text-align: center;
    height: 200px;
    background-color: #ffffff;
}
.box-style-mv p{
    text-align: center;
}
 .testimonial-header {
    font-weight: 300;
    margin: 0 0 30px;
}
.testimonial .review {
    font-size: 20px;
    color: black;
    margin: 0 0 10px;
}
.testimonial .user{
    font-size: 24px;
    color: black;
    font-weight: 300;
    margin: 0 0 0px;
}
.star .fa {
    color: rgb(255, 193, 7);
}
.top-bar{
    background-color: #244d8f;
    padding: 0px 40px;
    
  }
  .social .fa {
    color: #244d8f;
    vertical-align: -webkit-baseline-middle;
}
.contacth .fa {
    margin-right:8px;
    
}
  .top-bar a{
    color: #ffffff;
  }
  .social>li {
    display: inline-block;
    text-align: center;
    width: 30px;
    margin: 5px 5px;
    position: relative;
    font-size: 13px;
    background-color: #fff;
    border-radius: 50px;
    height: 30px;
}

.social li:hover .fa{
  color: #f70000;



}
.contacth>li {
    display: inline-block;
    padding: 15px 20px;
    position: relative;
    font-size: 14px;
}

.menubar {
    position: fixed;
    width: 100%;
    z-index: 10;
    padding: 0px 20px;
}
.menubar2 {
  position: relative;
  width: 100%;
  padding: 0px 20px;
  background: <?=$cheader?>;
  box-shadow: 0px 0px 1px 0 rgb(0 0 0 / 16%), 0 4px 10px 0px rgb(0 0 0 / 12%);

}
  .navbar {
    padding: 0px 10px;
}

  /* .menu-bar .dropdown-item:focus, .menu-bar .dropdown-item:hover{
    color: #cd004d;
  background: #ffffff;
  } */
  /* NOTE: top-bar end */
  
  
  /* .menu-bar{
    background:rgba(0, 0, 0, 0.84);
    position: sticky;
    top: 0;
    padding: 25px 0 25px 0;
    z-index: 2;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
  } */


  .dropdown-item{
   color: #212529!important;
   padding: 15px 20px;
  }
  .dropdown-item .fas{
    color:#090909;
  }
  .modal-header{
    background-color:<?=$cheader?>;
  }
  .modal-body .btncstm{
    background-color:<?=$cheader?>;
    color: #fff;
  }
  .cart{
    background-color:<?=$cheader?>;
  }
  .mob-ser .fas {
    color: <?=$cheader?>;
}
.navbar-light .navbar-toggler {
  color: <?=$cheader?>;
  border-color:<?=$cheader?>;
}

  .sticky {
    position: fixed;
    width: 100%;
    top: 0;
    box-shadow: 0px 0px 1px 0 rgb(0 0 0 / 16%), 0 4px 10px 0px rgb(0 0 0 / 12%);
    background: <?=$cheader?>;
    -webkit-transition: all 0.4s  ease-in-out;
    transition: all 0.4s  ease-in-out;
}
 .dropdown-menu{
  -webkit-transition: all 0.4s  ease-in-out;
    transition: all 0.4s  ease-in-out;
    font-size:14px;
 }
 .dropdown-divider {
  height: 0;
   margin: unset; 
  overflow: hidden;
  border-top: 1px solid #e9ecef;
}
  
  .nav-link {
    font-size: 14px;
    letter-spacing: 0.5px;
    font-weight: 300;
    outline: 0;
    text-transform: uppercase;
    position: relative;
}

.navbar-expand-lg .navbar-nav .nav-link {
    /* padding-right: .5rem; */
    /* padding-left: .5rem; */
    padding: 8px 14px;
    margin: 0px 0px;
}



.navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
    color: #d0b050;
    border-radius: 50px;
    border-top: 1px solid #d0b050;
    
}
  .navbar-light .navbar-nav .nav-link{
    color:#000000;
  }
  .menubar2 .navbar-light .navbar-nav .nav-link {
    color: #ffffff;
}
.menubar2 .navbar-light .navbar-nav .nav-link:hover {
    color: #d0b050;
}
  .sticky .navbar-light .navbar-nav .nav-link{
    color: #ffffff;
  }
  .sticky .navbar-light .navbar-nav .nav-link:hover {
    color: #d0b050;
}
  .navbar-brand img{
    -webkit-transition: all 0.4s  ease-in-out;
    transition: all 0.4s  ease-in-out;
    width: 250px;
  }
  .menubar .navbar-nav{
      margin-right: 0;
  }
  .catemenu .navbar-nav{
    margin: unset;
  }

  .filter .fhead{
    margin: 0;
    padding:.75rem 1.25rem ;
  }
  .filter .card-header{
    border: unset;
    background-color: #fff;
  }
  .search{
    padding: 0px 15px;
  }
  .whatsapp{
    position: fixed;
    bottom: 20px;
    right: 15px;
    z-index: 10;
    border-radius: 50px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
}
.calc {
  position: fixed;
  bottom: 20px;
  left: 15px;
  z-index: 10;
  border-radius: 50px;
  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
  cursor: pointer;
}
.whatsapp:hover{
transform: scale(1.03);
}
.menu-top{
  display:none;
  position: fixed;
  top: 20px;
  right: 15px;
  z-index: 10;
  cursor:pointer;
}
.menu{
  
    
    
    
    border-radius: 50px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);

}
hr{
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}


.serv li{
  display: inline-block;
  padding: 5px;
}
.serv img, .servd img{
  width: 50px;
  margin-bottom:6px;
}

.close {

  color: #bbb;
  
}
.close:not(:disabled):not(.disabled):focus, .close:not(:disabled):not(.disabled):hover {
  color: #fff;

}
/*set a border on the images to prevent shifting*/
#gal1 img {
  border: 1px solid white;
  width: 60px;
}

#img_01{
  position: relative!important;
}

.mainimg{
  
}
.prod_des {
  border: 1px solid rgba(28, 93, 190, 0.18);
  padding: 15px;
  position: relative;
  background-color: #fff;
}

span.des_fav {
  position: absolute;
  top: 3px;
  right: 3px;
  z-index: 1;
  font-size: 20px;
  height: 40px;
  padding: 4px;
  text-align: center;
  width: 40px;
  border: 1px solid rgba(28, 93, 190, 0.18);
  border-radius: 50%;
}
.des_fav .fas {
margin: 0;
}
.cb_div li {
 display: inline-block;
}
.acart,  .abuy{
  font-size: 18px;
  padding: 0 10%;
}
.acart_icon, .abuy_icon {
  padding: 10px 20px;
}
.zoomWrapper{
  overflow: hidden;
}
.product_det li .fas{
 font-size: 8px;
}
.my_orders li{
  display: inline-block;
  padding-right:12px;
  vertical-align: middle;
}

.my_orders li h6, .my_cart li h6{
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.my_orders .price{
    font-weight: 300;
    font-size: 18px;
}
.ordimg{
    padding:40px;
}

.my_cart li{
  display: inline-block;
  vertical-align: middle;
  
}
.my_cart img {
  width:100px;
  
}
.my_cart li p{
  line-height: unset;
  font-size: 10px;
  display: inline;
}
.my_cart .delete, .my_orders .delete{
  position: absolute;
    top: 8px;
    right: 10px;
    font-size: 13px;

}
span.price {
    padding-right: 10px;
}
.cwidth{
 width: 25%;
}
.cwidthmyo{
  width:40%;
}
.prod_des-head{
  font-size: 18px;
}
.breadcrumb{
  margin:0;
  font-size:12px;
}
ul.cb_div a {
    color: #fff;
}
.fea .item img{
  border-radius:5%;
}
.text-dark {
    color: #4f4f4f!important;
}
.cb_div{
  padding:15px;
  text-align: center;
  background-color: #e3e3e3;
}
#livesearch span{
  color:#000;
}
.goog-te-banner-frame.skiptranslate {
  display: none !important;
  } 
  #goog-gt-tt{
    display:none!important;
  }
/* ============================ footer =========================*/

.footer1 {
    padding: 30px 50px;
    background-color: <?=$cfooter?>;
}

img.footerlogo1{
  width: 25%;
}
img.footerlogo2 {
    width: 100px;
}

.footer1 ul li a, .footer1 p {
  color: #e1e1e1;
}
.footer1 ul li {
  padding: 0 0;
  font-size: 15px;
}
.footer1 h6 {
  color: #eedd6f;
  font-style: normal;
}

.footer1 .fas, .footer1 .fab {
    margin-right: 10px;
    color: #eedd6f;
}
.footer-menu img{
  margin: 0px;
}

.footer-menu li {
    display: inline-block;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 300;
}
.footer-menu li a {
  color: #ffffff;
}
ul.address li {
    padding: 15px;
    color: #ffffff;

}
ul.address li .fa {
    color:#e6bd54;
    font-size: 15px
}
.footer2{
  border-top: 1px solid #ffffff1a;
  background-color:<?=$cfooter?>;

}
.footer2 p{
  color: #ffffff;
  margin: 10px 0;
  line-height: unset;
  font-size: 13px;
}
.footer2 a{
  color: #eedd6f;

}
.footer2 ul li{
  display: inline-block;
  padding-right: 15px;
}
.footer-img{
  width: 50%;
  float: right;
}
.tracko{
  
  margin: 0px;
}
.modal-content{
  border: unset;
}

.navbar-light .navbar-toggler-icon {
  background-image: url("../img/menu.png");
}
.lioffer{

    position: absolute;
    left: 12px;
    top: 12px;
    padding: 0!important;
}
.offer {
    font-size: 12px;
    border: 1px solid #ff0023;
    border-radius: 25px;
    
    background-color: #ff0023;
    padding: 4px 20px;
    color: #FFFFFF;
}
.addtocart {
    font-size: 12px;
    border: 1px solid #000000;
    border-radius: 25px;
    background-color: #000000;
    padding: 6px 24px;
    color: #FFFFFF;
}
.cart-view{
   font-size: 12px;
    border: 1px solid #000000;
    border-radius: 25px;
    background-color: #000000;
    padding: 6px 24px;
    color: #FFFFFF;
}
.btn-light {
    
    background-color: #ffffff;
    border-color: #ffffff;
}

/* The snackbar - position it at the bottom and in the middle of the screen */
#snackbar {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background-color: #333; /* Black background color */
  color: #fff; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 1051; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  bottom: 30px; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#snackbar.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.9s;
  animation: fadein 0.5s, fadeout 0.5s 2.9s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}
.passmatch, .pw, .iotp{
    display: none;
    width: 100%;
    margin-top: .25rem;
    font-size: 80%;
    color: #dc3545;
}
.pinchkmsg{
  font-weight: 300;
}
.fav{
   position: absolute;
    top: 0;
    right: 0;
}
.top_cart_count{
  background-color: #090909;
    color: #fefefe;
    padding: 1px 5px;
    left: 20px;
    border-radius: 50%;
    font-size: 10px;
    top: 2px;
    position: absolute;
}
<!-- order status -->
.bs4-order-tracking {
    margin-bottom: 30px;
    overflow: hidden;
    color: #878788;
    padding-left: 0px;
    margin-top: 30px
}

.bs4-order-tracking li {
    list-style-type: none;
    font-size: 13px;
    width: 20%;
    float: left;
    position: relative;
    font-weight: 400;
    color: #878788;
    text-align: center
}

.bs4-order-tracking li:first-child:before {
    margin-left: 15px !important;
    padding-left: 11px !important;
    text-align: left !important
}

.bs4-order-tracking li:last-child:before {
    margin-right: 5px !important;
    padding-right: 11px !important;
    text-align: right !important
}

.bs4-order-tracking li>div {
    color: #fff;
    width: 29px;
    text-align: center;
    line-height: 29px;
    display: block;
    font-size: 12px;
    background: #878788;
    border-radius: 50%;
    margin: auto
}

.bs4-order-tracking li:after {
    content: '';
    width: 150%;
    height: 2px;
    background: #878788;
    position: absolute;
    left: 0%;
    right: 0%;
    top: 15px;
    z-index: -1
}

.bs4-order-tracking li:first-child:after {
    left: 50%
}

.bs4-order-tracking li:last-child:after {
    left: 0% !important;
    width: 0% !important
}

.bs4-order-tracking li.active {
    font-weight: bold;
    color: #dc3545
}

.bs4-order-tracking li.active>div {
    background: #dc3545
}

.bs4-order-tracking li.active:after {
    background: #dc3545
}

.card-timeline {
    background-color: #fff;
    z-index: 0;
    position:relative;
}
.card-timeline .fas{
   margin:0;
}
.plus-btns, .minus-btns {
    padding: 1px 5px;
    font-size: 12px;
}
.quantity .fas {
    margin:0;
}
.quantity input {
  -webkit-appearance: none;
  border: none;
  text-align: center;
  width: 32px;
  font-size: 16px;
  color: #43484D;
  font-weight: 300;
}
.breadcrumb{
  background-color:#ffffff;
}
#livesearch{
  position: absolute;
    left: 3%;
    background-color: #fff;
    z-index: 2;
    width: 94%;
    padding: 10px;
    box-shadow: 0 2px 4px 0 rgb(0 0 0 / 16%), 0 0px 0px 0 rgb(0 0 0 / 12%);
}
#livesearch ul li{
    font-size:14px;
    
}
.terms p{
  font-size: 18px;
    color: #585858;
    font-weight:300;
}
.terms h5, .terms h1 {
    font-weight: 300;
    font-style: unset;
}
.terms h6 {
    font-weight: 300;
    font-style: unset;
}
.terms ul {
    list-style: disc;
    margin: auto;
    padding-left: 40px;
}
.terms ul li {
    font-weight: 300;
    line-height: 30px;
}


.dos p{
  font-size:17px;
}
.categt a{
  color: #000;
    font-size: 18px;
}
.servd h3{
  font-family: 'Poppins', sans-serif;
}
.dos h5{
  font-family: 'Poppins', sans-serif;
}
.dos p{
  font-family: 'Poppins', sans-serif;
}
.footer1 .rounded-left  {
    border-top-left-radius: 3.25rem!important;
    border-bottom-left-radius: 3.25rem!important;
}
.footer1 .rounded-right{
  border-top-right-radius: 3.25rem!important;
    border-bottom-right-radius: 3.25rem!important;
}
.top-bar .imgcont{
  text-align:right;
}
.card-title {
   
    font-size: 18px;
}
.card-deck .card-title {
   font-size: 16px;
}
.card-img-top {
    padding-top: 1.25rem;
    font-size: 40px;
    overflow: hidden;
}
.card-img-top img, .imganim img{
  -webkit-transition-duration: 0.3s;
    transition-duration: 0.3s;
    width: 100%;
}
.card-img-top img:hover{
  transform: scale(1.2);

}
.imganim:hover img{
  transform: scale(1.1);
}
.overflowhiden{
  overflow: hidden;
}

.aboutbg {
  background: rgb(240,248,255);
  background: linear-gradient(90deg, rgba(240,248,255,1) 34%, rgba(255,238,238,1) 61%);
}
.aboutbg2 {
    background: rgb(255,255,255);
    background: linear-gradient(90deg, rgb(247 247 247) 34%, #f8f8f8 61%);
}
.servbg {

 
  background-color: <?=$cheader?>;

}
  .servbg2{
    background-image: url(../img/banner/back2.jpg);
    background-attachment: fixed;
    background-size: cover;
    background-position: top;
  }
  .card-deck .numscroller {
    font-size: 40px;
}
.nav-link.job{
  background-color:<?=$cheader?>;
    color: #ffffff!important;
    border-radius: 50px;
}
.sticky .nav-link.job{
    background-color:#ffffff;
    color: #000000!important;
    border-radius: 50px;
}
.menubar2 .nav-link.job{
    background-color:#ffffff;
    color: #000000!important;
    border-radius: 50px;
}
.services ul li {
    display: -webkit-inline-box;

    color: #6c757d;
    font-weight: 300;
    margin: 15px;
}
.faborder {
    border: 2px solid <?=$cheader?>;
    border-radius: 50%;
    padding: 9px;
    color: #f70000;
    background-color: #fff;
}

.count_border {
  /* border-top: 4px solid #e3aa3b; */
  /* width: 25%; */
  margin-bottom: 0px;
}

.bg-black {
  background-color: #343a40;
}
.slider {
    /* position: relative;
    overflow: hidden; */
    /* display: flex;
    flex-direction: row;
    justify-content: center; */
    
}
.main_slide_head {
    position: absolute;
    margin: 13% auto;
    z-index: 9;
    left: 0;
    width: 80%;
    top: 0;
    right: 0;
}
.main_slide_head .card {
   
    background-color: #00000000;
    border: unset;
}
.main_slide_head .card .card-body {
  padding: 20px 44px;
}
.main_slide_head h5 {
    font-size: 20px;
    letter-spacing: 1px;
}
.main_slide_head h1 {
    font-size: 60px;
    line-height: 80px;
    letter-spacing: 1px;
    color: #fff;
}
.main_slide_head h3 {
    font-size: 40px;
    letter-spacing: 1px;
    color: #fff;
}

.main_slide_head h2 {
    font-size: 70px;
    letter-spacing: 1px;
    color: #fff;

}

.main_slide_head h6 {
    font-size: 20px;
    letter-spacing: 1px;

}

.main_slide_head p {
  font-size: 18px;
  color: #ffc107;
  letter-spacing: 5px;
  text-shadow: 0px 1px 5px #010a05;
  line-height: 16px;
}
.overlay {
    width: 100%;
    height: 100%;
    position: absolute;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    display: flex;
    overflow: hidden;
    top: 0;
    left: 0;
    -webkit-transition: all 0.4s  cubic-bezier(0.88,-0.99, 0, 1.81);
    transition: all 0.4s  cubic-bezier(0.88,-0.99, 0, 1.81);
}

.overlay h4 {
    text-transform: capitalize;
    letter-spacing: 1px;
    color: #fff;
    text-align: center;
    position: relative;
    margin: 0;
    font-size: 1.2em;
    padding: 10px 0;
    width: 55%;
    background: <?=$cheader?>;
    -webkit-transform: translateY(40px);
    -ms-transform: translateY(40px);
    transform: translateY(40px);
    -webkit-transition: all 0.4s cubic-bezier(0.88,-0.99, 0, 1.81);
    transition: all 0.4s cubic-bezier(0.88,-0.99, 0, 1.81);
}
.overlay:hover{
  background-color:<?=$cheader?>57;
}
.overlay:hover h4 {
    -webkit-transform: translateY(10%);
    -ms-transform: translateY(10%);
    transform: translateY(10%);
    -moz-transform: translateY(10%);
    -o-transform: translateY(10%);
}
.services-icon {
  width: 60px;
  height: 60px;
  text-align: center;
  border: solid 2px #f1f1f1;
  padding: 1.1em 0 0 0;
  margin: 0 auto;
}
.services-icon-info {
  color: <?=$cheader?>;
  font-size: 16px;
  font-weight: 100;
  margin: 1em 0 0 0;
}
.service  i {
  color: #fff;
  font-size: 24px;
}
.hvr-radial-in {
    display: inline-block;
    vertical-align: middle;
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    position: relative;
    overflow: hidden;
    background: <?=$cheader?>;
    -webkit-transition-property: color;
    transition-property: color;
    -webkit-transition-duration: 0.3s;
    transition-duration: 0.3s;
}
.hvr-radial-in:before {
    content: "";
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: #101010;
    border-radius: 100%;
    -webkit-transform: scale(2);
    transform: scale(2);
    -webkit-transition-property: transform;
    transition-property: transform;
    -webkit-transition-duration: 0.3s;
    transition-duration: 0.3s;
    -webkit-transition-timing-function: ease-out;
    transition-timing-function: ease-out;
}
.services-grid:hover .hvr-radial-in:before {
    -webkit-transform: scale(0);
    transform: scale(0);
}
.service .bg-img {
  /* background-image: url(../img/property/p1.jpg);
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat; */
background-color: #000000;
}

.service .overlay {
  width: 100%;
  height: 100%;
  position: absolute;
  overflow: hidden;
  top: 0;
  left: 0;
  background-color:#171818b0;
  -webkit-transition: all 0.4s  cubic-bezier(0.88,-0.99, 0, 1.81);
  transition: all 0.4s  cubic-bezier(0.88,-0.99, 0, 1.81);
}
.service .slider p {
  line-height: 25px;
  font-size: 16px;
}
.service h5{
  font-size: 22px;
}
.nav-pills .nav-item{
  text-transform: none;
}
.scatl  .activec {
  color: #fff!important;
  background-color: <?=$cheader?>;
}
.scatl a {
  color: #fff;
  border: 1px solid #0000000f;
  background-color: #000000;
}
.owl-stage {
  margin: auto;
}
.testimonial .card {
  
  width: 96%;
  margin: auto;
}
.contactus i {
  color: #fdbd10;
  font-size: 28px;
  vertical-align: middle;
  border-right: 3px solid #00000070;
  padding: .8em .4em .8em 0em;
  float: left;
}
.contact-right {
  padding-left: 1.5em;
  float: left;
  padding-top: 8px;
}

.footer1 .fb {
  
  background-color: #2654b5;
  padding: 16px;
  border-radius: 50px;
}

.footer1 .tw {
  
  background-color: #1da1f2;
  padding: 16px;
  border-radius: 50px;
}

.footer1 .in {
  
  background: #f09433; 
  background: -moz-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); 
  background: -webkit-linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
  background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
  
  padding: 16px;
  border-radius: 50px;
  
}

.footer1 .yb {
  
  background-color: #f70000;
  padding: 16px;
  border-radius: 50px;
}
.bg-img2{


    background-image: url(../img/banner/about.jpg);
    background-attachment: fixed;
    background-size: cover;
    background-position: top;
}

#course-form .form-control {
 
    color: #ffffff;
    background-color: #151515;

    border: 1px solid #000000;

}
.displaynone-desk{
   display: none;
}
.displaynone-mob{
  display: block;
  }
  /* .animate__slideInDown {
    -webkit-animation-name: slideInDown;
    animation-name: slideInDown;
} */
  /* @-webkit-keyframes animate__slideInDown {
    0% {
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0);
    visibility: visible;
}
to {
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
}
}@keyframes slideInDown {
    0% {
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0);
    visibility: visible;
}
to {
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
}
}
   */
   figure{
    overflow: hidden;
   }
   .anim-img {
    opacity: 0;
    
   

}
.anim-img.active {

  opacity: 1;
  animation: zoomIn 1s 1;
 
}
  @media (prefers-reduced-motion: no-preference) {
    .square-animation {
      animation: bounceIn 1s 1;
      
    }
  }
  .reveal{
    position: relative;
    transform: translateY(150px);
    opacity: 0;
    -webkit-transition: all 0.4s  ease-in-out;
    transition: all 0.4s  ease-in-out;
  }
  
  .reveal.active{
    transform: translateY(0);
    opacity: 1;
  }
  .counter_outer h2 {
    color: #404040;
    font-size: 60px;
}
.counter-head h5 {
    
  margin-bottom: 0;
    font-size: 16px;
    line-height: 25px;
    font-weight: 600;
    color: #767676;
}
.counter-head h6 {
    font-size: 16px;
    line-height: 1.35;
    font-weight: 600;
    color: #404040;
}
.counter i {
    font-size: 25px;
  
}
  .btn-outline-danger {
    color: <?=$cheader?>;
    background-color: transparent;
    background-image: none;
    border-color: <?=$cheader?>;
}
.btn-outline-danger:hover {
  color: #fff;
  background-color: <?=$cheader?>;
  border-color: <?=$cheader?>;
}
 .icon{
  width: 36px;
 }
 .imghover:hover {
  transition: all 0.2s ease-in-out;
  transform: scale(1.03);
  cursor:pointer;
  

}
.btn-primary{

    -webkit-transition: all 0.4s  ease-in-out;
    transition: all 0.4s  ease-in-out;
    background-color: #2c3283;
    border-color: #2c3283;
    width: 20%;
    border-radius: 1.25rem;

}
.btn-danger{

-webkit-transition: all 0.4s  ease-in-out;
transition: all 0.4s  ease-in-out;
background-color: <?=$cheader?>;
border-color: <?=$cheader?>;
width: 20%;
border-radius: 1.25rem;

}
.btn-primary:hover {
    color: #fff;
    background-color: #2c3283;
    border-color: #2c3283;
}
.btn-danger:hover {
    color: #fff;
    background-color: <?=$cheader?>;
border-color: <?=$cheader?>;
}

.readmore{

  height: 50%;
  overflow: hidden;

}
.section-padding .btn {
    width: fit-content;
    border-radius: 50px;
}
.owl-rating .circle {
    padding: 15px;
    width: 100px;
    height: 100px;
    border: 1px solid #00959f;
    background-color: #f2f2f2;
    overflow: hidden;
    border-radius: 50px;
}
.cat .circle {
    width: 200px;
    height: 200px;
    border: 2px solid #0a1423ba;
    background-color: #f2f2f2;
    overflow: hidden;
    border-radius: 50%;
}
.ht .card {
    height: 100%;
}
.main_image {
    background-repeat: no-repeat;
    height: 100%;
    background-position: center;
    background-size: cover;
}
.list-group-item {
    position: relative;
    display: block;
    padding: .75rem 1.25rem;
    margin-bottom: -1px;
   background-color: unset;
    border: 1px solid rgb(255 255 255 / 13%);
}
.clients i{

    font-size: 26px;

}
h2.numscroller {
    font-size: 38px;
    line-height: 43px;
    margin-bottom: 5px;
    font-weight: 600;
}
.bg-warning {
    background-color: #c09a3a!important;
}
.text-warning {
    color: #e8d264!important;
}
b{
  font-weight: 600;
}

  /* Extra small devices (portrait phones, less than 767px)*/
@media (max-width: 767px) and (min-width: 375px) {

  .footer1 {
    padding: 30px 15px;

}
  .readmore {
    height: 200px;
    
}

  .aboutbg{
    background: rgb(255,255,255);
background: linear-gradient(180deg, rgba(255,255,255,1) 34%, rgba(255,238,238,1) 75%);
  }
  .aboutbg2 {
    background: rgb(255,255,255);
    background: linear-gradient(180deg, rgba(255,255,255,1) 34%, #fbfbfb 61%);
}
  .testimonial .card {
    

   
    width: 100%;
   
}
  /* .slider .item{
    width:1300px;
  }  */
  p.sub-head {
    letter-spacing: 0px;
    font-size: 14px;
}
  .home_sub{
    font-size: 17px;
    text-align:left;
  }
  .main_slide_head .card .card-body {
    padding: 20px 16px;
}
  h3 {
    font-size: 18px;
    text-align:left;
}
  p {
 
    font-size: 14px;
   
}



  .dropdown-menu {

    font-size: 12px;
}

  h1 {
    font-size: 30px;
}
  .owl-theme .owl-nav [class*=owl-] {

    font-size: 20px;

    width: 23px;
    height: 50px;

}

  .owl-carousel .owl-nav .owl-prev {
    left: 0px;
    top: 30%;
}
.owl-carousel .owl-nav .owl-next {
  right: 0px;
  top: 30%;
}
.main_slide_head h5 {
    font-size: 12px;
    letter-spacing: 0px;
}
.main_slide_head h6 {
    font-size: 14px;
    letter-spacing: 0px;
  
}
.main_slide_head .btn {
    font-size: 10px;

  
}
.main_slide_head h2 {
    font-size: 24px;
    letter-spacing: 0px;
    margin:0;

}
.main_slide_head h3 {
    font-size: 16px;
    letter-spacing: 0px;
    margin:0;

}
.main_slide_head h1 {
    font-size: 20px;
    letter-spacing: 0px;
    line-height: 25px;
}
.main_slide_head p {
  font-size: 15px;
  color: #fdbd10;
  letter-spacing: 3px;
  text-shadow: 0px 1px 5px #010a05;
  line-height: 20px;
}

.main_slide_head {
    position: absolute;
    margin: 0% 20px 0px;
    z-index: 9;
    width: 100%;
}
.navbar-light .navbar-toggler {
    color: #ffffff;
    position: absolute;
    border-color: #ffffff;
    right: 0;
    right: 4px;
    top: 39px;
}

.clients img {
    width: 50px!important;
    margin: 0px auto 16px;
}
.clients .card-title {
    font-size: 16px;
    margin-bottom: 5px;
}
.clients .card-body {
    padding:10px;
}
.clients .card-text {
    margin: 0!important;
    font-size: 12px;
    color: rgb(86, 86, 86);
    line-height: 24px;
}


.displaynone-desk{
display: block;
}

  .servbg {

    background-position: left;
}
  .services ul li {
    display: -webkit-inline-box;
    width: 100%;
  
    text-align: left;
    margin: 5px;
}
  .w-50, .w-75{
    width:100%!important;
  }
  ul.footerli li{
    margin: 0 0 4px 0;
    display: inline-block;
    background-color: #343a40;
    padding: 5px 10px;
  }  ul.footerli li a{
    color:#fff;
  }
.footer1 h6{
  margin: 0 0 8px;
}
  .servd h3 {
   
    font-size: 14px;
}
  .top-bar .imgcont{
  text-align:center;
}
.categt a {
    
    font-size: 10px;
}
  .os h4{
  font-size:18px;
}
  .cwidth{
    width: 100%;
   }
   .section-padding {
    padding: 15px 0;
}

  .section-title {

      
    margin: 0 0 0px 0;
    font-size: 18px;
  }
  .card-title {
    font-size: 12px;
}
.top-bar {
  padding: 0px 5px;
}
.menubar {
  padding: 5px 5px;
  position: relative;
  background: <?=$cheader?>;

}
.navbar-light .navbar-nav .nav-link {
  color: #ffffff;
}
.mob-ser .fas {
    color: #ffffff;
}
.menubar2 {
  background: #ffffff;
  background: <?=$cheader?>;
}
.menubar2 .navbar-light .navbar-nav .nav-link {
  color: #ffffff;
}
  .overlay h4 {

    margin: 31px auto 2px;

}
.service .overlay {

  position: relative;

}
  p {
    margin: 0 0 15px;
    line-height: 30px;
}

  .contacth>li {
 
    padding: 15px 0px;
  
    border: unset!important;
}

  .users{
    padding: 40px 40px!important;
  }
  .testimonial-header {
    
    font-size: 24px!important;
  
}
.testimonial .review{
  font-size: 14px!important;

}
  .section-title span.elitecolor{
    padding-left: 5px;
  }
  .navbar-brand img {
    width: 316px!important;
}
.navbar {
    padding: 0px 0px;
}
.navbar-brand {

    margin-right: 0;
}
  .aboutintro img{
    margin-left: 0!important;
  }
  .card-deck .card-title {
    font-size: 16px;
}
.testimonial .user {
  font-size: 16px;

}
.counter h5 {
    font-size: 12px;
    line-height:16px;
}
.counter h2 {
  font-size: 16px;
  margin:0;
  line-height: 30px;
}
.counter img {
  width: 26px;
}
.counter-head h6 {
  font-size: 12px;

}
.btn-primary{
  width: fit-content;
}
.btn-danger{
  width: fit-content;
}
.contactus i {
  color: #fdbd10;
  width: 100%;
  background-color: #e1e1e1;
  font-size: 16px;
  vertical-align: middle;
  border-right: 3px solid #00000070;
  padding: .8em .8em .8em 1em;
  float: left;
}
.contact-right {
  padding-left: 0.5rem;

}
 
  .aboutintro p {
    padding-bottom:10px;
    font-size: 13px;
}
  .about h5{
    padding: 10px;
    font-size: 16px
  }
  .btm-head p{
    font-size: 12px;
  }
  
  .dth ul li{
    padding: 15px;
  }

.displaynone-mob{
	display:none!important;
}
.serv img, .servd img {
  width: 60px;
}
.serv h4, .servd h4 {
  font-size: 15px;
  margin-top: 8px;
}
.serv li{
  padding: unset;
}
.footer2 p {
    font-size:12px;
}

.main_image {

    height: 180px;

}
.footer1{
  
  padding: 40px  15px 0;

  background-repeat: no-repeat;
  background-position: right;
  background-size: cover;
  
}
.footer1 ul li a, .footer1 p {
  margin: 0;
}
.acart_icon, .abuy_icon {
  padding: 5px 10px;
}

.acart, .abuy {
  font-size: 15px;
  padding: 0 4%;
}
.my_orders li {
  
  padding: 5px;
  font-size: 12px;
  
  
}
.my_orders button {
  
  

  
  
}
.my_orders .price {
   
    width: 100%;
}
.ordimg{
  width:60px;
}
.my_cart li {
  display: inline-block;
  
}
.my_cart img {
  width:50px;
  
}
.cwidthmyo {
    width: 60%;
}
.bs4-order-tracking li {
    
    font-size: 8px;
}
.tracko{
  text-align: center;
  margin-top: 5px;
}

.eliteborder-shop {
    margin: 0px;
    border: 0.1px solid rgb(179 179 179 / 18%);

}
.newarrival .btn{
  font-size:10px;
}

span.price {
    padding-right: 0px;
}
.btm-head {
    
    padding: 8px;
}
#loader {
    
    margin: -75px 0 0 -44px;
   
}

.addtocart {
    
    padding: 6px 12px;
    font-size: 9px;
    
}
.cart-view{
  font-size: 9px;
}
.offer {
    font-size: 10px;
     padding: 2px 12px;
    
}
.lioffer {
    
    left: 4px;
    top: 7px;
    
}
.btm-head .price, .btm-head .actual_price {
    font-size: 12px;
    
}
.terms h6 {
  
  font-size: 12px;
}
.terms ul {
 
  padding-left: 5px;
}
.terms ul li {
  
  font-size: 12px;
}
.terms h5, .terms h1 {
  
  font-size: 20px;
  
}
.terms p {
  
  font-size: 14px;
  margin: 0 0 10px;
}

  }




  @media (max-width: 374px) and (min-width: 300px) {

    .footer1 {
      padding: 30px 15px;
  
  }
    .readmore {
      height: 200px;
      
  }
  
    .aboutbg{
      background: rgb(255,255,255);
  background: linear-gradient(180deg, rgba(255,255,255,1) 34%, rgba(255,238,238,1) 75%);
    }
    .aboutbg2 {
      background: rgb(255,255,255);
      background: linear-gradient(180deg, rgba(255,255,255,1) 34%, #fbfbfb 61%);
  }
    .testimonial .card {
      
  
     
      width: 100%;
     
  }
    /* .slider .item{
      width:1300px;
    }  */
    p.sub-head {
      letter-spacing: 0px;
      font-size: 14px;
  }
    .home_sub{
      font-size: 17px;
      text-align:left;
    }
    .main_slide_head .card .card-body {
      padding: 20px 16px;
  }
    h3 {
      font-size: 18px;
      text-align:left;
  }
    p {
   
      font-size: 14px;
     
  }
  
  
  
    .dropdown-menu {
  
      font-size: 12px;
  }
  
    h1 {
      font-size: 30px;
  }
    .owl-theme .owl-nav [class*=owl-] {
  
      font-size: 20px;
  
      width: 23px;
      height: 50px;
  
  }
  
    .owl-carousel .owl-nav .owl-prev {
      left: 0px;
      top: 30%;
  }
  .owl-carousel .owl-nav .owl-next {
    right: 0px;
    top: 30%;
  }
  .main_slide_head h5 {
      font-size: 12px;
      letter-spacing: 0px;
  }
  .main_slide_head h6 {
      font-size: 14px;
      letter-spacing: 0px;
    
  }
  .main_slide_head .btn {
      font-size: 10px;
  
    
  }
  .main_slide_head h2 {
      font-size: 24px;
      letter-spacing: 0px;
      margin:0;
  
  }
  .main_slide_head h3 {
      font-size: 16px;
      letter-spacing: 0px;
      margin:0;
  
  }
  .main_slide_head h1 {
      font-size: 20px;
      letter-spacing: 0px;
      line-height: 25px;
  }
  .main_slide_head p {
    font-size: 15px;
    color: #fdbd10;
    letter-spacing: 3px;
    text-shadow: 0px 1px 5px #010a05;
    line-height: 20px;
  }
  
  .main_slide_head {
      position: absolute;
      margin: 0% 20px 0px;
      z-index: 9;
      width: 100%;
  }
  .navbar-light .navbar-toggler {
      color: #ffffff;
      position: absolute;
      border-color: #ffffff;
      right: 0;
      right: 4px;
      top: 39px;
  }
  
  .clients img {
      width: 50px!important;
      margin: 0px auto 16px;
  }
  .clients .card-title {
      font-size: 16px;
      margin-bottom: 5px;
  }
  .clients .card-body {
      padding:10px;
  }
  .clients .card-text {
      margin: 0!important;
      font-size: 12px;
      color: rgb(86, 86, 86);
      line-height: 24px;
  }
  
  
  .displaynone-desk{
  display: block;
  }
  
    .servbg {
  
      background-position: left;
  }
    .services ul li {
      display: -webkit-inline-box;
      width: 100%;
    
      text-align: left;
      margin: 5px;
  }
    .w-50, .w-75{
      width:100%!important;
    }
    ul.footerli li{
      margin: 0 0 4px 0;
      display: inline-block;
      background-color: #343a40;
      padding: 5px 10px;
    }  ul.footerli li a{
      color:#fff;
    }
  .footer1 h6{
    margin: 0 0 8px;
  }
    .servd h3 {
     
      font-size: 14px;
  }
    .top-bar .imgcont{
    text-align:center;
  }
  .categt a {
      
      font-size: 10px;
  }
    .os h4{
    font-size:18px;
  }
    .cwidth{
      width: 100%;
     }
     .section-padding {
      padding: 15px 0;
  }
  
    .section-title {
  
        
      margin: 0 0 0px 0;
      font-size: 18px;
    }
    .card-title {
      font-size: 12px;
  }
  .top-bar {
    padding: 0px 5px;
  }
  .menubar {
    padding: 5px 5px;
    position: relative;
    background: <?=$cheader?>;
  
  }
  .navbar-light .navbar-nav .nav-link {
    color: #ffffff;
  }
  .mob-ser .fas {
      color: #ffffff;
  }
  .menubar2 {
    background: #ffffff;
    background: <?=$cheader?>;
  }
  .menubar2 .navbar-light .navbar-nav .nav-link {
    color: #ffffff;
  }
    .overlay h4 {
  
      margin: 31px auto 2px;
  
  }
  .service .overlay {
  
    position: relative;
  
  }
    p {
      margin: 0 0 15px;
      line-height: 30px;
  }
  
    .contacth>li {
   
      padding: 15px 0px;
    
      border: unset!important;
  }
  
    .users{
      padding: 40px 40px!important;
    }
    .testimonial-header {
      
      font-size: 24px!important;
    
  }
  .testimonial .review{
    font-size: 14px!important;
  
  }
    .section-title span.elitecolor{
      padding-left: 5px;
    }
    .navbar-brand img {
      width: 261px!important;
  }
  .navbar {
      padding: 0px 0px;
  }
  .navbar-brand {
  
      margin-right: 0;
  }
    .aboutintro img{
      margin-left: 0!important;
    }
    .card-deck .card-title {
      font-size: 16px;
  }
  .testimonial .user {
    font-size: 16px;
  
  }
  .counter h5 {
      font-size: 12px;
      line-height:16px;
  }
  .counter h2 {
    font-size: 16px;
    margin:0;
    line-height: 30px;
  }
  .counter img {
    width: 26px;
  }
  .counter-head h6 {
    font-size: 12px;
  
  }
  .btn-primary{
    width: fit-content;
  }
  .btn-danger{
    width: fit-content;
  }
  .contactus i {
    color: #fdbd10;
    width: 100%;
    background-color: #e1e1e1;
    font-size: 16px;
    vertical-align: middle;
    border-right: 3px solid #00000070;
    padding: .8em .8em .8em 1em;
    float: left;
  }
  .contact-right {
    padding-left: 0.5rem;
  
  }
   
    .aboutintro p {
      padding-bottom:10px;
      font-size: 13px;
  }
    .about h5{
      padding: 10px;
      font-size: 16px
    }
    .btm-head p{
      font-size: 12px;
    }
    
    .dth ul li{
      padding: 15px;
    }
  
  .displaynone-mob{
    display:none!important;
  }
  .serv img, .servd img {
    width: 60px;
  }
  .serv h4, .servd h4 {
    font-size: 15px;
    margin-top: 8px;
  }
  .serv li{
    padding: unset;
  }
  .footer2 p {
      font-size:12px;
  }
  
  .main_image {
  
      height: 180px;
  
  }
  .footer1{
    
    padding: 40px  15px 0;
  
    background-repeat: no-repeat;
    background-position: right;
    background-size: cover;
    
  }
  .footer1 ul li a, .footer1 p {
    margin: 0;
  }
  .acart_icon, .abuy_icon {
    padding: 5px 10px;
  }
  
  .acart, .abuy {
    font-size: 15px;
    padding: 0 4%;
  }
  .my_orders li {
    
    padding: 5px;
    font-size: 12px;
    
    
  }
  .my_orders button {
    
    
  
    
    
  }
  .my_orders .price {
     
      width: 100%;
  }
  .ordimg{
    width:60px;
  }
  .my_cart li {
    display: inline-block;
    
  }
  .my_cart img {
    width:50px;
    
  }
  .cwidthmyo {
      width: 60%;
  }
  .bs4-order-tracking li {
      
      font-size: 8px;
  }
  .tracko{
    text-align: center;
    margin-top: 5px;
  }
  
  .eliteborder-shop {
      margin: 0px;
      border: 0.1px solid rgb(179 179 179 / 18%);
  
  }
  .newarrival .btn{
    font-size:10px;
  }
  
  span.price {
      padding-right: 0px;
  }
  .btm-head {
      
      padding: 8px;
  }
  #loader {
      
      margin: -75px 0 0 -44px;
     
  }
  
  .addtocart {
      
      padding: 6px 12px;
      font-size: 9px;
      
  }
  .cart-view{
    font-size: 9px;
  }
  .offer {
      font-size: 10px;
       padding: 2px 12px;
      
  }
  .lioffer {
      
      left: 4px;
      top: 7px;
      
  }
  .btm-head .price, .btm-head .actual_price {
      font-size: 12px;
      
  }
  .terms h6 {
    
    font-size: 12px;
  }
  .terms ul {
   
    padding-left: 5px;
  }
  .terms ul li {
    
    font-size: 12px;
  }
  .terms h5, .terms h1 {
    
    font-size: 20px;
    
  }
  .terms p {
    
    font-size: 14px;
    margin: 0 0 10px;
  }
  
    }